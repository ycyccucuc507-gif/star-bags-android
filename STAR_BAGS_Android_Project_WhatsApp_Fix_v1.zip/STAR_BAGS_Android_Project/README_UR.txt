STAR BAGS Android Project

یہ پروجیکٹ آپ کی موجودہ HTML ایپ کو Android WebView میں چلاتا ہے۔
اس اپڈیٹ میں:
1) FileProvider کے ذریعے بل کی PNG تصویر Android کے شیئر مینو میں بھیجنے کی سہولت شامل ہے۔
2) SMS کے لیے فون نمبر اور بل کا متن native SMS ایپ میں کھولنے کی سہولت شامل ہے۔
3) Gradle dependency اور Android manifest میں FileProvider ترتیب دی گئی ہے۔
4) GitHub Actions workflow الگ فائل .github/workflows/build-apk.yml میں موجود ہے۔

اہم حدود:
- WhatsApp پر بھیجنے سے پہلے Android share chooser میں WhatsApp منتخب کرنا ہوگا؛ ایپ خودکار طور پر پیغام نہیں بھیجتی۔
- Google Drive کا روزانہ خودکار بیک اپ ابھی شامل نہیں؛ اس کے لیے محفوظ Google sign-in/OAuth اور Drive API سیٹ اپ درکار ہے۔
- 58mm Bluetooth thermal printer کی مکمل pairing/ESC-POS سپورٹ پرنٹر کے درست ماڈل کے بغیر تصدیق نہیں کی جا سکتی۔
- Pull-to-refresh، تمام صفحات کا نیا navigation، اور scheduled background backup اس پیکج میں مکمل نہیں کیے گئے۔
- موجودہ مقامی ڈیٹا محفوظ رکھنے کے لیے اپڈیٹ سے پہلے ایپ کے اندر سے Full Backup JSON لازماً نکال کر الگ محفوظ کریں۔
- اگر نئی APK کی signing key پرانی APK سے مختلف ہو تو Android اسے براہ راست update نہیں کرے گا۔ ایسی صورت میں پرانی ایپ uninstall نہ کریں جب تک backup بحال کرنے کا طریقہ یقینی نہ ہو۔

Build:
GitHub Actions میں Build STAR BAGS APK workflow چلائیں۔ کامیاب build کے بعد STAR-BAGS-APK artifact میں app-debug.apk ملے گی۔
