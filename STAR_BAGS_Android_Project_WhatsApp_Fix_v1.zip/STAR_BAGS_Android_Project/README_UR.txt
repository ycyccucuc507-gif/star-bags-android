STAR BAGS Android Project — Version 1.2

یہ مکمل Android Studio پروجیکٹ ہے۔ ایپ کا موجودہ HTML سورس app/src/main/assets/index.html میں رکھا گیا ہے اور MainActivity.java اسے Android WebView میں چلاتی ہے۔

اس اپڈیٹ میں شامل اصلاحات:
1) WhatsApp کے لیے https://wa.me لنک؛ Android میں WhatsApp Business پہلے، پھر عام WhatsApp کھولنے کی کوشش۔
2) Send Bill پر بل کی خودکار محفوظ کاری برقرار رکھی گئی ہے۔
3) بل کی اصل PNG تصویر تیار کرکے Android share intent کے ذریعے منسلک کی جاتی ہے؛ WhatsApp Business/WhatsApp کو ترجیح دی جاتی ہے۔
4) Backup JSON کو Android Downloads/STAR BAGS میں محفوظ کرنے کے لیے native bridge؛ پرانے Android پر Save As دستاویز کا آپشن۔
5) Backup میں بل، پروڈکٹس، پرچیز، پارٹیز، مزدوری، اخراجات، اسٹاک تبدیلیاں، ادائیگیاں، ری سائیکل بن، پڑتا ریکارڈ اور بنیادی ایپ ترجیحات شامل ہیں۔ Restore میں پرانا ڈیٹا ڈھانچہ برقرار رکھا گیا ہے اور نئی ترجیحات بھی بحال ہوتی ہیں۔
6) Android status/navigation bar insets، بڑا STAR BAGS ہیڈر اور تین لائنوں والا مینیو۔
7) Native Splash Screen پر STAR BAGS لوگو اور نام۔
8) SwipeRefreshLayout کے ذریعے Pull-to-Refresh؛ اسکرین نیچے کھینچ کر چھوڑنے پر Home کھلتا ہے۔ فارم اور اندرونی اسکرول والے حصوں میں عام gestures محفوظ رکھنے کے لیے touch guard شامل ہے۔
9) Android Back کے لیے in-app module stack؛ ایک ایک قدم پیچھے، Home پر پہنچنے کے بعد ایپ بند ہوتی ہے۔
10) پرنٹر Settings کے Bluetooth intent سمیت دیگر Android intents کی routing۔

GitHub Actions Build:
- Java: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Android SDK: API 35
- Workflow: .github/workflows/build-apk.yml

GitHub پر اپلوڈ کرنے کا طریقہ (پچھلے workflow کے ساتھ):
1) اس پروجیکٹ ZIP کا نام STAR_BAGS_Android_Project_WhatsApp_Fix_v1.zip رکھ کر GitHub repository کے root میں اپلوڈ کریں۔
2) repository میں .github/workflows/main.yml فائل موجود ہونی چاہیے؛ اس اپڈیٹ کے ساتھ فراہم کردہ main.yml اس جگہ رکھیں یا پرانی فائل کو اس سے replace کریں۔
3) GitHub → Actions → STAR BAGS Android APK Build کھولیں اور Run workflow دبائیں۔ ZIP اپلوڈ کرنے پر بھی workflow خودکار طور پر چل سکتا ہے۔
4) کامیاب build کے بعد STAR-BAGS-Android-APK artifact ڈاؤن لوڈ کریں؛ اس میں app-debug.apk ہوگی۔

متبادل: ZIP Extract کرکے repository کے root میں STAR_BAGS_Android_Project فولڈر اور .github/workflows/build-apk.yml اپلوڈ کریں؛ اس صورت میں build-apk.yml والا workflow استعمال ہوگا۔
اہم احتیاط:
- نئی APK انسٹال کرنے سے پہلے موجودہ ایپ سے Full Backup JSON بنا کر محفوظ کریں۔
- اگر نئی APK کی signing key پرانی APK سے مختلف ہو تو Android اسے براہ راست update نہیں کرے گا۔ Backup اور app signing کی تصدیق کیے بغیر پرانی ایپ uninstall نہ کریں۔
- WhatsApp خودکار طور پر Send بٹن نہیں دباتا؛ Android/WhatsApp میں صارف کو آخری Send کی تصدیق کرنا ہوگی۔ WhatsApp Business میں چیٹ preselect کرنے کی کوشش کی جاتی ہے، لیکن WhatsApp کے ورژن کے لحاظ سے کبھی chat picker بھی ظاہر ہوسکتا ہے۔
- اس ماحول میں Android SDK/Gradle موجود نہ ہونے کی وجہ سے یہاں مکمل APK build نہیں چل سکی؛ GitHub Actions کا build لازمی چلائیں اور APK کو اصل موبائل پر test کریں۔
