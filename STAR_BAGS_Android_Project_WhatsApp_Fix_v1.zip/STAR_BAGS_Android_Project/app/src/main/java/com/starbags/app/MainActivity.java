package com.starbags.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.app.DownloadManager;
import android.os.Environment;
import android.content.Context;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(35,77,120));
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(true);
        s.setBuiltInZoomControls(false); s.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new StarBagsBridge(), "StarBagsAndroid");
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                // Never let custom intent:// URLs fall through to WebView (ERR_UNKNOWN_URL_SCHEME).
                try {
                    if (url != null && url.startsWith("intent://")) {
                        Uri source = Uri.parse(url);
                        String phone = source.getQueryParameter("phone");
                        String message = source.getQueryParameter("text");
                        if (phone != null && !phone.isEmpty()) {
                            Uri wa = Uri.parse("https://wa.me/" + phone + (message == null ? "" : "?text=" + Uri.encode(message)));
                            Intent business = new Intent(Intent.ACTION_VIEW, wa);
                            business.setPackage("com.whatsapp.w4b");
                            try { startActivity(business); } catch (Exception noBusiness) {
                                Intent normal = new Intent(Intent.ACTION_VIEW, wa);
                                try { startActivity(normal); } catch (Exception noWhatsApp) {
                                    v.loadUrl(wa.toString());
                                }
                            }
                        }
                        return true;
                    }
                    if (url.startsWith("https://") || url.startsWith("http://") || url.startsWith("tel:") || url.startsWith("mailto:")) {
                        Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        try { startActivity(view); return true; }
                        catch (Exception e) { return url.startsWith("http") ? false : true; }
                    }
                } catch (Exception ignored) { return true; }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return shouldOverrideUrlLoading(v, request.getUrl().toString());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null); fileCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_CHOOSER); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        webView.setDownloadListener((url, ua, disposition, mime, length) -> {
            try { DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime); r.addRequestHeader("User-Agent", ua);
                r.setTitle(URLUtil.guessFileName(url, disposition, mime));
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, disposition, mime));
                ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            } catch (Exception ignored) {}
        });
        if (state == null) webView.loadUrl("file:///android_asset/index.html"); else webView.restoreState(state);
    }

    public class StarBagsBridge {
        @JavascriptInterface public void shareBillImage(String base64, String phone, String message) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared_bills"); if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, "STAR-BAGS-Bill.png");
                try (FileOutputStream out = new FileOutputStream(f)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", f);
                Intent send = new Intent(Intent.ACTION_SEND); send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri); send.putExtra(Intent.EXTRA_TEXT, message == null ? "STAR BAGS Bill" : message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "STAR BAGS — بل شیئر کریں"));
            } catch (Exception e) { runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔ دوبارہ کوشش کریں۔", android.widget.Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void openSms(String phone, String message) {
            try { Uri uri = Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone));
                Intent i = new Intent(Intent.ACTION_SENDTO, uri); i.putExtra("sms_body", message == null ? "" : message); startActivity(i);
            } catch (Exception e) { runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, "SMS ایپ دستیاب نہیں۔", android.widget.Toast.LENGTH_LONG).show()); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); fileCallback = null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) { webView.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
