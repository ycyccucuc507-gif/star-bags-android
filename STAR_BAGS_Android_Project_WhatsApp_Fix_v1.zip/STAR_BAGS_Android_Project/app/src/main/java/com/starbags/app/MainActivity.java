package com.starbags.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_BACKUP = 1002;
    private static final int BRAND = Color.rgb(24, 59, 99);

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private FrameLayout root;
    private View splashView;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingBackupBytes;
    private String pendingBackupName = "star-bags-backup.json";
    private String pendingBackupMime = "application/json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(BRAND);
        getWindow().setNavigationBarColor(BRAND);
        getWindow().getDecorView().setSystemUiVisibility(0);

        root = new FrameLayout(this);
        root.setBackgroundColor(BRAND);
        root.setClipToPadding(false);

        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setColorSchemeColors(BRAND, Color.rgb(49, 91, 135));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        swipeRefresh.addView(webView, new SwipeRefreshLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(swipeRefresh, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);

        showSplash();
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setBuiltInZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new StarBagsBridge(), "StarBagsAndroid");
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(view, url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(view, request.getUrl().toString());
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideSplash();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.startsWith("blob:")) return; // Blob backups use the native bridge below.
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                if (mimeType != null) request.setMimeType(mimeType);
                if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(filename);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
            } catch (Exception e) {
                Toast.makeText(this, "فائل ڈاؤن لوڈ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
            }
        });

        swipeRefresh.setOnChildScrollUpCallback((parent, child) -> webView != null && webView.canScrollVertically(-1));
        swipeRefresh.setOnRefreshListener(() -> {
            if (webView == null) {
                swipeRefresh.setRefreshing(false);
                return;
            }
            webView.evaluateJavascript(
                    "(function(){if(window.starBagsGoHomeFromRefresh){window.starBagsGoHomeFromRefresh();}else if(window.showModule){window.showModule('home');window.scrollTo(0,0);}})();",
                    value -> { if (swipeRefresh != null) swipeRefresh.setRefreshing(false); });
        });

        if (state == null) webView.loadUrl("file:///android_asset/index.html");
        else {
            webView.restoreState(state);
            if (webView.getUrl() == null) webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BRAND);
        splash.setPadding(28, 32, 28, 32);

        ImageView logo = new ImageView(this);
        try { logo.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("star_bags_logo.jpg"), null)); }
        catch (Exception ignored) {}
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(220), dp(160));
        logoParams.bottomMargin = dp(18);
        splash.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("STAR BAGS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));

        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        progressParams.topMargin = dp(22);
        splash.addView(progress, progressParams);

        splashView = splash;
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideSplash() {
        if (splashView != null && root != null) {
            root.removeView(splashView);
            splashView = null;
        }
    }

    private boolean routeUrl(WebView view, String rawUrl) {
        if (rawUrl == null) return false;
        try {
            if (rawUrl.startsWith("intent://")) {
                Uri intentUri = Uri.parse(rawUrl);
                launchWhatsApp(intentUri.getQueryParameter("phone"), intentUri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("intent:")) {
                try { startActivity(Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME)); }
                catch (Exception ignored) { Toast.makeText(this, "یہ Android آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
                return true;
            }
            Uri uri = Uri.parse(rawUrl);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (host.equals("wa.me") || host.endsWith(".wa.me") || host.equals("api.whatsapp.com")) {
                String phone = uri.getQueryParameter("phone");
                if (phone == null || phone.isEmpty()) {
                    java.util.List<String> segments = uri.getPathSegments();
                    if (!segments.isEmpty()) phone = segments.get(0);
                }
                launchWhatsApp(phone, uri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("https://") || rawUrl.startsWith("http://") || rawUrl.startsWith("tel:") || rawUrl.startsWith("mailto:")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (Exception e) { return rawUrl.startsWith("http"); }
            }
        } catch (Exception ignored) {
            return true;
        }
        return false;
    }

    private void launchWhatsApp(String phone, String message) {
        String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        Uri chat = Uri.parse("https://wa.me/" + number + (message == null || message.isEmpty() ? "" : "?text=" + Uri.encode(message)));
        Intent business = new Intent(Intent.ACTION_VIEW, chat);
        business.setPackage("com.whatsapp.w4b");
        try { startActivity(business); return; } catch (Exception ignored) {}
        Intent normal = new Intent(Intent.ACTION_VIEW, chat);
        normal.setPackage("com.whatsapp");
        try { startActivity(normal); return; } catch (Exception ignored) {}
        try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, chat), "WhatsApp کھولیں")); }
        catch (Exception e) { Toast.makeText(this, "WhatsApp دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
    }

    private void saveBackupBytes(byte[] bytes, String filename, String mimeType) {
        pendingBackupBytes = bytes;
        pendingBackupName = filename == null || filename.trim().isEmpty() ? "star-bags-backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
        pendingBackupMime = mimeType == null || mimeType.isEmpty() ? "application/json" : mimeType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingBackupName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, pendingBackupMime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/STAR BAGS");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Downloads provider unavailable");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Unable to open output");
                    out.write(bytes);
                }
                ContentValues complete = new ContentValues();
                complete.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, complete, null, null);
                pendingBackupBytes = null;
                Toast.makeText(this, "بیک اپ Downloads/STAR BAGS میں محفوظ ہوگیا۔", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception e) {
                // SAF below is the safe fallback if MediaStore is unavailable.
            }
        }
        try {
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType(pendingBackupMime);
            create.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
            startActivityForResult(create, CREATE_BACKUP);
        } catch (Exception e) {
            Toast.makeText(this, "بیک اپ محفوظ کرنے کا آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show();
            pendingBackupBytes = null;
        }
    }

    public class StarBagsBridge {
        @JavascriptInterface public void setPullToRefreshEnabled(boolean enabled) {
            runOnUiThread(() -> { if (swipeRefresh != null) swipeRefresh.setEnabled(enabled); });
        }

        @JavascriptInterface public void saveBackup(String base64, String filename, String mimeType) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> saveBackupBytes(bytes, filename, mimeType));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بیک اپ فائل تیار نہیں ہو سکی۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBillImage(String base64, String phone, String message) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared_bills");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cache directory unavailable");
                File file = new File(dir, "STAR-BAGS-Bill.png");
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message == null ? "STAR BAGS Bill" : message);
                if (!number.isEmpty()) send.putExtra("jid", number + "@s.whatsapp.net");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newUri(getContentResolver(), "STAR BAGS Bill", uri));
                runOnUiThread(() -> {
                    try {
                        Intent business = new Intent(send);
                        business.setPackage("com.whatsapp.w4b");
                        startActivity(business);
                    } catch (Exception noBusiness) {
                        try {
                            Intent normal = new Intent(send);
                            normal.setPackage("com.whatsapp");
                            startActivity(normal);
                        } catch (Exception noWhatsApp) {
                            try { startActivity(Intent.createChooser(send, "STAR BAGS — بل شیئر کریں")); }
                            catch (Exception e) { Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔", Toast.LENGTH_LONG).show(); }
                        }
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔ دوبارہ کوشش کریں۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void openSms(String phone, String message) {
            try {
                Uri uri = Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone));
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", message == null ? "" : message);
                startActivity(intent);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "SMS ایپ دستیاب نہیں۔", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
            return;
        }
        if (requestCode == CREATE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Unable to open destination");
                    out.write(pendingBackupBytes);
                    Toast.makeText(this, "بیک اپ فائل محفوظ ہوگئی۔", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "بیک اپ فائل محفوظ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupBytes = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
                "(function(){try{return window.starBagsHandleBack?window.starBagsHandleBack():false;}catch(e){return false;}})();",
                value -> {
                    if (value == null || "false".equals(value) || "null".equals(value)) finish();
                });
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
