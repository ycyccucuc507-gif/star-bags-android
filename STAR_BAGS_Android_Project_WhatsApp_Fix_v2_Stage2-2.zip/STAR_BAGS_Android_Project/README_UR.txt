STAR BAGS — Audited source package V2.1

اس اپ ڈیٹ میں V2.0 کے اصل Android project پر دو تصحیحات کی گئی ہیں:
1) کیٹلاگ کی فی آئٹم display settings اب اصل product storage key میں محفوظ ہوتی ہیں۔
2) بل کے ساتھ منسلک تصویر/PDF پر 3 MB کی مصنوعی app-level پابندی ہٹا دی گئی ہے۔ تصاویر JPEG میں resize/compress ہوتی ہیں؛ PDF اپنی اصل شکل میں محفوظ ہوتی ہے۔ فون کی RAM، دستیاب اسٹوریج اور WebView کی حدود پھر بھی لاگو رہتی ہیں۔

پروجیکٹ میں پہلے سے موجود خصوصیات: پارٹی Contacts picker، بل/WhatsApp sharing، پارٹی sort/delete confirmation، previous due transfer، reports/dashboard، product multi-image compression، backup/restore، local WhatsApp catalog اور local order register۔

اہم: یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور حقیقی فون ٹیسٹ دستیاب نہیں تھے، اس لیے اسے device-tested یا مکمل production-verified نہیں کہا جا سکتا۔ پہلے backup لیں، پرانی APK uninstall نہ کریں، اور GitHub Actions سے build کرکے APK install test کریں۔

بغیر سرور/ہوسٹنگ کے مستقل public web store، WhatsApp Business Catalog کی خودکار cloud sync، اور remote customer orders کی app میں خودکار push notification ممکن نہیں؛ اس ورژن میں local catalog + WhatsApp share + manual order entry ہے۔


نئی کیٹلاگ اپ ڈیٹ:
- مشترکہ دکھانے/چھپانے کی سیٹنگ کے لیے Apply to All۔
- ہر آئٹم کے لیے الگ نام، تفصیل، کیٹلاگ قیمت، کیٹلاگ اسٹاک اور دستیابی۔
- کیٹلاگ کی اپنی تبدیلیاں اصل بلنگ/انوینٹری کے ڈیٹا کو تبدیل نہیں کرتیں۔
- منتخب آئٹمز کی ڈیفالٹ حالت غیر منتخب ہے؛ ایک یا تمام آئٹمز منتخب کیے جا سکتے ہیں۔
- ہر منتخب پروڈکٹ کی تصویر کے اندر اسی پروڈکٹ کا نام/تفصیل/قیمت/اسٹاک کارڈ کی صورت میں شامل کیا جاتا ہے، تاکہ متعدد تصاویر شیئر ہونے پر شناخت واضح رہے۔
- کیٹلاگ کی انفرادی سیٹنگز مکمل بیک اپ اور ریسٹور میں بھی شامل ہیں۔

نوٹ: WhatsApp پر تصاویر کی وصولی/ترتیب WhatsApp اور فون کے شیئر مینو کے مطابق ہو سکتی ہے۔ اس ورژن کا Android APK ابھی حقیقی ڈیوائس پر ٹیسٹ ہونا باقی ہے۔
