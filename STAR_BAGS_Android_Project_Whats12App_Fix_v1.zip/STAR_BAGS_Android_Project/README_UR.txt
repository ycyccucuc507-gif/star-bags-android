STAR BAGS Android Project — Version 1.3 (15 requirements update)

یہ Android Studio کا مکمل سورس پروجیکٹ ہے۔ موجودہ HTML billing app کو Android WebView میں چلایا جاتا ہے۔

اس ورژن میں شامل/درست کیے گئے اہم کام:
1) WhatsApp intent:// اور wa.me لنکس کو Android native routing کے ذریعے کھولنا؛ پہلے WhatsApp Business، پھر عام WhatsApp۔
2) بل بننے پر خودکار محفوظ کاری؛ موجودہ ریکارڈ میں ترمیم ہو تو اسی بل کو اپ ڈیٹ کرنا۔
3) بل کی PNG تصویر تیار کرنا اور اصل تصویر کو WhatsApp share intent کے ساتھ منسلک کرنا۔
4) Save، Print/PDF اور Send کے بٹن؛ Thermal/A4 پرنٹ کے موجودہ اختیارات برقرار۔
5) پارٹی کے محفوظ فون نمبر کو WhatsApp share میں استعمال کرنے کی کوشش۔
6) موجودہ STAR BAGS لوگو اور کمپنی نام محفوظ؛ Splash پر صرف STAR BAGS نام (STAR BAG HOUSE نہیں)۔
7) تین لائنوں والا مینیو اور نیوی بلیو ہیڈر/status bar۔
8) Native splash screen۔
9) مینیو Refresh: Home پر واپس؛ Backup/Utility میں Refresh Records بٹن بھی شامل۔
10) Pull-to-refresh: نیچے کھینچنے پر Home؛ فارم اور اندرونی اسکرول کے gestures کے لیے touch guard۔
11) Android Back navigation: کھلے ہوئے modules سے ایک ایک قدم پیچھے؛ Home پر Back سے ایپ بند۔
12) Full JSON backup میں bills, products, parties, purchases, payments, expenses, labor, recycle bin, costing ledger اور app settings شامل۔
13) Android 10+ پر Downloads/STAR BAGS میں backup محفوظ؛ ناکامی کی صورت میں Save As picker؛ پرانے Android پر بھی Save As۔
14) Backup restore، موجودہ data structure اور اضافی ledgers سمیت برقرار۔
15) GitHub Actions workflow Gradle 8.9، Java 17، Android SDK 35 کے ساتھ debug APK بناتا ہے۔

Backup کے بارے میں:
- بیک اپ بٹن اب Android bridge کے ذریعے JSON فائل محفوظ کرتا ہے۔ Android 10+ میں فائل Downloads/STAR BAGS فولڈر میں جاتی ہے۔
- اگر فون کا Downloads provider دستیاب نہ ہو تو Android Save As picker کھلے گا۔
- Restore کرنے سے پہلے موجودہ ڈیٹا کی الگ backup فائل ضرور بنا لیں۔

GitHub پر اپلوڈ:
1) ZIP کو Extract کریں۔
2) Repository کے root میں STAR_BAGS_Android_Project فولڈر اور .github/workflows/build-apk.yml اپلوڈ کریں۔
3) پرانا .github/workflows/main.yml اگر موجود ہو تو اسے حذف کریں تاکہ دو workflows ایک ساتھ نہ چلیں۔
4) GitHub → Actions → Build STAR BAGS APK → Run workflow۔
5) کامیاب build کے بعد STAR-BAGS-APK artifact سے app-debug.apk حاصل کریں۔

اہم احتیاط اور ٹیسٹنگ:
- نئی APK انسٹال کرنے سے پہلے موجودہ ایپ سے Full Backup JSON بنائیں۔
- اگر signing key مختلف ہو تو نئی APK پرانی ایپ کے اوپر update نہیں ہوگی؛ پرانی ایپ uninstall کرنے سے پہلے signing key اور backup کی تصدیق کریں۔
- WhatsApp آخری Send صارف کے ہاتھ میں رکھتا ہے؛ ایپ خودکار طور پر پیغام نہیں بھیجتی۔ WhatsApp کے ورژن کے مطابق chat picker آ سکتا ہے۔
- اس ماحول میں Android SDK/Gradle دستیاب نہیں، اس لیے یہاں APK build یا فون پر runtime test ممکن نہیں ہوا۔ HTML کے تمام inline JavaScript بلاکس `node --check` سے syntax-checked ہیں؛ GitHub Actions build اور اصل موبائل پر عملی ٹیسٹ لازمی ہیں۔


اپ ڈیٹ v1.4 (2026-11-05): STAR BAGS لوگو سے Android launcher icon شامل کیا گیا ہے۔ Pull-to-refresh اب Home پر جانے کے ساتھ موجودہ غیر محفوظ بل فارم اور preview بھی صاف کرتا ہے؛ محفوظ بل/ریکارڈ حذف نہیں ہوتے۔
اہم: پارٹی لیجر میں پرانے بقایا اور وصولیوں کا مکمل transaction-based حساب، ادائیگی کی علیحدہ تاریخ، بل attachment اور باقی نئی درخواستوں کی مکمل implementation اس پیکج میں شامل/مصدقہ نہیں؛ اسے مکمل فیچر اپ ڈیٹ نہ سمجھیں۔
