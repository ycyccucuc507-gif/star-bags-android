STAR BAGS V6.3 — Catalog + WhatsApp Order Auto Fill

اہم سیٹنگز:
- Firebase URL: https://starbags-shop-default-rtdb.firebaseio.com
- Shop ID: starbags-7265
- Catalog Website URL: https://starbags-123.netlify.app
- WhatsApp نمبر اور آرڈر الفاظ: ایپ کی Settings میں محفوظ رکھیں۔

نیا آرڈر طریقہ:
1. گاہک کیٹلاگ میں ہر مطلوبہ بیگ کی تعداد درج کرتا ہے۔
2. WhatsApp آرڈر سے پہلے نام اور موبائل نمبر درج کرتا ہے۔
3. WhatsApp پیغام میں ہر آئٹم الگ لائن میں پروڈکٹ نام × مقدار = لائن ٹوٹل کے ساتھ جاتا ہے۔
4. STAR BAGS ایپ میں WhatsApp Notification Access فعال ہو تو آرڈر Inbox میں آتا ہے۔
5. آرڈر کھول کر Auto Fill دبائیں۔ پارٹی، فون اور تمام شناخت شدہ آئٹمز/مقدار/ریٹ بل شیٹ میں بھرتے ہیں۔
6. Next دبائیں، سابقہ بقایا دیکھیں، پھر بل تیار کریں اور چیک کرکے محفوظ کریں۔

اہم: نئے Catalog Website checkout fields کے لیے catalog_web/index.html کو Netlify پر دوبارہ deploy کریں۔ نئے Android code کے لیے اسی Package ID اور signing key سے APK build/install کریں؛ پرانی ایپ uninstall یا Clear Data نہ کریں۔

جانچ: JavaScript syntax اور multi-item parser sample پاس؛ Android Gradle build، حقیقی فون، WhatsApp notification، Firebase اور printer کا live test باقی ہے۔
