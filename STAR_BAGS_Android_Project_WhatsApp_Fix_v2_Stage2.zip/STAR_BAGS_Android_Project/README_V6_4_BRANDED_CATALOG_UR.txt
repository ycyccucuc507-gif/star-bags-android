STAR BAGS Android V6.4 — Branded Catalog

- Catalog publishing now shares the short site root URL rather than Firebase query parameters.
- Catalog site URL remains configurable in Settings; default is https://starbags-123.netlify.app
- Catalog website includes embedded Firebase database/shop defaults matching the supplied store configuration.
- Original STAR BAGS logo is used in the catalog header and social preview metadata.

Important: deploy the matching Catalog V4 files to Netlify. Build APK with the same applicationId and signing key to update the existing app without clearing its data.
