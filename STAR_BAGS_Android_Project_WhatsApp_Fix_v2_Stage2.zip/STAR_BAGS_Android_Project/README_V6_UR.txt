STAR BAGS V6 — سمارٹ اپ گریڈ
نیا کوڈ app/src/main/assets/sb/ فولڈر میں الگ ماڈیولز میں ہے (core, security, ui, features, sync)۔
پرانی index.html وہیں ہے؛ لوگو تین بار کے بجائے ایک بار (sb-logo.js) رکھا گیا۔
ضروری: یہ ماحول Android Studio نہیں چلا سکتا، اس لیے Java حصہ (MainActivity، WhatsAppOrderListener، zxing) کمپائل/ٹیسٹ نہیں ہوا۔
Android Studio میں Sync اور Build کر کے اصل فون اور پرنٹر پر ٹیسٹ کریں۔
catalog_web فولڈر کسی مفت ہوسٹنگ پر رکھیں: index.html?u=<Firebase لنک>&s=<دکان ID>
