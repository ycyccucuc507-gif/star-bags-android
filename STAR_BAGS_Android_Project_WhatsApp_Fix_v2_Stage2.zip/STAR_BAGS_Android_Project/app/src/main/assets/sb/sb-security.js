/* STAR BAGS V6 — PIN / fingerprint lock, owner & employee roles, auto-lock */
(function(){'use strict';var SB=window.SB;
var st=SB.settings();
if(st.pinEnabled&&st.pinHash&&!sessionStorage.getItem('sb_unlocked'))document.documentElement.classList.add('sb-locked');
function applyRole(){document.body&&document.body.classList.toggle('sb-employee',SB.role()==='employee')}
SB.applyRole=applyRole;
function hashPin(p,salt){return SB.sha256(salt+'|'+p+'|starbags')}
SB.setPin=function(kind,pin){var s=SB.settings();var salt=s.salt||(Math.random().toString(36).slice(2)+Date.now().toString(36));
 if(kind==='owner')SB.save({salt:salt,pinHash:hashPin(pin,salt),pinEnabled:true});else SB.save({salt:salt,empPinHash:hashPin(pin,salt)})};
SB.disablePin=function(){SB.save({pinEnabled:false,pinHash:'',empPinHash:'',bio:false});sessionStorage.removeItem('sb_unlocked');document.documentElement.classList.remove('sb-locked')};
SB.checkPin=function(p){var s=SB.settings();if(!s.pinHash)return null;var h=hashPin(p,s.salt);if(h===s.pinHash)return'owner';if(s.empPinHash&&h===s.empPinHash)return'employee';return null};
var fails=0,lockUntil=0;
function build(){if(document.getElementById('sbLock'))return;var d=document.createElement('div');d.id='sbLock';
 d.innerHTML='<div class="sb-lock-card"><div class="sb-lock-logo">⭐</div><h2>STAR BAGS</h2><p id="sbLockMsg">اپنا PIN درج کریں</p><div id="sbDots"><i></i><i></i><i></i><i></i></div><div id="sbPad"></div><button type="button" id="sbBioBtn" class="sb-bio">👆 فنگر پرنٹ / فون لاک سے کھولیں</button></div>';
 document.body.appendChild(d);var pad=d.querySelector('#sbPad'),val='';
 ['1','2','3','4','5','6','7','8','9','⌫','0','✓'].forEach(function(k){var b=document.createElement('button');b.type='button';b.textContent=k;b.onclick=function(){press(k)};pad.appendChild(b)});
 function dots(){d.querySelectorAll('#sbDots i').forEach(function(x,i){x.className=i<val.length?'on':''})}
 function press(k){if(Date.now()<lockUntil){msg('کچھ دیر بعد کوشش کریں ('+Math.ceil((lockUntil-Date.now())/1000)+' سیکنڈ)');return}
  if(k==='⌫'){val=val.slice(0,-1)}else if(k==='✓'){try_()}else if(val.length<8){val+=k;if(val.length>=4&&val.length===4)setTimeout(function(){if(val.length===4)try_()},180)}dots()}
 function msg(t){d.querySelector('#sbLockMsg').textContent=t}
 function try_(){var r=SB.checkPin(val);if(r){fails=0;unlock(r)}else{fails++;val='';dots();d.classList.add('shake');setTimeout(function(){d.classList.remove('shake')},400);if(fails>=5){lockUntil=Date.now()+30000;fails=0;msg('بہت زیادہ غلط PIN — 30 سیکنڈ انتظار')}else msg('غلط PIN، دوبارہ کوشش کریں')}}
 function unlock(role){sessionStorage.setItem('sb_unlocked','1');sessionStorage.setItem('sb_role',role);document.documentElement.classList.remove('sb-locked');d.style.display='none';val='';dots();msg('اپنا PIN درج کریں');applyRole();window.dispatchEvent(new Event('sb-unlocked'))}
 SB._unlock=unlock;
 var bb=d.querySelector('#sbBioBtn');var n=SB.native();if(!(n&&n.authenticateDevice)||!SB.settings().bio)bb.style.display='none';
 bb.onclick=function(){window.sbBioResult=function(ok){if(ok)unlock('owner');else msg('تصدیق نہیں ہو سکی')};try{n.authenticateDevice('sbBioResult')}catch(e){msg('فنگر پرنٹ دستیاب نہیں')}};
 SB.showLock=function(){sessionStorage.removeItem('sb_unlocked');sessionStorage.removeItem('sb_role');d.style.display='flex';document.documentElement.classList.add('sb-locked');val='';dots();var s=SB.settings();var b=d.querySelector('#sbBioBtn');b.style.display=(n&&n.authenticateDevice&&s.bio)?'':'none'};
 if(!(SB.settings().pinEnabled&&SB.settings().pinHash&&!sessionStorage.getItem('sb_unlocked')))d.style.display='none';
 else if(SB.settings().bio&&n&&n.authenticateDevice)setTimeout(function(){bb.click()},400)}
document.addEventListener('DOMContentLoaded',function(){build();applyRole()});
/* auto-lock after inactivity or after the app stays in the background */
var last=Date.now(),hiddenAt=0;
['click','touchstart','keydown'].forEach(function(ev){document.addEventListener(ev,function(){last=Date.now()},true)});
setInterval(function(){var s=SB.settings();if(s.pinEnabled&&s.pinHash&&s.autoLockMin>0&&sessionStorage.getItem('sb_unlocked')&&Date.now()-last>s.autoLockMin*60000&&SB.showLock)SB.showLock()},15000);
document.addEventListener('visibilitychange',function(){var s=SB.settings();if(document.hidden)hiddenAt=Date.now();else if(s.pinEnabled&&s.pinHash&&s.autoLockMin>0&&hiddenAt&&Date.now()-hiddenAt>s.autoLockMin*60000&&SB.showLock)SB.showLock()});
})();
