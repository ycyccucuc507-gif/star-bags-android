/* STAR BAGS V7 — WhatsApp / online orders: auto-fill bill, smart party matching, separate "online business" section.
   Online bills are ordinary bills (tagged channel:'online'), so accounts, stock, profit/loss and backups stay exactly as before. */
(function(){'use strict';var SB=window.SB,$=function(id){return document.getElementById(id)},E=SB.esc,M=SB.money;
var INBOX='starbags_wa_inbox_v1',ALIAS='starbags_wa_alias_v1',DELIV='starbags_online_delivery_v1',BILLS='starbags_bills_v2',PARTIES='starbags_parties_v1';
function last10(s){var d=String(s==null?'':s).replace(/\D/g,'');return d.length>=10?d.slice(-10):''}
function cleanFrom(s){return String(s||'').replace(/\s*\(\d+\s*[^)]*\)\s*$/,'').trim()}
function latin(s){return String(s||'').replace(/[۰-۹]/g,function(c){return'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)}).replace(/[٠-٩]/g,function(c){return'٠١٢٣٤٥٦٧٨٩'.indexOf(c)})}
function parties(){return SB.jget(PARTIES,[])}
function products(){return SB.jget('starbags_products_v2',[])}

/* ---------- read the order text ---------- */
function parseOrder(text){var o={name:'',phone:'',items:[]},last='';
 latin(text).split(/\r?\n/).forEach(function(l){l=l.trim().replace(/^\*(.+)\*$/,'$1').trim();if(!l)return;var m;
  if(!/[A-Za-z؀-ۿ0-9]/.test(l))return;
  if((m=l.match(/^(?:نام|name)\s*[:：]\s*(.+)$/i))){o.name=m[1].trim();return}
  if((m=l.match(/^(?:فون|نمبر|phone|mobile|contact)\s*[:：]\s*(.+)$/i))){o.phone=m[1].trim();return}
  if(/^(?:آرڈر|order)\s*[:：]?\s*$/i.test(l)||/^[^\w؀-ۿ]*(?:آرڈر|order)\s*[:：]?\s*$/i.test(l)||/^(?:کل\s*بل|کل|total|grand\s*total|مجموعہ)\s*[:：=\-]/i.test(l)||/^(?:کل|total)\s+(?:rs\.?\s*)?[\d,]+\s*$/i.test(l)||/^(?:شکریہ|thanks|thank you)/i.test(l))return;
  var nm=null,q=0;
  /* two-line format:  "<item name>"  then  "20 × 265 = Rs. 5,300"  */
  if(last&&(m=l.match(/^(\d+(?:\.\d+)?)\s*[×x*]\s*(?:rs\.?\s*)?[\d,\.]+\s*(?:=\s*(?:rs\.?\s*)?[\d,\.]+)?\s*$/i))){o.items.push({raw:last+' '+l,name:last,qty:+m[1]});last='';return}
  if((m=l.match(/^(.+?)\s*[×*]\s*(\d+)\b/))||(m=l.match(/^(.+?)\s+x\s*(\d+)\b/i))){nm=m[1];q=+m[2]}
  else if((m=l.match(/^(.+?)\s*[-:=]\s*(\d+)\s*(?:پیس|pcs?|عدد|piece)?\s*$/i))){nm=m[1];q=+m[2]}
  else if((m=l.match(/^(.+?)\s+(\d+)\s*(?:پیس|pcs?|عدد|piece)?\s*$/i))){nm=m[1];q=+m[2]}
  else if((m=l.match(/^(\d+)\s*(?:پیس|pcs?|عدد|piece)?\s+(.+)$/i))){q=+m[1];nm=m[2]}
  if(nm&&q>0){o.items.push({raw:l,name:nm.trim(),qty:q});last=''}else last=l});
 return o}
function matchProduct(name){var n=SB.norm(name);if(!n)return null;var best=null,sc=0;
 products().forEach(function(p){var pn=SB.norm(p.name),kw=SB.norm(p.keyword||''),s=0;
  if(pn===n||(kw&&kw===n))s=100;else if(pn&&(pn.indexOf(n)>=0||n.indexOf(pn)>=0))s=80;
  else{var a=n.split(' '),b=pn.split(' '),c=0;a.forEach(function(w){if(w.length>1&&b.indexOf(w)>=0)c++});s=c?60*c/Math.max(a.length,b.length):0}
  if(s>sc){sc=s;best=p}});
 return sc>=50?best:null}

/* ---------- which party is this? phone first, then remembered link, then exact name ---------- */
function findParty(from,o,hint){var ps=parties(),ph=[last10(hint),last10(from),last10(o.phone)].filter(Boolean),p;
 if(ph.length){p=ps.filter(function(x){var l=last10(x.phone);return l&&ph.indexOf(l)>=0})[0];if(p)return{p:p,by:'نمبر سے'}}
 var al=SB.jget(ALIAS,{}),keys=[SB.norm(from),SB.norm(o.name)].filter(Boolean);
 for(var i=0;i<keys.length;i++){var an=al[keys[i]];if(an){p=ps.filter(function(x){return SB.norm(x.name)===SB.norm(an)})[0];if(p)return{p:p,by:'پہلے جوڑا ہوا'}}}
 for(var j=0;j<keys.length;j++){p=ps.filter(function(x){return SB.norm(x.name)===keys[j]})[0];if(p)return{p:p,by:'نام سے'}}
 return null}
function rememberParty(from,o,name){var al=SB.jget(ALIAS,{});if(SB.norm(from))al[SB.norm(from)]=name;if(SB.norm(o.name))al[SB.norm(o.name)]=name;SB.jset(ALIAS,al);
 var phone=o.phone||(last10(from)?from:''),ps=parties(),p=ps.filter(function(x){return SB.norm(x.name)===SB.norm(name)})[0];
 if(p){if(phone&&!p.phone){p.phone=phone}}else{ps.unshift({id:Date.now(),name:name,phone:phone,address:'',rates:{},laborEnabled:false})}
 SB.jset(PARTIES,ps);try{window.SBX.renderParties()}catch(e){}}
function linkAlias(from,o,name){try{var al=SB.jget(ALIAS,{});if(SB.norm(from))al[SB.norm(from)]=name;if(SB.norm(o.name))al[SB.norm(o.name)]=name;SB.jset(ALIAS,al)}catch(e){}}
function askParty(from,o,cb){var old=$('sbPartyAsk');if(old)old.remove();var names=parties().map(function(p){return p.name}).sort(),guess=o.name||from;
 var d=document.createElement('div');d.id='sbPartyAsk';d.style.cssText='position:fixed;left:0;right:0;top:0;bottom:0;background:#0008;z-index:99999;display:flex;align-items:center;justify-content:center;padding:14px';
 d.innerHTML='<div style="background:#fff;border-radius:14px;padding:16px;max-width:430px;width:100%;direction:rtl;max-height:90vh;overflow:auto"><h3 style="margin:0 0 8px">یہ پارٹی ایپ میں نہیں ملی</h3><p style="margin:0 0 10px">WhatsApp پر نام/نمبر: <b dir="ltr">'+E(from)+'</b></p><label>اگر یہ پہلے سے آپ کی پارٹی ہے تو اس کا (اردو) نام منتخب کریں:</label><select id="sbPaSel" style="width:100%;margin:6px 0 12px"><option value="">— نئی پارٹی —</option>'+names.map(function(n){return'<option>'+E(n)+'</option>'}).join('')+'</select><label>یا نئی پارٹی کا نام:</label><input id="sbPaNew" value="'+E(guess)+'" style="width:100%;margin:6px 0 12px"><div class="buttons"><button type="button" id="sbPaOk">جاری رکھیں</button><button type="button" class="outline" id="sbPaNo">منسوخ</button></div><p class="hint">یہ جوڑ یاد رہے گا؛ اگلی بار یہ پارٹی خود بخود اسی نام سے کھلے گی۔</p></div>';
 document.body.appendChild(d);
 $('sbPaNo').onclick=function(){d.remove()};
 $('sbPaOk').onclick=function(){var name=($('sbPaSel').value||$('sbPaNew').value||'').trim();if(!name){alert('نام لکھیں یا منتخب کریں');return}d.remove();rememberParty(from,o,name);cb(name)}}

/* ---------- ⚡ auto-fill the bill ---------- */
function formDirty(){var party=$('party')&&$('party').value.trim();var q=[].some.call(document.querySelectorAll('#saleRows .sheet-qty'),function(x){return Number(x.value)>0});return !!(party||q)}
SB.autoFill=function(id){var m=SB.jget(INBOX,[]).filter(function(x){return x.id===id})[0];if(!m)return;
 var from=cleanFrom(m.from),o=parseOrder(m.text),f=findParty(from,o,m.phone),ph=last10(m.phone)||last10(from)||last10(o.phone);
 if(f){linkAlias(from,o,f.p.name);go(f.p.name)}
 else if(ph){/* brand-new number: add as a new party automatically */var nm=(from&&!last10(from)?from:'')||o.name||('WhatsApp '+ph);o.phone=m.phone||o.phone||ph;rememberParty(from,o,nm);SB.toast('🆕 نئی پارٹی بنا دی گئی: '+nm,4000);go(nm)}
 else askParty(from,o,go);
 function go(name){
  if(formDirty()&&!confirm('موجودہ ادھورا بل صاف ہو جائے گا اور اس آرڈر سے نیا بل بھرا جائے گا۔ جاری رکھیں؟'))return;
  var home=document.querySelector('#mainMenu [data-module="home"]');if(home)home.click();else if(window.showModule)window.showModule('home');
  window.SBX.fresh();$('party').value=name;['input','change'].forEach(function(ev){$('party').dispatchEvent(new Event(ev,{bubbles:true}))});
  try{$('billNo').value=window.SBX.nextNo()}catch(e){}
  $('note').value='آن لائن / WhatsApp آرڈر';
  SB.pendingOnline={id:m.id,from:from,party:name};
  var miss=[];$('saleRows').innerHTML='';
  o.items.forEach(function(it){var p=matchProduct(it.name);if(!p){miss.push(it.raw);return}
   var srcs=[];try{srcs=window.SBX.sources(p.name).filter(function(x){return Number(x.stock)>0})}catch(e){}
   var src=srcs.length===1?srcs[0].source:'';window.SBX.addRow(p.id,src,it.qty,window.SBX.rate(p,src))});
  if(!$('saleRows').children.length)window.SBX.addRow();
  window.scrollTo(0,0);
  if(miss.length||!o.items.length){alert((o.items.length?'یہ لائنیں آپ کے آئٹمز میں نہیں ملیں:\n\n'+miss.join('\n')+'\n\nباقی آئٹمز بھر دیے ہیں۔ اوپر/نیچے سے یہ آئٹم خود منتخب کریں، پھر "اگلا" دبائیں۔':'پیغام میں آئٹم کی لائنیں نہیں ملیں۔ پارٹی بھر دی ہے؛ آئٹمز خود منتخب کریں۔'));return}
  window.SBX.nextOrBill();
  var due=0;try{due=window.SBX.due(name)}catch(e){}
  SB.toast('✅ '+name+' — آئٹمز بھر گئے'+(due>0?' — پچھلا بقایا Rs. '+M(due):''),5000)}};

/* link the order to the saved bill */
/* tag the bill as online when it was made from an order (only if the party on the bill is still that order's party) */
window.SBX.hookRender(function(b){var po=SB.pendingOnline;if(po&&b&&!window.SBX.editing()&&SB.norm(b.party)===SB.norm(po.party)&&!SB.jget(BILLS,[]).some(function(x){return String(x.id)===String(b.id)})){b.channel='online';b.waId=po.id;b.waFrom=po.from}});
SB.onBillsChange=function(arr){try{var box=SB.jget(INBOX,[]),ch=false;arr.forEach(function(b){if(b.channel==='online'&&b.waId){var m=box.filter(function(x){return x.id===b.waId})[0];if(m&&m.billId!==b.id){m.billId=b.id;m.billNo=b.no;if(m.status!=='delivered')m.status='billed';ch=true}}});if(ch)SB.jset(INBOX,box);if(SB.pendingOnline&&arr.some(function(b){return b.waId===SB.pendingOnline.id}))SB.pendingOnline=null}catch(e){}};

/* ---------- online business numbers (same formulas as the app's profit & loss) ---------- */
function money(b){var items=b.items||[],amt=0,cost=0,ret=0;items.forEach(function(i){amt+=Number(i.amount||0);cost+=(i.cost!=null?Number(i.cost):Number(i.qty||0)*Number(i.buy||0))});
 (Array.isArray(b.returns)?b.returns:[]).forEach(function(r){ret+=Number(r.amount||Number(r.qty||0)*Number(r.rate||0))});
 var sale=amt+Number(b.laborCharge||0)-ret,profit=amt-cost+Number(b.laborPieces||0)*25-ret-Number(b.writeOff||0);return{sale:sale,cost:cost,profit:profit,paid:Number(b.paid||0)}}
var period='month';
function inPeriod(d){d=String(d||'');if(period==='today')return d===SB.today();if(period==='month')return d.slice(0,7)===SB.today().slice(0,7);return true}

SB.modules.sborders=function(){SB.pullWa();var el=$('module-sborders'),box=SB.jget(INBOX,[]),dl=SB.jget(DELIV,{}),so=SB.jget('starbags_store_orders_v1',[]);
 var ob=SB.jget(BILLS,[]).filter(function(b){return b.channel==='online'&&inPeriod(b.date)}).sort(function(a,b){return String(b.date).localeCompare(String(a.date))||Number(b.id)-Number(a.id)});
 var t={sale:0,cost:0,profit:0,paid:0,deliv:0};ob.forEach(function(b){var x=money(b);t.sale+=x.sale;t.cost+=x.cost;t.profit+=x.profit;t.paid+=x.paid;if(dl[b.id])t.deliv++});
 var h='<h2>📥 آرڈرز / آن لائن کاروبار</h2><div class="field"><select id="onPeriod"><option value="today"'+(period==='today'?' selected':'')+'>آج</option><option value="month"'+(period==='month'?' selected':'')+'>اس مہینے</option><option value="all"'+(period==='all'?' selected':'')+'>تمام</option></select></div>'+
 '<div class="moneybox"><div class="moneyline"><span>آن لائن بل</span><strong>'+ob.length+'</strong></div><div class="moneyline"><span>ڈلیور ہو گئے / باقی</span><strong>'+t.deliv+' / '+(ob.length-t.deliv)+'</strong></div><div class="moneyline"><span>آن لائن فروخت</span><strong>Rs. '+M(t.sale)+'</strong></div><div class="moneyline"><span>لاگت</span><strong>Rs. '+M(t.cost)+'</strong></div><div class="moneyline"><span>وصول شدہ</span><strong>Rs. '+M(t.paid)+'</strong></div><div class="moneyline"><span>اندازاً '+(t.profit<0?'نقصان':'منافع')+'</span><strong class="'+(t.profit>=0?'good':'due')+'">Rs. '+M(Math.abs(t.profit))+'</strong></div></div><p class="hint">یہ بل عام سیل بل ہی ہیں — ایپ کے کھاتے، اسٹاک اور پرافٹ اینڈ لاس میں پہلے کی طرح شامل رہتے ہیں؛ یہاں صرف آن لائن کا الگ حساب نظر آتا ہے۔</p>';
 h+='<h4>🧾 آن لائن بل</h4>'+(ob.length?ob.slice(0,40).map(function(b){var x=money(b),d=dl[b.id];return'<div class="sb-card"><b>#'+E(b.no)+'</b> '+E(b.party||'—')+' <span class="sb-chip">'+E(b.date)+'</span> Rs. '+M(x.sale)+' <span class="sb-chip" style="background:'+(x.profit>=0?'#e3f5ea;color:#17673c':'#fde8e8;color:#a02020')+'">'+(x.profit<0?'نقصان ':'منافع ')+M(Math.abs(x.profit))+'</span> '+(d?'<span class="sb-chip" style="background:#e3f5ea;color:#17673c">🚚 ڈلیور ہو گیا</span>':'<span class="sb-chip" style="background:#fff3d6;color:#8a5a00">ڈلیوری باقی</span>')+'<div class="buttons"><button type="button" class="smallbtn'+(d?' outline':'')+'" data-o="deliv" data-bid="'+E(b.id)+'">'+(d?'↩ ڈلیوری واپس':'🚚 ڈلیور ہو گیا')+'</button></div></div>'}).join(''):'<p class="hint">اس مدت میں کوئی آن لائن بل نہیں۔</p>');
 h+='<h4>💬 WhatsApp پیغامات (آرڈر والے الفاظ پر)</h4>'+(box.length?box.slice(0,60).map(function(m){var from=cleanFrom(m.from),o=parseOrder(m.text),f=findParty(from,o,m.phone);
  var st=m.status==='new'?' <span class="sb-chip" style="background:#fde8e8;color:#a02020">نیا</span>':m.status==='billed'?' <span class="sb-chip" style="background:#e3f5ea;color:#17673c">🧾 بل #'+E(m.billNo||'')+'</span>':m.status==='delivered'?' <span class="sb-chip" style="background:#e3f5ea;color:#17673c">🚚 ڈلیور</span>':'';
  return'<div class="sb-card"><b>'+E(m.from)+'</b> <span class="sb-chip">'+E(new Date(m.t).toLocaleString('en-GB',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))+'</span>'+st+'<p style="white-space:pre-wrap">'+E(m.text)+'</p><p class="hint">'+(f?'پارٹی: <b>'+E(f.p.name)+'</b> ('+f.by+' مل گئی)':'نئی پارٹی — آٹو فل پر خود بن جائے گی')+' — '+o.items.length+' آئٹم لائنیں</p><div class="buttons"><button type="button" class="smallbtn" data-o="fill" data-id="'+E(m.id)+'">⚡ آٹو فل (بل تیار)</button><button type="button" class="outline smallbtn" data-o="done" data-id="'+E(m.id)+'">✔ مکمل</button><button type="button" class="outline smallbtn" data-o="del" data-id="'+E(m.id)+'">حذف</button></div></div>'}).join(''):'<p class="hint">ابھی کوئی پیغام نہیں۔ سیٹنگ ← WhatsApp آرڈر الرٹ میں رسائی دیں اور آرڈر کے الفاظ لکھیں۔</p>');
 h+='<h4>🛍️ اسٹور آرڈرز</h4>'+(so.length?'<p class="hint">'+so.length+' آرڈر محفوظ ہیں — مکمل تفصیل کے لیے ٹولز ← آن لائن اسٹور کھولیں۔</p>':'<p class="hint">کوئی اسٹور آرڈر نہیں۔</p>')+'<div class="buttons"><button type="button" class="secondary" id="ordToStore">🧰 آن لائن اسٹور کھولیں</button></div>';
 el.innerHTML=h;
 if(box.some(function(x){return x.status==='new'})){box.forEach(function(x){if(x.status==='new')x.status='seen'});SB.jset(INBOX,box);SB.alerts&&SB.alerts()}
 $('onPeriod').onchange=function(){period=this.value;SB.modules.sborders()};
 el.onclick=function(e){if(e.target.id==='ordToStore'){document.querySelector('#mainMenu [data-module="utility"]').click();return}var b=e.target.closest('[data-o]');if(!b)return;var k=b.dataset.o;
  if(k==='deliv'){var d=SB.jget(DELIV,{}),id=b.dataset.bid;if(d[id])delete d[id];else d[id]=new Date().toISOString();SB.jset(DELIV,d);
   var all=SB.jget(INBOX,[]);all.forEach(function(m){if(String(m.billId)===String(id))m.status=d[id]?'delivered':'billed'});SB.jset(INBOX,all);SB.modules.sborders();return}
  var all2=SB.jget(INBOX,[]),m=all2.filter(function(x){return x.id===b.dataset.id})[0];if(!m)return;
  if(k==='del'){SB.jset(INBOX,all2.filter(function(x){return x!==m}));SB.modules.sborders()}
  else if(k==='done'){m.status='done';SB.jset(INBOX,all2);SB.modules.sborders()}
  else if(k==='fill')SB.autoFill(m.id)}};
})();
