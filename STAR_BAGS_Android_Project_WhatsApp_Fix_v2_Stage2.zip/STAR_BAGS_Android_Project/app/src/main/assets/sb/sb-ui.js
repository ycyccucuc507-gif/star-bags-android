/* STAR BAGS V6 — header, 3-dot menu, settings page, bill-sheet helpers, attachments, alerts */
(function(){'use strict';var SB=window.SB,$=function(id){return document.getElementById(id)};
SB.modules=SB.modules||{};
function applyLook(){var s=SB.settings(),b=document.body;
 b.classList.toggle('sb-norate',!s.showRate);b.style.zoom=(s.fontScale||100)/100;
 document.documentElement.style.setProperty('--sb-thumb',(s.thumbSize||64)+'px');
 var img=document.querySelector('.app-header .brand-logo');if(img){img.style.width=img.style.height=(s.logoSize||40)+'px'}
 /* pertah columns: 3 = title+date+amount, 2 = title+amount (uses the app's own print-field switches) */
 try{var k='starbags_bill_print_settings_v1',v=JSON.parse(localStorage.getItem(k)||'{}');v.fields=v.fields||{};var want=(s.pertahCols!==2);if(v.fields.pertahDate!==want&&s._pcApplied!==s.pertahCols){v.fields.pertahDate=want;localStorage.setItem(k,JSON.stringify(v));SB.save({_pcApplied:s.pertahCols})}}catch(e){}}
SB.applyLook=applyLook;
/* ---------- header ---------- */
(function header(){var hdr=document.querySelector('.app-header');if(!hdr)return;
 var mb=$('mainMenuBtn');if(mb){mb.textContent='⋮';mb.title='مزید';mb.setAttribute('aria-label','مزید')}
 var g=document.createElement('button');g.id='sbSettingsBtn';g.type='button';g.textContent='⚙️';g.title='سیٹنگ';g.setAttribute('aria-label','سیٹنگ');hdr.appendChild(g);
 var on=document.createElement('div');on.id='sbOnline';document.body.appendChild(on);
 function net(){on.textContent=navigator.onLine?'● آن لائن':'● آف لائن (ڈیٹا فون میں محفوظ)';on.className=navigator.onLine?'':'off'}
 window.addEventListener('online',function(){net();window.dispatchEvent(new Event('sb-online'))});window.addEventListener('offline',net);net()})();
/* ---------- three-dot menu: app functions only (no settings here) ---------- */
(function menu(){var m=$('mainMenu');if(!m)return;var keep=m.querySelector('[data-action="refresh-home"]');
 var items=[['home','🏠 ہوم / سیل بل'],['today','📅 آج کا کاروبار'],['sales','🧾 تمام سیل بل'],['parties','👥 پارٹیز'],['sbstatement','📒 پارٹی کھاتہ / اسٹیٹمنٹ'],['-'],['reports','📊 رپورٹس'],['profitloss','📈 پرافٹ اینڈ لاس'],['sbsearch','🔍 تلاش اور فلٹر'],['-'],['catalog','🛍️ آئٹمز / ریٹس'],['inventory','📦 انوینٹری / اسٹاک'],['purchases','🧾 پرچیز / سپلائر حساب'],['labor','🧵 مزدوری اور خاندانی حساب'],['-'],['sborders','📥 آرڈرز (WhatsApp / آن لائن)'],['utility','🧰 پڑتا، ری سائیکل بن، آن لائن اسٹور'],['seasonplanner','📅 سیزن پلانر'],['-'],['sbexport','📤 PDF / Excel ایکسپورٹ'],['sbaudit','🕘 ایکٹیویٹی لاگ']];
 m.innerHTML='';if(keep)m.appendChild(keep);
 items.forEach(function(it){if(it[0]==='-'){m.appendChild(document.createElement('hr'));return}var b=document.createElement('button');b.type='button';b.setAttribute('data-module',it[0]);b.innerHTML=it[1]+(it[0]==='sborders'?' <span class="sb-badge" id="sbOrdBadge" style="display:none"></span>':'');m.appendChild(b)});
 document.addEventListener('click',function(e){if(!e.target.closest('.menu-wrap'))m.classList.remove('open')})})();
/* custom modules + hook so they render when opened */
(function mods(){var main=document.querySelector('main');var footer=main&&main.querySelector('footer');
 ['sbstatement','sbsearch','sbexport','sbaudit','sborders'].forEach(function(n){if($('module-'+n))return;var s=document.createElement('section');s.className='panel module';s.id='module-'+n;if(footer)main.insertBefore(s,footer);else main.appendChild(s)});
 var old=window.starBagsOnModuleChange;window.starBagsOnModuleChange=function(n){if(typeof old==='function')try{old(n)}catch(e){}var r=SB.modules[n];if(r)setTimeout(function(){try{r()}catch(e){console.error(e)}},0)}})();
/* ---------- settings page ---------- */
var SBOX;
function sw(key,label,hint){var s=SB.settings();return'<div class="sb-row"><div>'+label+(hint?'<small>'+hint+'</small>':'')+'</div><label class="sb-sw"><input type="checkbox" data-sk="'+key+'" '+(s[key]?'checked':'')+'><span></span></label></div>'}
function num(key,label,hint,min,max,step){var s=SB.settings();return'<div class="sb-row"><div>'+label+(hint?'<small>'+hint+'</small>':'')+'</div><input type="number" data-sk="'+key+'" data-t="num" min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+SB.esc(s[key])+'"></div>'}
function txt(key,label,hint,ph,type){var s=SB.settings();return'<div class="sb-row"><div>'+label+(hint?'<small>'+hint+'</small>':'')+'</div><input type="'+(type||'text')+'" data-sk="'+key+'" data-t="txt" placeholder="'+(ph||'')+'" value="'+SB.esc(s[key])+'"></div>'}
function sel(key,label,opts,hint){var s=SB.settings();return'<div class="sb-row"><div>'+label+(hint?'<small>'+hint+'</small>':'')+'</div><select data-sk="'+key+'" data-t="selnum">'+opts.map(function(o){return'<option value="'+o[0]+'" '+(String(s[key])===String(o[0])?'selected':'')+'>'+o[1]+'</option>'}).join('')+'</select></div>'}
function btn(act,label,cls){return'<button type="button" class="'+(cls||'secondary')+'" data-sa="'+act+'">'+label+'</button>'}
function build(){if($('sbSettings'))return;var d=document.createElement('div');d.id='sbSettings';
 d.innerHTML='<div class="sb-sbar"><b>⚙️ سیٹنگ</b><button type="button" id="sbSetClose">✕ بند کریں</button></div><div class="sb-sbody">'+
 '<details open><summary>🏷️ عمومی</summary><div class="sb-sec" id="sbS_general">'+num('fontScale','ایپ کی لکھائی کا سائز (%)','80 سے 130','80','130','5')+num('logoSize','ہیڈر لوگو کا سائز (px)','','24','80','2')+'</div></details>'+
 '<details><summary>🔐 سیکیورٹی</summary><div class="sb-sec" id="sbS_sec"></div></details>'+
 '<details><summary>🧾 بل اور پرنٹ کا مواد</summary><div class="sb-sec" id="sbS_bill">'+
   sw('hideRs','بل پر رقم کے ساتھ "Rs" لکھیں','بند کریں تو صرف عدد چھپے گا (پیش منظر اور پرنٹ)')+sw('gstOn','ٹیکس / GST کی لائن بل پر شامل کریں','ٹیکس شامل قیمت (inclusive) کی معلومات')+num('gstPct','GST فیصد','','0','40','0.5')+txt('gstNo','GST / NTN نمبر','','NTN')+
   sw('showRate','بل شیٹ میں ریٹ کا خانہ دکھائیں','بند ہو تو صرف نام، تعداد اور ٹوٹل')+sw('creditWarn','پارٹی کی ادھار حد سے زیادہ پر خبردار کریں','حد پارٹی اسٹیٹمنٹ والے صفحے میں سیٹ ہوتی ہے')+sw('negStockWarn','اسٹاک کم / منفی ہونے پر بل بناتے وقت خبردار کریں','')+'<div id="sbS_billmoved"></div></div></details>'+
 '<details><summary>📒 پڑتا بل کی سیٹنگ</summary><div class="sb-sec" id="sbS_pertah">'+sel('pertahCols','پڑتا میں کالم',[[3,'3 کالم — نام، تاریخ، رقم'],[2,'2 کالم — نام، رقم']],'مزید خانے ہر پڑتا آئٹم کے آگے والے "بل میں دکھائیں" سے بند/کھولیں')+'</div></details>'+
 '<details><summary>🖨️ پرنٹنگ</summary><div class="sb-sec" id="sbS_print">'+num('printDelay','پرنٹ کی رفتار — ہر پٹی کے بعد وقفہ (ملی سیکنڈ)','کم = تیز۔ پرنٹر رک رک کر چلے یا لائنیں گم ہوں تو بڑھائیں (20 سے 200)','20','200','5')+'<div id="sbS_printmoved"></div></div></details>'+
 '<details><summary>💾 بیک اپ، کلاؤڈ اور سنک</summary><div class="sb-sec" id="sbS_backup">'+sw('autoBackup','خودکار بیک اپ (فون میں اور ہر تبدیلی کے بعد)','ایپ کا ڈیٹا صاف ہو جائے تو اگلی بار خود بحال ہو جائے گا')+'<p class="hint">بیک اپ کا وقفہ نیچے منٹ، گھنٹے یا دن منتخب کرکے مقرر کریں۔</p>'+ '<div class="sb-row"><div>شیڈول کی مقدار / یونٹ</div><div style="display:flex;gap:6px"><input id="sbBackupValue" type="number" min="1" value="30" style="width:85px"><select id="sbBackupUnit"><option value="minutes">منٹ</option><option value="hours">گھنٹے</option><option value="days">دن</option></select></div></div><div class="sb-btnrow"><button type="button" class="secondary" id="sbBackupApply">⏱️ شیڈول محفوظ کریں</button><button type="button" class="outline" id="sbBackupFolder">📁 بیک اپ فولڈر منتخب کریں</button></div><p class="hint" id="sbBackupStatus">WorkManager شیڈول کم از کم 15 منٹ کے وقفے سے چلتا ہے۔</p><div class="sb-row"><div>آخری بیک اپ<small id="sbLastBk"></small></div></div><div class="sb-btnrow">'+btn('export','⬇️ بیک اپ فائل بنائیں')+btn('import','⬆️ بیک اپ بحال کریں','outline')+'</div>'+
   '<h4 style="margin:12px 0 4px">☁️ آن لائن کلاؤڈ (Firebase Realtime Database)</h4><p class="hint">اپنا مفت Firebase پروجیکٹ بنا کر Realtime Database کا لنک اور (اختیاری) secret یہاں لکھیں۔ دو موبائل ایک ہی دکان ID سے ایک ہی ڈیٹا ضم کر سکتے ہیں۔</p>'+txt('cloudUrl','ڈیٹابیس لنک','https://xxxx.firebaseio.com','https://...')+txt('cloudSecret','Secret / Auth (اختیاری)','','','password')+txt('shopId','دکان ID','انگریزی/نمبر، مثلاً starbags1','starbags1')+txt('catalogBaseUrl','Catalog Website URL','آپ کی Netlify ویب سائٹ کا بنیادی لنک','https://starbags-123.netlify.app')+sw('cloudAuto','خودکار سنک (آن لائن ہوتے ہی)','')+sw('catalogAutoPublish','Public آئٹمز کیٹلاگ میں خودکار اپ ڈیٹ کریں','صرف Public منتخب آئٹمز اپ لوڈ ہوں گے؛ Firebase استعمال کے مطابق خرچ ہو سکتا ہے')+'<div class="sb-btnrow">'+btn('cloudUp','☁️ اپ لوڈ')+btn('cloudMerge','🔄 ڈاؤن لوڈ اور ضم کریں')+btn('cloudCatalog','🛍️ آن لائن کیٹلاگ شائع کریں')+'</div><p class="hint" id="sbCloudMsg"></p></div></details>'+
 '<details><summary>💬 WhatsApp آرڈر الرٹ</summary><div class="sb-sec" id="sbS_wa">'+txt('waNumber','آپ کا WhatsApp نمبر (کیٹلاگ آرڈر کے لیے)','بین الاقوامی شکل: 923001234567','923...')+txt('waKeywords','آرڈر والے الفاظ','کاما سے الگ — صرف ایسے پیغامات محفوظ ہوں گے','order,آرڈر')+'<div class="sb-btnrow">'+btn('waAccess','🔔 نوٹیفکیشن رسائی دیں')+btn('waTest','🧪 چیک کریں')+'</div><p class="hint">یہ سہولت صرف WhatsApp کی نوٹیفکیشن پڑھتی ہے، اور صرف اوپر والے الفاظ والے پیغامات ایپ میں محفوظ کرتی ہے۔ دوسری چیٹس محفوظ نہیں ہوتیں۔ رسائی دینے کے بعد آنے والے آرڈر مینیو ← آرڈرز میں اور الرٹ کے ساتھ ملیں گے۔</p><p class="hint" id="sbWaMsg"></p></div></details>'+
 '<details><summary>📦 اسٹاک اور الرٹ</summary><div class="sb-sec" id="sbS_stock">'+num('lowStockT','کم اسٹاک کی حد (پیس)','','0','1000','1')+sw('notifyPromise','وعدہ تاریخ پر یاد دہانی نوٹیفکیشن','')+sw('scanSound','اسکین کے بعد آواز/وائبریشن','')+'</div></details>'+
 '<details><summary>🗂️ ڈیٹا اور اسٹوریج</summary><div class="sb-sec" id="sbS_data"><div class="sb-meter"><i id="sbMeterI" style="width:0"></i></div><p class="hint" id="sbMeterT"></p>'+num('attachMax','اٹیچمنٹ تصویر کی زیادہ سے زیادہ لمبائی (px)','چھوٹی = کم جگہ','400','1600','100')+num('attachQuality','اٹیچمنٹ کوالٹی (%)','','30','90','5')+num('thumbSize','اٹیچمنٹ تھمب نیل کا سائز (px)','کھولنے کے لیے تھمب نیل پر ٹیپ کریں','40','160','8')+'<div class="sb-btnrow">'+btn('compress','🗜️ پرانی اٹیچمنٹ چھوٹی کریں')+btn('auditClear','🧹 ایکٹیویٹی لاگ صاف کریں','outline')+'</div></div></details>'+
 '<details><summary>ℹ️ ایپ کے بارے میں</summary><div class="sb-sec"><p class="hint">STAR BAGS V6 — آف لائن اور آن لائن دونوں طرح کام کرتی ہے۔ پرانی بیک اپ فائلیں اسی ایپ میں بحال ہو سکتی ہیں۔</p></div></details>'+
 '</div>';
 document.body.appendChild(d);SBOX=d;secSection();
 var bv=$('sbBackupValue'),bu=$('sbBackupUnit'),bs=$('sbBackupStatus'),native=SB.native();if(bv)bv.value=String(SB.settings().backupEveryValue||30);if(bu)bu.value=SB.settings().backupEveryUnit||'minutes';if($('sbBackupApply'))$('sbBackupApply').onclick=function(){var v=Math.max(1,Number(bv.value||30)),u=bu.value;SB.save({backupEveryValue:v,backupEveryUnit:u,backupEveryMin:Math.max(15,Math.round(v*(u==='days'?1440:u==='hours'?60:1)))});if(native&&native.scheduleAutomaticBackup)native.scheduleAutomaticBackup(v,u,true);if(bs)bs.textContent='شیڈول محفوظ: ہر '+v+' '+(u==='days'?'دن':u==='hours'?'گھنٹے':'منٹ')+'۔ Android بجلی/بیٹری کی وجہ سے تاخیر کر سکتا ہے۔';SB.toast('بیک اپ شیڈول محفوظ ہوگیا')};if($('sbBackupFolder'))$('sbBackupFolder').onclick=function(){if(native&&native.chooseBackupFolder)native.chooseBackupFolder();else alert('یہ اختیار Android ایپ میں دستیاب ہے۔')};if(native&&native.backupStatus&&bs){try{var z=JSON.parse(native.backupStatus());bs.textContent='فولڈر: '+(z.folder||'STAR BAGS')+' · آخری بیک اپ: '+(z.lastBackupAt?new Date(z.lastBackupAt).toLocaleString():'ابھی نہیں')+' · اگلا متوقع: '+(z.nextBackupAt?new Date(z.nextBackupAt).toLocaleString():'شیڈول کے مطابق')+(z.lastError?' · خرابی: '+z.lastError:'')}catch(e){}}
 /* move existing setting cards into settings (their handlers stay intact) */
 function mv(el,to){if(el&&to)to.appendChild(el)}
 var u=$('module-utility');var lang=$('languageStatus');mv(lang&&lang.closest('.history-item'),$('sbS_general'));var cn=$('companyNameInput');mv(cn&&cn.closest('.history-item'),$('sbS_general'));
 mv($('billPrintSettingsCard'),$('sbS_billmoved'));mv($('thermalPrinterSettings'),$('sbS_printmoved'));
 var bk=$('module-backup');if(bk){var box=$('sbS_backup');[].slice.call(bk.children).forEach(function(c){if(c.tagName!=='H2')box.appendChild(c)})}
 var lt=$('lowStockThreshold');var lts=d.querySelector('[data-sk="lowStockT"]');if(lts){lts.value=SB.jget('starbags_low_stock_threshold_v1',10)}
 d.addEventListener('change',function(e){var t=e.target,k=t.getAttribute&&t.getAttribute('data-sk');if(!k)return;var v;if(t.type==='checkbox')v=t.checked;else if(t.getAttribute('data-t')==='num'||t.getAttribute('data-t')==='selnum')v=Number(t.value);else v=t.value.trim();
  if(k==='lowStockT'){SB.jset('starbags_low_stock_threshold_v1',v);return}
  var o={};o[k]=v;SB.save(o);if(k==='autoBackup'){var n=SB.native(),st=SB.settings();if(n&&n.scheduleAutomaticBackup)n.scheduleAutomaticBackup(st.backupEveryValue||30,st.backupEveryUnit||'minutes',!!v)}if(k==='pertahCols')SB.save({_pcApplied:0});applyLook();if(k==='printDelay'){var n=SB.native();if(n&&n.setPrintDelay)n.setPrintDelay(v)}if(k==='waKeywords')pushWa();SB.toast('محفوظ ہو گیا')});
 d.addEventListener('click',function(e){var b=e.target.closest('[data-sa]');if(b)act(b.getAttribute('data-sa'))});
 $('sbSetClose').onclick=close}
function secSection(){var s=SB.settings(),box=$('sbS_sec');
 box.innerHTML=sw('pinEnabled','PIN لاک','ایپ کھولنے پر PIN مانگے')+'<div class="sb-btnrow">'+btn('setPin','🔑 مالک کا PIN سیٹ/تبدیل')+btn('setEmpPin','👤 ملازم کا PIN سیٹ','outline')+btn('lockNow','🔒 ابھی لاک کریں','outline')+'</div>'+sw('bio','فنگر پرنٹ / فون لاک سے کھولیں','مالک کے لیے؛ فون میں فنگر پرنٹ یا لاک سیٹ ہونا چاہیے')+sel('autoLockMin','خودکار لاک',[[0,'کبھی نہیں'],[1,'1 منٹ بعد'],[2,'2 منٹ بعد'],[5,'5 منٹ بعد'],[15,'15 منٹ بعد']])+'<p class="hint">ملازم کا PIN: بل بنانا، بل/پارٹی دیکھنا ممکن؛ نفع و نقصان، رپورٹس، پرچیز، مزدوری، اسٹاک اور سیٹنگ بند رہیں گی۔</p>';
 var chk=box.querySelector('[data-sk="pinEnabled"]');chk.addEventListener('change',function(ev){ev.stopPropagation();if(chk.checked){if(!SB.settings().pinHash){chk.checked=false;act('setPin')}else SB.save({pinEnabled:true})}else{if(confirm('PIN لاک بند کریں؟ ملازم PIN بھی ختم ہو جائے گا۔'))SB.disablePin();else chk.checked=true}},true)}
function askPin(title){var p=prompt(title+' (کم از کم 4 ہندسے)');if(p==null)return null;if(!/^\d{4,8}$/.test(p)){alert('PIN صرف 4 سے 8 ہندسوں کا ہو۔');return null}var q=prompt('PIN دوبارہ لکھیں');if(q!==p){alert('PIN ایک جیسا نہیں۔');return null}return p}
function pushWa(){var n=SB.native();if(n&&n.setWaKeywords)n.setWaKeywords(SB.settings().waKeywords||'')}
function act(a){var n=SB.native(),s=SB.settings();
 if(a==='export')SB.exportBackup();
 else if(a==='import'){$('importFile').click()}
 else if(a==='setPin'){var p=askPin('مالک کا نیا PIN');if(p){SB.setPin('owner',p);secSection();SB.toast('مالک PIN محفوظ')}}
 else if(a==='setEmpPin'){if(!s.pinHash){alert('پہلے مالک کا PIN سیٹ کریں۔');return}var p2=askPin('ملازم کا PIN');if(p2){if(SB.checkPin(p2)==='owner'){alert('ملازم کا PIN مالک کے PIN سے مختلف رکھیں۔');return}SB.setPin('employee',p2);SB.toast('ملازم PIN محفوظ')}}
 else if(a==='lockNow'){if(!s.pinHash){alert('پہلے PIN سیٹ کریں۔');return}close();SB.showLock()}
 else if(a==='waAccess'){if(n&&n.openNotificationAccess){pushWa();n.openNotificationAccess()}else alert('یہ سہولت صرف اینڈرائیڈ ایپ میں ہے۔')}
 else if(a==='waTest'){var ok=n&&n.isNotificationAccessGranted&&n.isNotificationAccessGranted();$('sbWaMsg').textContent=ok?'✅ رسائی فعال ہے۔ آرڈر والے الفاظ پر پیغام آنے پر الرٹ ملے گا۔':'⚠️ رسائی ابھی نہیں دی گئی۔'}
 else if(a==='compress')SB.compressOld&&SB.compressOld();
 else if(a==='auditClear'){if(confirm('ایکٹیویٹی لاگ صاف کریں؟')){localStorage.removeItem('starbags_audit_log_v1');SB.toast('لاگ صاف')}}
 else if(a==='backupFolder'){if(n&&n.chooseBackupFolder)n.chooseBackupFolder();else alert('فولڈر منتخب کرنے کے لیے Android ایپ استعمال کریں۔')}else if(a==='cloudUp')SB.cloudPush&&SB.cloudPush();else if(a==='cloudMerge')SB.cloudMerge&&SB.cloudMerge();else if(a==='cloudCatalog')SB.cloudCatalog&&SB.cloudCatalog()}
function stats(){var u=SB.storageUsage(),mb=u/1048576;var el=$('sbMeterI');if(el){el.style.width=Math.min(100,mb/5*100)+'%';el.style.background=mb>4?'#c0392b':mb>3?'#d89b00':'#1f8a5b'}var t=$('sbMeterT');if(t)t.textContent='ایپ ڈیٹا: '+mb.toFixed(2)+' MB (WebView کی حد تقریباً 5 MB)۔ بیک اپ باقاعدگی سے بنائیں۔';var lb=$('sbLastBk');if(lb){var x=SB.settings().lastBackupAt;try{var n=SB.native();if(n&&n.backupStatus){var z=JSON.parse(n.backupStatus());x=z.lastBackupAt||x}}catch(e){}lb.textContent=x?new Date(x).toLocaleString():'ابھی تک نہیں'}}
function open(){if(SB.role()==='employee'){alert('سیٹنگ صرف مالک کے لیے ہے۔');return}build();secSection();SBOX.classList.add('on');stats();document.body.style.overflow='hidden'}
function close(){if(SBOX)SBOX.classList.remove('on');document.body.style.overflow=''}
$('sbSettingsBtn')&&($('sbSettingsBtn').onclick=open);SB.openSettings=open;
document.addEventListener('click',function(e){if(SBOX&&SBOX.classList.contains('on')&&e.target.id==='importButton')close()});
window.addEventListener('popstate',close);
/* ---------- bill sheet: newest row stays visible, scroll like before ---------- */
(function sheet(){var rows=$('saleRows'),wrap=$('saleSheetWrap');if(!rows||!wrap)return;var obs=new MutationObserver(function(m){var added=m.some(function(x){return x.addedNodes.length});if(added)setTimeout(function(){wrap.scrollTop=wrap.scrollHeight},30)});obs.observe(rows,{childList:true});
 /* when a product is chosen, jump to qty and keep focus visible */ })();
/* ---------- attachments: small thumbnails + lightbox + smart compression ---------- */
(function att(){var lb=document.createElement('div');lb.id='sbLightbox';lb.innerHTML='<img alt=""><button type="button">✕ بند کریں</button>';document.body.appendChild(lb);
 lb.onclick=function(){lb.classList.remove('on')};
 document.addEventListener('click',function(e){var im=e.target;if(im.tagName==='IMG'&&im.closest&&im.closest('#billAttachmentPreview,#savedBillAttachment')){e.preventDefault();lb.querySelector('img').src=im.src;lb.classList.add('on')}},true);
 var td=HTMLCanvasElement.prototype.toDataURL;HTMLCanvasElement.prototype.toDataURL=function(type,q){
  if(type==='image/jpeg'&&q===0.62){var s=SB.settings(),max=s.attachMax||900,w=this.width,h=this.height,sc=Math.min(1,max/Math.max(w,h));var c=this;
   if(sc<1){c=document.createElement('canvas');c.width=Math.round(w*sc);c.height=Math.round(h*sc);c.getContext('2d').drawImage(this,0,0,c.width,c.height)}
   return td.call(c,'image/jpeg',(s.attachQuality||55)/100)}
  return td.apply(this,arguments)};
 SB.compressOld=function(){var bills=SB.jget('starbags_bills_v2',[]),todo=bills.filter(function(b){return b.billAttachment&&b.billAttachment.type&&b.billAttachment.type.indexOf('image/')===0&&b.billAttachment.data&&b.billAttachment.data.length>90000});
  if(!todo.length){SB.toast('کوئی بڑی تصویر نہیں ملی');return}var s=SB.settings(),done=0,saved=0;
  function next(){var b=todo.shift();if(!b){SB.jset('starbags_bills_v2',bills);SB.toast('✅ '+done+' تصاویر چھوٹی ہوئیں، '+Math.round(saved/1024)+' KB بچت');setTimeout(function(){location.reload()},1200);return}
   var im=new Image();im.onload=function(){var sc=Math.min(1,s.attachMax/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);var nd=td.call(c,'image/jpeg',s.attachQuality/100);if(nd.length<b.billAttachment.data.length){saved+=b.billAttachment.data.length-nd.length;b.billAttachment.data=nd;b.billAttachment.type='image/jpeg';done++}next()};im.onerror=next;im.src=b.billAttachment.data}
  next()}})();
/* ---------- "Rs" on/off for preview + printing ---------- */
(function rs(){var ft=CanvasRenderingContext2D.prototype.fillText;CanvasRenderingContext2D.prototype.fillText=function(t){if(!SB.settings().hideRs&&true===false){}if(SB.settings().hideRs&&typeof t==='string'&&/Rs\.?/.test(t)){arguments[0]=t.replace(/\bRs\.?\s?/g,'')}return ft.apply(this,arguments)};
 var root=$('billOutput');if(!root)return;var busy=false;function strip(){if(busy||!SB.settings().hideRs)return;busy=true;var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),n;while((n=w.nextNode())){if(/\bRs\.?\s?/.test(n.nodeValue))n.nodeValue=n.nodeValue.replace(/\bRs\.?\s?/g,'')}busy=false}
 new MutationObserver(function(){strip()}).observe(root,{childList:true,subtree:true,characterData:true});strip()})();
/* ---------- barcode / QR scan → add to bill ---------- */
(function scan(){var add=$('addSaleRow');if(!add)return;var b=document.createElement('button');b.type='button';b.className='outline smallbtn';b.id='sbScanBtn';b.textContent='📷 اسکین';add.parentNode.insertBefore(b,add.nextSibling);
 function prods(){return SB.jget('starbags_products_v2',[])}
 function addProduct(p){var rows=$('saleRows'),tr=[].slice.call(rows.querySelectorAll('tr')).filter(function(r){return String(r.querySelector('.sheet-product').value)===String(p.id)})[0];
  if(tr){var q=tr.querySelector('.sheet-qty');q.value=Number(q.value||0)+1;q.dispatchEvent(new Event('input',{bubbles:true}));tr.scrollIntoView({block:'nearest'});return}
  var empty=[].slice.call(rows.querySelectorAll('tr')).filter(function(r){return!r.querySelector('.sheet-product').value})[0];if(!empty){add.click();empty=rows.lastElementChild}
  var sel=empty.querySelector('.sheet-product');sel.value=String(p.id);sel.dispatchEvent(new Event('change',{bubbles:true}));var q2=empty.querySelector('.sheet-qty');q2.value=1;q2.dispatchEvent(new Event('input',{bubbles:true}))}
 window.sbScanResult=function(code){code=String(code||'').trim();if(!code)return;var map=SB.jget('starbags_barcodes_v1',{});var ps=prods();var p=ps.filter(function(x){return String(x.id)===String(map[code])})[0]||ps.filter(function(x){return SB.norm(x.keyword)===SB.norm(code)||SB.norm(x.name)===SB.norm(code)})[0];
  if(p){addProduct(p);SB.toast('✔ '+p.name);if(SB.settings().scanSound&&navigator.vibrate)navigator.vibrate(60);return}
  var list=ps.map(function(x,i){return(i+1)+'. '+x.name}).join('\n');var pick=prompt('کوڈ "'+code+'" کسی آئٹم سے منسلک نہیں۔ آئٹم کا نمبر لکھیں تاکہ منسلک ہو جائے:\n'+list);var i=parseInt(pick,10);if(i>=1&&i<=ps.length){map[code]=ps[i-1].id;SB.jset('starbags_barcodes_v1',map);addProduct(ps[i-1])}};
 b.onclick=function(){var n=SB.native();if(n&&n.scanBarcode)n.scanBarcode('sbScanResult');else{var c=prompt('بار کوڈ / QR کا نمبر لکھیں');if(c)window.sbScanResult(c)}}})();
/* ---------- pre-"Next" safety checks: credit limit + negative stock ---------- */
(function guards(){var mk=$('makeBill');if(!mk)return;mk.addEventListener('click',function(e){var extra=$('billExtraFields');if(extra&&!extra.classList.contains('hidden'))return;var s=SB.settings();
 var rows=[].slice.call($('saleRows').querySelectorAll('tr')).map(function(tr){var sel=tr.querySelector('.sheet-product');return{name:sel.options[sel.selectedIndex]&&sel.value?sel.options[sel.selectedIndex].text:'',qty:Number(tr.querySelector('.sheet-qty').value||0)}}).filter(function(r){return r.name&&r.qty>0});
 if(s.negStockWarn&&rows.length){var st=SB.stock(),editNo=($('billNo').value||'').trim(),old=SB.jget('starbags_bills_v2',[]).filter(function(b){return String(b.no)===editNo})[0];var back={};if(old)(old.items||[]).forEach(function(i){var k=SB.norm(i.name);back[k]=(back[k]||0)+Number(i.qty||0)});
  var bad=[];rows.forEach(function(r){var k=SB.norm(r.name.replace(/\s*[\(\[—-].*$/,'')),cand=Object.keys(st).filter(function(x){return x===k||k.indexOf(x)===0||x.indexOf(k)===0})[0];if(cand===undefined)return;var left=st[cand].stock+(back[cand]||0)-r.qty;if(left<0)bad.push(st[cand].name+' (موجود '+(st[cand].stock+(back[cand]||0))+'، درکار '+r.qty+')')});
  if(bad.length&&!confirm('⚠️ اسٹاک کم / منفی ہو جائے گا:\n'+bad.join('\n')+'\n\nپھر بھی بل بنائیں؟')){e.stopImmediatePropagation();e.preventDefault();return}}
 if(s.creditWarn){var party=($('party').value||'').trim(),lim=SB.jget('starbags_credit_limits_v1',{})[SB.norm(party)];if(party&&lim>0){var tot=Number(($('sheetGrandTotal').textContent||'').replace(/[^\d.]/g,''))||0,prev=Number($('previousDue').value||0);if(prev+tot>lim&&!confirm('⚠️ '+party+' کی ادھار حد Rs. '+SB.money(lim)+' ہے۔\nسابقہ بقایا + یہ بل = Rs. '+SB.money(prev+tot)+'\n\nپھر بھی جاری رکھیں؟')){e.stopImmediatePropagation();e.preventDefault()}}}},true)})();
SB.stock=function(){var t={};function g(n,name){var k=SB.norm(n);if(!t[k])t[k]={name:name||n,buy:0,sold:0,adjust:0};return t[k]}
 SB.jget('starbags_products_v2',[]).forEach(function(p){g(p.name)});SB.jget('starbags_purchases_v1',[]).forEach(function(p){g(p.item).buy+=Number(p.qty||0)});
 SB.jget('starbags_bills_v2',[]).forEach(function(b){(b.items||[]).forEach(function(i){g(i.name).sold+=Number(i.qty||0)})});SB.jget('starbags_stock_adjustments_v2',[]).forEach(function(a){g(a.item).adjust+=Number(a.qty||0)});
 Object.keys(t).forEach(function(k){t[k].stock=t[k].buy+t[k].adjust-t[k].sold});return t};
/* ---------- alert banner: promise dates, low stock, new orders ---------- */
function bill$(b){return(b.items||[]).reduce(function(s,i){return s+Number(i.amount||0)},0)+Number(b.laborCharge||0)}
SB.billBalance=function(b){var ret=0;try{ret=(b.returns||[]).reduce(function(s,r){return s+Number(r.amount||0)},0)}catch(e){}return Math.max(0,bill$(b)+Number(b.previousDue||0)-ret-Number(b.paid||0)-Number(b.writeOff||0)-Number(b.transferredAmount||0))};
function alerts(){var box=$('sbAlerts');if(!box){var ep=$('entryPanel');if(!ep)return;box=document.createElement('div');box.id='sbAlerts';ep.parentNode.insertBefore(box,ep)}
 var out=[],today=SB.today(),bills=SB.jget('starbags_bills_v2',[]);
 var due=bills.filter(function(b){return b.promiseDate&&b.promiseDate<=today&&SB.billBalance(b)>0});
 if(due.length){var ps={};due.forEach(function(b){ps[b.party||'—']=(ps[b.party||'—']||0)+SB.billBalance(b)});out.push(['red','⏰ وعدہ تاریخ آ گئی: '+Object.keys(ps).slice(0,4).map(function(p){return p+' (Rs. '+SB.money(ps[p])+')'}).join('، ')+(Object.keys(ps).length>4?' …':''),'parties']);
  var s=SB.settings();if(s.notifyPromise&&s._promiseNotified!==today){var n=SB.native();if(n&&n.notifyNow){n.notifyNow('وعدہ تاریخ کی یاد دہانی',Object.keys(ps).length+' پارٹیوں کی ادائیگی کی تاریخ آ گئی')}SB.save({_promiseNotified:today})}}
 var th=Number(SB.jget('starbags_low_stock_threshold_v1',10)),st=SB.stock(),low=Object.keys(st).filter(function(k){return st[k].stock<=th&&(st[k].buy||st[k].sold||st[k].adjust)});if(low.length)out.push(['','📦 کم اسٹاک: '+low.slice(0,4).map(function(k){return st[k].name+' ('+st[k].stock+')'}).join('، ')+(low.length>4?' …':''),'inventory']);
 var ni=SB.jget('starbags_wa_inbox_v1',[]).filter(function(x){return x.status==='new'}).length;var bd=$('sbOrdBadge');if(bd){bd.style.display=ni?'':'none';bd.textContent=ni}
 if(ni)out.push(['red','📥 '+ni+' نئے آرڈر پیغام','sborders']);
 box.innerHTML='';out.forEach(function(o){var d=document.createElement('div');d.className=o[0];d.textContent=o[1];d.onclick=function(){var b=document.querySelector('#mainMenu [data-module="'+o[2]+'"]');if(b)b.click()};box.appendChild(d)})}
SB.alerts=alerts;
document.addEventListener('DOMContentLoaded',function(){applyLook();setTimeout(alerts,800);var n=SB.native();if(n&&n.setPrintDelay)n.setPrintDelay(SB.settings().printDelay);pushWa()});
window.addEventListener('sb-unlocked',function(){setTimeout(alerts,300)});setInterval(alerts,5*60000);
document.addEventListener('visibilitychange',function(){if(!document.hidden){alerts();if(SB.pullWa)SB.pullWa()}});
applyLook();
})();
