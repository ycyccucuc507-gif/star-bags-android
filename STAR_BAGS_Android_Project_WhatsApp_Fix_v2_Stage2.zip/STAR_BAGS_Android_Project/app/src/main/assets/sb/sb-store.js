/* STAR BAGS: large data (product/bill images) is kept in phone files instead of the 5 MB WebView localStorage.
   Transparent: the rest of the app still uses localStorage.getItem/setItem. Browser (no Android bridge) = unchanged. */
(function(){'use strict';
var N=null;try{N=window.StarBagsAndroid}catch(e){}
if(!N||typeof N.kvPut!=='function'||typeof Storage==='undefined')return;
var M='\u0001SBFILE\u0001',LIM=50000,cache={};
var _get=Storage.prototype.getItem,_set=Storage.prototype.setItem,_rem=Storage.prototype.removeItem,_clr=Storage.prototype.clear;
function ls(o){return o===window.localStorage}
function mine(k){return String(k).indexOf('starbags_')===0}
function toFile(self,k,v){var ok=false;try{ok=N.kvPut(String(k),v)}catch(e){}if(!ok)return false;cache[k]=v;_set.call(self,k,M);return true}
Storage.prototype.getItem=function(k){var v=_get.call(this,k);
 if(v===M&&ls(this)){k=String(k);if(Object.prototype.hasOwnProperty.call(cache,k))return cache[k];var f=null;try{f=N.kvGet(k)}catch(e){}if(f==null)return null;cache[k]=f;return f}
 return v};
Storage.prototype.setItem=function(k,v){
 if(ls(this)&&mine(k)){k=String(k);v=String(v);
  if(v.length>LIM&&toFile(this,k,v))return;
  var wasFile=_get.call(this,k)===M;
  try{_set.call(this,k,v)}catch(err){if(toFile(this,k,v))return;throw err}
  if(wasFile){try{N.kvDel(k)}catch(e){}delete cache[k]}
  return}
 return _set.call(this,k,v)};
Storage.prototype.removeItem=function(k){
 if(ls(this)&&mine(k)&&_get.call(this,k)===M){try{N.kvDel(String(k))}catch(e){}delete cache[String(k)]}
 return _rem.call(this,k)};
Storage.prototype.clear=function(){if(ls(this)){try{N.kvClear()}catch(e){}cache={}}return _clr.call(this)};
window.SBStore={active:true,size:function(){try{return Number(N.kvSize())||0}catch(e){return 0}}};
/* one-time migration: move existing big values out of localStorage (frees the 5 MB space) */
try{var keys=[];for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&mine(k))keys.push(k)}
 keys.forEach(function(k){var v=_get.call(localStorage,k);if(v&&v!==M&&v.length>LIM)toFile(localStorage,k,v)})}catch(e){}
})();
