/* STAR BAGS V6 — core: settings, storage mirror, backup/restore (old backups supported), audit log */
(function(){'use strict';
var SB=window.SB=window.SB||{};SB.version='6.0';
var SKEY='starbags_settings_v60',AUDIT='starbags_audit_log_v1';
var DEF={pinEnabled:false,pinHash:'',salt:'',empPinHash:'',bio:false,autoLockMin:2,hideRs:false,showRate:true,
 pertahCols:3,logoSize:40,negStockWarn:true,autoBackup:true,backupEveryMin:30,cloudUrl:'https://starbags-shop-default-rtdb.firebaseio.com',cloudSecret:'',apiKey:'',aiKey:'',vaultKey:'',fbRefresh:'',catalogSite:'https://starbags1.netlify.app',shopId:'starbags-7265',autoCatalog:true,
 cloudAuto:true,waNumber:'',waKeywords:'order,آرڈر,ارڈر,اردر,چاہیے,چاہئے,بھیج,بھیجیں,rate,ریٹ',printDelay:65,attachMax:900,
 attachQuality:55,gstOn:false,gstPct:0,gstNo:'',billTemplate:'classic',theme:'light',fontScale:100,thumbSize:64,
 notifyPromise:true,creditWarn:true,scanSound:true,lastBackupAt:0,lastCloudAt:0};
SB.DEF=DEF;
SB.settings=function(){try{return Object.assign({},DEF,JSON.parse(localStorage.getItem(SKEY)||'{}'))}catch(e){return Object.assign({},DEF)}};
SB.save=function(o){var s=Object.assign(SB.settings(),o||{});try{localStorage.setItem(SKEY,JSON.stringify(s))}catch(e){SB.toast('سیٹنگ محفوظ نہیں ہو سکی: جگہ کم ہے')}return s};
SB.jget=function(k,d){try{var v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
SB.jset=function(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
SB.norm=function(s){return String(s==null?'':s).toLowerCase().replace(/[ـ_،,]/g,' ').replace(/\s+/g,' ').trim()};
SB.money=function(n){return Number(n||0).toLocaleString('en-PK',{maximumFractionDigits:2})};
SB.today=function(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
SB.esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
SB.native=function(){try{return window.StarBagsAndroid||null}catch(e){return null}};
SB.role=function(){return sessionStorage.getItem('sb_role')||'owner'};
SB.toast=function(msg,ms){var go=function(){var t=document.getElementById('sbToast');if(!t){t=document.createElement('div');t.id='sbToast';document.body.appendChild(t)}t.textContent=msg;t.className='show';clearTimeout(SB._tt);SB._tt=setTimeout(function(){t.className=''},ms||2600)};if(document.body)go();else document.addEventListener('DOMContentLoaded',go)};

/* SHA-256 (pure JS: crypto.subtle is unavailable on file:// pages) */
SB.sha256=function(str){function r(n,x){return(x>>>n)|(x<<(32-n))}var K=[],H=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225],p=2,c=0;
while(c<64){var ok=true;for(var i=2;i*i<=p;i++){if(p%i===0){ok=false;break}}if(ok){K[c]=(Math.pow(p,1/3)*4294967296)|0;c++}p++}
var b=unescape(encodeURIComponent(str)),l=b.length*8,w=[],i2;for(i2=0;i2<b.length;i2++)w[i2>>2]|=b.charCodeAt(i2)<<(24-(i2%4)*8);
w[l>>5]|=0x80<<(24-l%32);w[(((l+64)>>9)<<4)+15]=l;
for(var o=0;o<w.length;o+=16){var W=w.slice(o,o+16),a=H.slice(),j;for(j=0;j<64;j++){if(j>=16){var s0=r(7,W[j-15])^r(18,W[j-15])^(W[j-15]>>>3),s1=r(17,W[j-2])^r(19,W[j-2])^(W[j-2]>>>10);W[j]=(W[j-16]+s0+W[j-7]+s1)|0}
var S1=r(6,a[4])^r(11,a[4])^r(25,a[4]),ch=(a[4]&a[5])^(~a[4]&a[6]),t1=(a[7]+S1+ch+K[j]+W[j])|0,S0=r(2,a[0])^r(13,a[0])^r(22,a[0]),mj=(a[0]&a[1])^(a[0]&a[2])^(a[1]&a[2]),t2=(S0+mj)|0;
a=[(t1+t2)|0,a[0],a[1],a[2],(a[3]+t1)|0,a[4],a[5],a[6]]}for(j=0;j<8;j++)H[j]=(H[j]+a[j])|0}
return H.map(function(x){return('00000000'+(x>>>0).toString(16)).slice(-8)}).join('')};

/* ---- mirror every starbags_* write to IndexedDB + native auto-backup (debounced) ---- */
var idb=null,mirrorT=null;
function openIdb(cb){if(idb)return cb(idb);try{var rq=indexedDB.open('starbags_mirror',1);rq.onupgradeneeded=function(){rq.result.createObjectStore('snap')};rq.onsuccess=function(){idb=rq.result;cb(idb)};rq.onerror=function(){cb(null)}}catch(e){cb(null)}}
SB.rawSnapshot=function(){var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&k.indexOf('starbags_')===0)o[k]=localStorage.getItem(k)}return o};
function scheduleMirror(){clearTimeout(mirrorT);mirrorT=setTimeout(doMirror,2500)}
function doMirror(){var s=SB.settings();var snap={savedAt:Date.now(),raw:SB.rawSnapshot()};
 openIdb(function(db){if(!db)return;try{db.transaction('snap','readwrite').objectStore('snap').put(snap,'latest')}catch(e){}});
 if(s.autoBackup){var n=SB.native();if(n&&n.saveAutoBackup){try{n.saveAutoBackup(JSON.stringify(SB.buildBackup()),SB.today())}catch(e){}}}
 SB._lastMirror=Date.now()}
var _set=Storage.prototype.setItem,_rem=Storage.prototype.removeItem;
Storage.prototype.setItem=function(k,v){var self=this,isLS=(self===window.localStorage);
 if(isLS&&k==='starbags_bills_v2'){try{SB._auditDiff(localStorage.getItem(k),v)}catch(e){}}
 try{_set.call(self,k,v)}catch(err){if(isLS)SB._quota(err);throw err}
 if(isLS&&String(k).indexOf('starbags_')===0&&k!==AUDIT)scheduleMirror()};
Storage.prototype.removeItem=function(k){_rem.call(this,k);if(this===window.localStorage&&String(k).indexOf('starbags_')===0)scheduleMirror()};
SB._quota=function(err){SB._quotaHit=true;SB.toast('⚠️ فون کی ایپ اسٹوریج بھر گئی ہے۔ سیٹنگ ← ڈیٹا ← تصاویر چھوٹی کریں',6000)};
SB.storageUsage=function(){var t=0;for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);t+=(k.length+(localStorage.getItem(k)||'').length)*2}return t};

/* ---- backup build / apply (old backups remain fully compatible) ---- */
var LEG=[['products','starbags_products_v2','arr'],['bills','starbags_bills_v2','arr'],['purchases','starbags_purchases_v1','arr'],['parties','starbags_parties_v1','arr'],['laborLedger','starbags_labor_ledger_v1','arr'],['lowStockThreshold','starbags_low_stock_threshold_v1','num'],['expenses','starbags_expenses_v2','arr'],['stockAdjustments','starbags_stock_adjustments_v2','arr'],['partyPayments','starbags_party_payments_v1','arr'],['supplierPayments','starbags_supplier_payments_v1','arr'],['recycleBin','starbags_recycle_bin_v1','arr'],['storeSettings','starbags_store_settings_v1','obj'],['storeItemOverrides','starbags_store_item_overrides_v2','obj'],['storeOrders','starbags_store_orders_v1','arr'],['pertahCosts','starbags_pertah_costs_v1','arr']];
var SECRET=['pinHash','empPinHash','salt','aiKey'];/* cloud settings now travel inside the backup so restoring it re-activates everything */
SB.buildBackup=function(){var d={app:'STAR BAGS',version:6,savedAt:new Date().toISOString()};
 LEG.forEach(function(r){d[r[0]]=SB.jget(r[1],r[2]==='arr'?[]:r[2]==='obj'?{}:10)});
 d.companyName=localStorage.getItem('starbags_company_name_v1')||'STAR BAGS';d.language=localStorage.getItem('starbags_language_v1')||'ur';
 d.thermalPaper=localStorage.getItem('starbags_thermal_paper_v1')||'58';d.seq=localStorage.getItem('starbags_seq_v2')||'1';
 var raw=SB.rawSnapshot();delete raw.starbags_settings_v60;var st=SB.settings();SECRET.forEach(function(k){delete st[k]});
 d.sbV60={settings:st,raw:raw};return d};
SB.applyBackup=function(d,silent){
 if(!d||!Array.isArray(d.products)||!Array.isArray(d.bills))throw new Error('bad');
 LEG.forEach(function(r){var v=d[r[0]];var ok=r[2]==='arr'?Array.isArray(v):r[2]==='obj'?(v&&typeof v==='object'&&!Array.isArray(v)):v!=null;
  var val=ok?v:(r[2]==='arr'?[]:r[2]==='obj'?{}:10);_set.call(localStorage,r[1],JSON.stringify(val))});
 _set.call(localStorage,'starbags_seq_v2',String(d.seq||'1'));
 _set.call(localStorage,'starbags_company_name_v1',String(d.companyName||'STAR BAGS'));
 _set.call(localStorage,'starbags_language_v1',d.language==='en'?'en':'ur');
 _set.call(localStorage,'starbags_thermal_paper_v1',['58','80','a4'].indexOf(String(d.thermalPaper))>=0?String(d.thermalPaper):'58');
 if(d.sbV60&&d.sbV60.raw){Object.keys(d.sbV60.raw).forEach(function(k){if(k.indexOf('starbags_')===0&&k!==SKEY&&LEG.every(function(r){return r[1]!==k}))_set.call(localStorage,k,d.sbV60.raw[k])})}
 if(d.sbV60&&d.sbV60.settings){var cur=SB.settings(),keep={};SECRET.forEach(function(k){keep[k]=cur[k]});_set.call(localStorage,SKEY,JSON.stringify(Object.assign({},DEF,d.sbV60.settings,keep)))}
 return true};
SB.exportBackup=function(){var payload=JSON.stringify(SB.buildBackup(),null,1),fn='star-bags-backup-'+SB.today()+'.json';
 SB.save({lastBackupAt:Date.now()});var n=SB.native();
 if(n&&n.saveBackup){var r=new FileReader();r.onload=function(){var b64=String(r.result).split(',')[1];try{n.saveBackup(b64,fn,'application/json')}catch(e){SB.download(payload,fn,'application/json')}};r.readAsDataURL(new Blob([payload],{type:'application/json'}))}
 else SB.download(payload,fn,'application/json')};
SB.download=function(text,fn,mime){var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=fn;document.body.appendChild(a);a.click();a.remove()};
SB.importFile=function(file){return file.text().then(function(txt){var d=JSON.parse(txt);if(!Array.isArray(d.products)||!Array.isArray(d.bills))throw new Error('bad');
 if(!confirm('موجودہ تمام ڈیٹا کی جگہ اس بیک اپ کا ڈیٹا بحال کریں؟\n(بحالی سے پہلے موجودہ ڈیٹا کا خودکار محفوظ نقل بن جائے گی)'))return false;
 try{var n=SB.native();if(n&&n.saveAutoBackup)n.saveAutoBackup(JSON.stringify(SB.buildBackup()),'before-restore-'+SB.today())}catch(e){}
 SB.applyBackup(d);alert('بیک اپ بحال ہو گیا۔ ایپ دوبارہ لوڈ ہو رہی ہے۔');location.reload();return true})};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#exportData,#menuExport,[data-sbact="export"]');if(b){e.stopImmediatePropagation();e.preventDefault();SB.exportBackup()}},true);
document.addEventListener('change',function(e){var t=e.target;if(t&&t.id==='importFile'&&t.files&&t.files[0]){e.stopImmediatePropagation();var f=t.files[0];SB.importFile(f).catch(function(){alert('درست STAR BAGS بیک اپ فائل منتخب کریں۔')}).then(function(){t.value=''})}},true);

/* ---- audit log: who / when for bill add, edit, delete ---- */
SB.audit=function(action,info){var l=SB.jget(AUDIT,[]);l.unshift(Object.assign({t:new Date().toISOString(),who:SB.role()==='employee'?'ملازم':'مالک',action:action},info||{}));if(l.length>600)l.length=600;try{_set.call(localStorage,AUDIT,JSON.stringify(l))}catch(e){}};
function bt(b){return(b.items||[]).reduce(function(s,i){return s+Number(i.amount||0)},0)+Number(b.laborCharge||0)}
SB._auditDiff=function(oldS,newS){if(!oldS||!newS)return;var o=JSON.parse(oldS),n=JSON.parse(newS);if(!Array.isArray(o)||!Array.isArray(n))return;var om={},nm={};o.forEach(function(b){om[b.id]=b});n.forEach(function(b){nm[b.id]=b});
 n.forEach(function(b){var p=om[b.id];if(!p)SB.audit('بل نیا',{no:b.no,party:b.party,total:bt(b)});else if(JSON.stringify(p.items)!==JSON.stringify(b.items)||Number(p.paid||0)!==Number(b.paid||0)||p.party!==b.party)SB.audit('بل تبدیل',{no:b.no,party:b.party,total:bt(b),old:bt(p)})});
 o.forEach(function(b){if(!nm[b.id])SB.audit('بل حذف',{no:b.no,party:b.party,total:bt(b)})})};
/* ---- auto backup ticker + daily rotation ---- */
setInterval(function(){var s=SB.settings();if(s.autoBackup&&(!SB._lastMirror||Date.now()-SB._lastMirror>s.backupEveryMin*60000))doMirror()},60000);
window.addEventListener('pagehide',function(){try{doMirror()}catch(e){}});
document.addEventListener('visibilitychange',function(){if(document.hidden)try{doMirror()}catch(e){}});
/* ---- native restore BEFORE the app boots, if localStorage was wiped ---- */
(function(){try{var hasData=localStorage.getItem('starbags_bills_v2')||localStorage.getItem('starbags_products_v2');
 if(!hasData){var n=SB.native();if(n&&n.loadAutoBackup){var txt=n.loadAutoBackup();if(txt&&txt.length>10){var d=JSON.parse(txt);SB.applyBackup(d,true);SB._restoredFromNative=true}}}}catch(e){console.error('native restore',e)}})();
/* ---- IndexedDB restore (async) → one reload ---- */
SB.idbRestoreCheck=function(){try{var has=localStorage.getItem('starbags_bills_v2')||localStorage.getItem('starbags_products_v2');if(has||sessionStorage.getItem('sb_idb_tried'))return;sessionStorage.setItem('sb_idb_tried','1');
 openIdb(function(db){if(!db)return;var q=db.transaction('snap').objectStore('snap').get('latest');q.onsuccess=function(){var s=q.result;if(s&&s.raw&&(s.raw.starbags_bills_v2||s.raw.starbags_products_v2)){Object.keys(s.raw).forEach(function(k){_set.call(localStorage,k,s.raw[k])});location.reload()}}})}catch(e){}};
SB.idbRestoreCheck();

})();
