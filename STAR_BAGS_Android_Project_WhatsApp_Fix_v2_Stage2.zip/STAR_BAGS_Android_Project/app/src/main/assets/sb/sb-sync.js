/* STAR BAGS V8 — cloud backup/sync + online catalog (Firebase Realtime Database over REST, secured with Firebase anonymous login) */
(function(){'use strict';var SB=window.SB,$=function(id){return document.getElementById(id)};
var DEF_DB='https://starbags-shop-default-rtdb.firebaseio.com',DEF_SHOP='starbags-7265';
function S(){return SB.settings()}
function slug(){return String(S().shopId||DEF_SHOP).replace(/[^A-Za-z0-9_-]/g,'')||DEF_SHOP}
function dbUrl(){var u=String(S().cloudUrl||DEF_DB).trim().replace(/\/+$/,'');return /^https:\/\//i.test(u)?u:DEF_DB}
function vault(){var s=S(),v=String(s.vaultKey||'').replace(/[^A-Za-z0-9]/g,'');if(v.length<16){var a=new Uint8Array(18);(window.crypto||window.msCrypto).getRandomValues(a);v=Array.prototype.map.call(a,function(x){return'abcdefghijkmnpqrstuvwxyz23456789'[x%32]}).join('');SB.save({vaultKey:v})}return v}
function privPath(){return'starbags/'+slug()+'-'+vault()}
/* never spam: silent (automatic) failures only update the small status line, one toast per hour at most */
var lastToast=0;
function msg(t,silent){var m=$('sbCloudMsg');if(m)m.textContent=t;if(!silent||Date.now()-lastToast>3600000){if(silent)lastToast=Date.now();SB.toast(t)}}
function explain(e){var m=String((e&&e.message)||e||'');
 if(/AUTH:/.test(m)){var c=m.replace(/^[\s\S]*?AUTH:/,'').slice(0,160);
  if(/ADMIN_ONLY|OPERATION_NOT_ALLOWED/.test(c))return'Firebase ← Authentication ← Sign-in method میں "Anonymous" آن کریں ['+c+']';
  if(/CONFIGURATION_NOT_FOUND/.test(c))return'Firebase ← Authentication کھول کر پہلے "Get started" دبائیں، پھر Anonymous آن کریں ['+c+']';
  if(/referer|referrer/i.test(c))return'Web API Key پر پابندی (HTTP referrer) ہے: Google Cloud ← APIs & Services ← Credentials ← "Browser key" ← Application restrictions = None کریں ['+c+']';
  if(/blocked|SERVICE_BLOCKED|has not been used|disabled/i.test(c))return'Google Cloud میں Identity Toolkit API بند/بلاک ہے: Credentials ← Browser key ← API restrictions میں "Identity Toolkit API" شامل کریں ['+c+']';
  if(/not valid|API_KEY_INVALID|INVALID_API_KEY|API_KEY/i.test(c))return'Web API Key درست نہیں لگ رہی ['+c+']';
  return'Firebase لاگ اِن ناکام ['+c+']'}
 if(/AUTH:(ADMIN_ONLY_OPERATION|OPERATION_NOT_ALLOWED)/.test(m))return'Firebase ← Authentication ← Sign-in method میں "Anonymous" آن کریں';
 if(/AUTH:|API.?KEY/i.test(m)&&!/HTTP/.test(m))return'Web API Key غلط یا خالی ہے (Firebase ← Project settings ← General ← Web API Key)';
 if(/HTTP 40[13]/.test(m))return'Firebase اجازت نہیں دے رہا (HTTP 401): API Key + Anonymous لاگ اِن آن کریں اور Rules لگائیں — سیٹنگ ← "کنکشن ٹیسٹ" دبائیں';
 if(/HTTP 404/.test(m))return'ڈیٹابیس لنک غلط ہے';
 if(/Failed to fetch|NetworkError|network/i.test(m))return'انٹرنیٹ یا ڈیٹابیس لنک کا مسئلہ';
 return m}
function j(r){return r.json()}
function tokenFresh(){var t=SB._tok;return t&&t.exp>Date.now()+60000?t.id:''}
function authToken(force){var s=S(),key=String(s.apiKey||'').trim();
 if(!key)return Promise.resolve(String(s.cloudSecret||''));
 var f=force?'':tokenFresh();if(f)return Promise.resolve(f);
 function ok(id,exp,rt){SB._tok={id:id,exp:Date.now()+(Number(exp)||3600)*1000};if(rt&&rt!==s.fbRefresh)SB.save({fbRefresh:rt});return id}
 var first=s.fbRefresh?fetch('https://securetoken.googleapis.com/v1/token?key='+encodeURIComponent(key),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=refresh_token&refresh_token='+encodeURIComponent(s.fbRefresh)}).then(j).then(function(d){if(!d.id_token)throw new Error('x');return ok(d.id_token,d.expires_in,d.refresh_token)}):Promise.reject(new Error('x'));
 return first.catch(function(){return fetch('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key='+encodeURIComponent(key),{method:'POST',headers:{'Content-Type':'application/json'},body:'{"returnSecureToken":true}'}).then(j).then(function(d){if(!d.idToken)throw new Error('AUTH:'+((d.error&&d.error.message)||'API_KEY'));return ok(d.idToken,d.expiresIn,d.refreshToken)})})}
function req(path,opt,noauth){opt=opt||{};
 function go(force){return(noauth?Promise.resolve(''):authToken(force)).then(function(tk){var u=dbUrl()+'/'+path+'.json'+(tk?'?auth='+encodeURIComponent(tk):'');return fetch(u,opt)})}
 return go(false).then(function(r){if((r.status===401||r.status===403)&&!noauth&&String(S().apiKey||'').trim()){SB._tok=null;return go(true)}return r}).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r})}
function fail(e,silent){var t='سنک ناکام: '+explain(e);SB.save({cloudErr:t,cloudErrAt:Date.now()});msg(t,silent);return false}
SB.cloudPush=function(silent){if(!navigator.onLine){if(!silent)msg('انٹرنیٹ نہیں ہے');return Promise.resolve(false)}
 var d=SB.buildBackup();delete d.sbV60;d.device=S().deviceId||'';if(!silent)msg('اپ لوڈ ہو رہا ہے…');
 return req(privPath(),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(){SB.save({lastCloudAt:Date.now(),cloudErr:''});try{rememberKnown()}catch(e){}if(!silent)msg('✅ کلاؤڈ پر اپ لوڈ ہو گیا');return true}).catch(function(e){return fail(e,silent)})};
var MERGE=[['products','starbags_products_v2','id'],['bills','starbags_bills_v2','id'],['purchases','starbags_purchases_v1','id'],['expenses','starbags_expenses_v2','id'],['laborLedger','starbags_labor_ledger_v1','id'],['stockAdjustments','starbags_stock_adjustments_v2','id'],['partyPayments','starbags_party_payments_v1','id'],['supplierPayments','starbags_supplier_payments_v1','id'],['storeOrders','starbags_store_orders_v1','id'],['parties','starbags_parties_v1','name']];
function keyOf(m,x){return String(m[2]==='name'?SB.norm(x.name):x[m[2]])}
function rememberKnown(){var known={};MERGE.forEach(function(m){var o={};SB.jget(m[1],[]).forEach(function(x){o[keyOf(m,x)]=1});known[m[0]]=o});SB.jset('starbags_sync_known_v1',known)}
/* 3-way merge: anything deleted here (or on another phone) after the last sync stays deleted instead of coming back */
SB.mergeInto=function(remote){var changed=0,known=SB.jget('starbags_sync_known_v1',{});MERGE.forEach(function(m){var rem=remote[m[0]];if(!Array.isArray(rem))return;var loc=SB.jget(m[1],[]),kn=known[m[0]]||{},remKeys={};rem.forEach(function(r){remKeys[keyOf(m,r)]=1});
  var gone=loc.filter(function(x){var k=keyOf(m,x);return kn[k]&&!remKeys[k]}),nk=Object.keys(kn).length;
  if(gone.length&&!(nk>=10&&gone.length>nk/2)){var gk={};gone.forEach(function(x){gk[keyOf(m,x)]=1});loc=loc.filter(function(x){return!gk[keyOf(m,x)]});changed+=gone.length}
  var idx={};loc.forEach(function(x,i){idx[keyOf(m,x)]=i});
  rem.forEach(function(r){var k=keyOf(m,r);if(!(k in idx)){if(kn[k])return;loc.push(r);idx[k]=loc.length-1;changed++}else if(r.updatedAt&&String(r.updatedAt)>String(loc[idx[k]].updatedAt||'')){loc[idx[k]]=r;changed++}});
  SB.jset(m[1],loc)});
 var seqR=Number(remote.seq||0),seqL=Number(localStorage.getItem('starbags_seq_v2')||0);if(seqR>seqL)localStorage.setItem('starbags_seq_v2',String(seqR));return changed};
SB.cloudMerge=function(silent){if(!navigator.onLine){if(!silent)msg('انٹرنیٹ نہیں ہے');return Promise.resolve(false)}
 if(!silent)msg('ڈاؤن لوڈ ہو رہا ہے…');
 return req(privPath()).then(j).then(function(d){if(!d||!Array.isArray(d.bills)){if(!silent)msg('کلاؤڈ پر ابھی ڈیٹا نہیں — پہلا اپ لوڈ ہو رہا ہے');return SB.cloudPush(true)}
  var c=SB.mergeInto(d);SB.save({lastCloudAt:Date.now(),cloudErr:''});return SB.cloudPush(true).then(function(){msg('✅ ضم ہو گیا ('+c+' نئے/اپڈیٹ ریکارڈ)',silent);if(c>0&&!silent)setTimeout(function(){location.reload()},900);return c})}).catch(function(e){return fail(e,silent)})};
/* auto-sync: every 10 min while online, but after a failure wait 60 min (no repeated error popups) */
function auto(){var s=S();if(!s.cloudAuto||!navigator.onLine)return;if(Date.now()-(s.lastCloudAt||0)<10*60000)return;if(s.cloudErr&&Date.now()-(s.cloudErrAt||0)<60*60000)return;SB.cloudMerge(true)}
window.addEventListener('sb-online',function(){setTimeout(auto,1500)});setInterval(auto,10*60000);document.addEventListener('DOMContentLoaded',function(){setTimeout(auto,6000)});
/* online catalog: products → cloud (small thumbnails). Public page: STAR BAGS catalog site. */
function catLink(){var s=S(),site=String(s.catalogSite||'').trim().replace(/\/+$/,'');if(!site)return'';var def=(dbUrl()===DEF_DB&&slug()===DEF_SHOP);return site+(def?'':'/?u='+encodeURIComponent(dbUrl())+'&s='+slug())}
function catSig(){var ps=SB.jget('starbags_products_v2',[]),st=SB.stock();return ps.map(function(p){var k=SB.norm(p.name),im=p.image||(p.images&&p.images[0])||'';return[p.name,p.sell,(st[k]&&(st[k].buy+st[k].adjust)>0)?st[k].stock:'',String(im).length].join('|')}).join(';')+'#'+(S().waNumber||'')+'#'+(localStorage.getItem('starbags_company_name_v1')||'')}
SB.cloudCatalog=function(silent){var s=S();if(!s.waNumber){if(!silent)alert('پہلے سیٹنگ ← WhatsApp میں اپنا نمبر لکھیں تاکہ گاہک کا آرڈر آپ کو آئے۔');return Promise.resolve(false)}
 var ps=SB.jget('starbags_products_v2',[]).slice(0,80),st=SB.stock(),sig=catSig();if(!silent)msg('کیٹلاگ تیار ہو رہا ہے…');
 function thumb(src){return new Promise(function(res){if(!src||String(src).indexOf('data:image')!==0)return res('');var im=new Image();im.onload=function(){var sc=Math.min(1,220/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',0.6))};im.onerror=function(){res('')};im.src=src})}
 return Promise.all(ps.map(function(p){var k=SB.norm(p.name);return thumb(p.image||(p.images&&p.images[0])).then(function(t){return{n:p.name,d:p.keyword||'',p:Number(p.sell||0),s:(st[k]&&(st[k].buy+st[k].adjust)>0)?st[k].stock:null,i:t}})})).then(function(items){
  return req('starbags_catalog/'+slug(),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:localStorage.getItem('starbags_company_name_v1')||'STAR BAGS',wa:String(s.waNumber).replace(/\D/g,''),updated:Date.now(),items:items})})}).then(function(){
  SB.save({lastCatalogSig:sig,cloudErr:''});var link=catLink();SB.lastCatalogLink=link;msg('✅ کیٹلاگ شائع ہو گیا',silent);if(!silent&&link)prompt('گاہکوں کو یہ لنک بھیجیں (کاپی کریں):',link);return true}).catch(function(e){var t='کیٹلاگ ناکام: '+explain(e);SB.save({cloudErr:t,cloudErrAt:Date.now()});msg(t,silent);return false})};
function autoCatalog(){var s=S();if(!s.autoCatalog||!s.waNumber||!navigator.onLine)return;if(s.cloudErr&&Date.now()-(s.cloudErrAt||0)<60*60000)return;if(catSig()!==s.lastCatalogSig)SB.cloudCatalog(true)}
setInterval(autoCatalog,5*60000);document.addEventListener('DOMContentLoaded',function(){setTimeout(autoCatalog,12000)});document.addEventListener('visibilitychange',function(){if(document.hidden)setTimeout(autoCatalog,300)});
/* connection test: tells exactly which step fails and what to do */
SB.cloudTest=function(){var out=[],el=$('sbCloudMsg');function say(t){out.push(t);if(el)el.innerHTML=out.map(function(x){return SB.esc(x)}).join('<br>')}
 say('⏳ ٹیسٹ ہو رہا ہے…');out.length=0;
 return req('starbags_catalog/'+slug(),{},true).then(function(){say('✅ 1) ڈیٹابیس لنک اور عوامی کیٹلاگ پڑھنا ٹھیک')},function(e){say('❌ 1) ڈیٹابیس: '+explain(e)+' (Rules میں starbags_catalog کی read اجازت دیں)')}).then(function(){
  if(!String(S().apiKey||'').trim()){say('ℹ️ 2) Web API Key خالی ہے — بغیر لاگ اِن کوشش ہو گی');return}
  return authToken(true).then(function(){say('✅ 2) Firebase لاگ اِن (Anonymous) ٹھیک')},function(e){say('❌ 2) '+explain(e))})}).then(function(){
  return req(privPath()+'/_ping',{method:'PUT',headers:{'Content-Type':'application/json'},body:String(Date.now())}).then(function(){say('✅ 3) نجی ڈیٹا لکھنا ٹھیک — اب سنک اور بیک اپ چلے گا');SB.save({cloudErr:''})},function(e){say('❌ 3) '+explain(e))})}).then(function(){
  var n=SB.native();if(n&&n.isNotificationAccessGranted)say(n.isNotificationAccessGranted()?'✅ 4) واٹس ایپ نوٹیفکیشن رسائی فعال':'❌ 4) نوٹیفکیشن رسائی بند — "🔔 نوٹیفکیشن رسائی دیں" دبائیں');if(n&&n.isBatteryUnrestricted)say(n.isBatteryUnrestricted()?'✅ 5) بیٹری پابندی ہٹی ہوئی ہے':'⚠️ 5) بیٹری پابندی ہے — ایپ بند ہونے پر آرڈر الرٹ دیر سے آ سکتا ہے۔ "🔋 بیٹری پابندی ہٹائیں" دبائیں')})};
/* one tap: make everything active (used after restoring a backup too) */
SB.setupAll=function(){SB.toast('سیٹ اپ چل رہا ہے…');try{vault()}catch(e){}var n=SB.native();if(n&&n.setWaKeywords)n.setWaKeywords(S().waKeywords||'');
 return SB.cloudTest().then(function(){return SB.cloudMerge(true)}).then(function(){return SB.cloudCatalog(true)}).then(function(){SB.toast('✅ سیٹ اپ مکمل — نتیجہ نیچے دیکھیں')})};
document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){var s=SB.stored&&SB.stored();try{var raw=JSON.parse(localStorage.getItem('starbags_settings_v60')||'{}');var fix={};if(!raw.cloudUrl)fix.cloudUrl=DEF_DB;if(!raw.shopId)fix.shopId=DEF_SHOP;if(!raw.catalogSite)fix.catalogSite='https://starbags1.netlify.app';if(Object.keys(fix).length)SB.save(fix)}catch(e){}},500)});
/* GST / NTN lines on both receipts (uses the app's own custom print rows) */
SB.applyGst=function(){var s=SB.settings(),K='starbags_bill_print_settings_v1',v=SB.jget(K,{fields:{},custom:[]});v.custom=(v.custom||[]).filter(function(x){return String(x.label||'').indexOf('\u2060')!==0});
 if(s.gstOn){if(s.gstNo)v.custom.push({label:'\u2060GST/NTN',value:s.gstNo});if(Number(s.gstPct)>0)v.custom.push({label:'\u2060GST',value:'قیمتوں میں '+s.gstPct+'% شامل'})}SB.jset(K,v);if(window.starBagsApplyPrintSettings)try{window.starBagsApplyPrintSettings()}catch(e){}};
document.addEventListener('change',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sk');if(k==='gstOn'||k==='gstPct'||k==='gstNo'){setTimeout(function(){SB.applyGst();SB.toast('GST لائن اپڈیٹ — اگلے بل پیش منظر میں نظر آئے گی')},50)}},false);
})();
