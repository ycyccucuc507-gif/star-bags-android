/* STAR BAGS V6 — online: cloud backup/sync (Firebase REST), online catalog, GST print lines */
(function(){'use strict';var SB=window.SB,$=function(id){return document.getElementById(id)};
function msg(t){var m=$('sbCloudMsg');if(m)m.textContent=t;SB.toast(t)}
function base(){var s=SB.settings();var u=(s.cloudUrl||'').trim().replace(/\/+$/,'');if(!u||!/^https:\/\//i.test(u)){msg('پہلے https والا ڈیٹابیس لنک لکھیں');return null}if(!s.shopId){msg('دکان ID لکھیں');return null}return u}
function url(path){var s=SB.settings(),u=base();if(!u)return null;return u+'/'+path+'.json'+(s.cloudSecret?'?auth='+encodeURIComponent(s.cloudSecret):'')}
function slug(){return String(SB.settings().shopId).replace(/[^A-Za-z0-9_-]/g,'')}
SB.cloudPush=function(silent){if(!navigator.onLine){msg('انٹرنیٹ نہیں ہے');return Promise.resolve(false)}var u=url('starbags/'+slug());if(!u)return Promise.resolve(false);
 var d=SB.buildBackup();delete d.sbV60;d.device=SB.settings().deviceId||'';if(!silent)msg('اپ لوڈ ہو رہا ہے…');
 return fetch(u,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);SB.save({lastCloudAt:Date.now()});if(!silent)msg('✅ کلاؤڈ پر اپ لوڈ ہو گیا');return true}).catch(function(e){msg('اپ لوڈ ناکام: '+e.message);return false})};
var MERGE=[['products','starbags_products_v2','id'],['bills','starbags_bills_v2','id'],['purchases','starbags_purchases_v1','id'],['expenses','starbags_expenses_v2','id'],['laborLedger','starbags_labor_ledger_v1','id'],['stockAdjustments','starbags_stock_adjustments_v2','id'],['partyPayments','starbags_party_payments_v1','id'],['supplierPayments','starbags_supplier_payments_v1','id'],['storeOrders','starbags_store_orders_v1','id'],['parties','starbags_parties_v1','name']];
SB.mergeInto=function(remote){var changed=0;MERGE.forEach(function(m){var rem=remote[m[0]];if(!Array.isArray(rem))return;var loc=SB.jget(m[1],[]),idx={};loc.forEach(function(x,i){idx[String(m[2]==='name'?SB.norm(x.name):x[m[2]])]=i});
  rem.forEach(function(r){var k=String(m[2]==='name'?SB.norm(r.name):r[m[2]]);if(!(k in idx)){loc.push(r);idx[k]=loc.length-1;changed++}else if(r.updatedAt&&String(r.updatedAt)>String(loc[idx[k]].updatedAt||'')){loc[idx[k]]=r;changed++}});
  if(changed||true)SB.jset(m[1],loc)});
 var seqR=Number(remote.seq||0),seqL=Number(localStorage.getItem('starbags_seq_v2')||0);if(seqR>seqL)localStorage.setItem('starbags_seq_v2',String(seqR));return changed};
SB.cloudMerge=function(silent){if(!navigator.onLine){msg('انٹرنیٹ نہیں ہے');return Promise.resolve(false)}var u=url('starbags/'+slug());if(!u)return Promise.resolve(false);if(!silent)msg('ڈاؤن لوڈ ہو رہا ہے…');
 return fetch(u).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}).then(function(d){if(!d||!Array.isArray(d.bills)){msg('کلاؤڈ پر ابھی ڈیٹا نہیں — پہلے اپ لوڈ کریں');return false}
  var c=SB.mergeInto(d);SB.save({lastCloudAt:Date.now()});return SB.cloudPush(true).then(function(){msg('✅ ضم ہو گیا ('+c+' نئے/اپڈیٹ ریکارڈ)');if(c>0&&!silent)setTimeout(function(){location.reload()},900);return c})}).catch(function(e){msg('سنک ناکام: '+e.message);return false})};
/* auto-sync */
function auto(){var s=SB.settings();if(!s.cloudAuto||!s.cloudUrl||!s.shopId||!navigator.onLine)return;if(Date.now()-(s.lastCloudAt||0)<10*60000)return;SB.cloudMerge(true)}
window.addEventListener('sb-online',function(){setTimeout(auto,1500)});setInterval(auto,10*60000);document.addEventListener('DOMContentLoaded',function(){setTimeout(auto,6000)});
/* online catalog: products → cloud (small thumbnails) ; customers open catalog_web/index.html?u=<db>&s=<shop> */
SB.cloudCatalog=function(){var s=SB.settings();if(!s.waNumber){alert('پہلے سیٹنگ ← WhatsApp میں اپنا نمبر لکھیں تاکہ گاہک کا آرڈر آپ کو آئے۔');return}var u=url('starbags_catalog/'+slug());if(!u)return;
 var ps=SB.jget('starbags_products_v2',[]).slice(0,80),st=SB.stock();msg('کیٹلاگ تیار ہو رہا ہے…');
 function thumb(src){return new Promise(function(res){if(!src||String(src).indexOf('data:image')!==0)return res('');var im=new Image();im.onload=function(){var sc=Math.min(1,220/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',0.6))};im.onerror=function(){res('')};im.src=src})}
 Promise.all(ps.map(function(p){var k=SB.norm(p.name);return thumb(p.image||(p.images&&p.images[0])).then(function(t){return{n:p.name,d:p.keyword||'',p:Number(p.sell||0),s:st[k]?st[k].stock:null,i:t}})})).then(function(items){
  var o=SB.jget('starbags_store_item_overrides_v2',{});return fetch(u,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:localStorage.getItem('starbags_company_name_v1')||'STAR BAGS',wa:String(s.waNumber).replace(/\D/g,''),updated:Date.now(),items:items})})}).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);
  var link='catalog_web/index.html?u='+encodeURIComponent(s.cloudUrl.trim().replace(/\/+$/,''))+'&s='+slug();msg('✅ کیٹلاگ شائع ہو گیا');SB.lastCatalogLink=link;
  var n=SB.native();prompt('گاہکوں کے لیے لنک: catalog_web فولڈر کو کسی مفت ہوسٹنگ (Netlify / GitHub Pages) پر رکھ کر آخر میں یہ حصہ جوڑیں:',link.replace('catalog_web/index.html',''))}).catch(function(e){msg('کیٹلاگ ناکام: '+e.message)})};
/* GST / NTN lines on both receipts (uses the app's own custom print rows) */
SB.applyGst=function(){var s=SB.settings(),K='starbags_bill_print_settings_v1',v=SB.jget(K,{fields:{},custom:[]});v.custom=(v.custom||[]).filter(function(x){return String(x.label||'').indexOf('\u2060')!==0});
 if(s.gstOn){if(s.gstNo)v.custom.push({label:'\u2060GST/NTN',value:s.gstNo});if(Number(s.gstPct)>0)v.custom.push({label:'\u2060GST',value:'قیمتوں میں '+s.gstPct+'% شامل'})}SB.jset(K,v);if(window.starBagsApplyPrintSettings)try{window.starBagsApplyPrintSettings()}catch(e){}};
document.addEventListener('change',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sk');if(k==='gstOn'||k==='gstPct'||k==='gstNo'){setTimeout(function(){SB.applyGst();SB.toast('GST لائن اپڈیٹ — اگلے بل پیش منظر میں نظر آئے گی')},50)}},false);
})();
