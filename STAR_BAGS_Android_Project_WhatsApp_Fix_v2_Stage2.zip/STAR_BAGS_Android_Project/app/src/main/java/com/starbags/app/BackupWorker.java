package com.starbags.app;

import android.content.Context;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Periodically copies the most recent WebView snapshot; no cloud service is required. */
public class BackupWorker extends Worker {
    public BackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    @NonNull @Override public Result doWork() {
        Context c=getApplicationContext();
        try {
            File src=new File(c.getFilesDir(), "latest_backup.json");
            if(!src.exists() || src.length()<20) throw new IllegalStateException("ابھی تک کوئی مکمل مقامی بیک اپ Snapshot موجود نہیں۔ ایپ کھول کر چند لمحے استعمال کریں۔");
            String stamp=new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
            String name="STAR-BAGS-backup-"+stamp+".json";
            android.content.SharedPreferences p=c.getSharedPreferences("star_bags_backup",Context.MODE_PRIVATE);
            String tree=p.getString("folder_uri","");
            if(tree!=null&&!tree.isEmpty()) {
                DocumentFile dir=DocumentFile.fromTreeUri(c,Uri.parse(tree));
                if(dir==null||!dir.canWrite()) throw new IllegalStateException("منتخب بیک اپ فولڈر دستیاب نہیں؛ دوبارہ فولڈر منتخب کریں۔");
                DocumentFile out=dir.createFile("application/json",name);
                if(out==null) throw new IllegalStateException("بیک اپ فائل نہیں بن سکی۔");
                try(FileInputStream in=new FileInputStream(src);OutputStream os=c.getContentResolver().openOutputStream(out.getUri())) { if(os==null)throw new IllegalStateException("فولڈر میں لکھنا ممکن نہیں۔"); byte[] b=new byte[16384];int n;while((n=in.read(b))>0)os.write(b,0,n);os.flush(); }
            } else {
                File dir=new File(c.getExternalFilesDir(null),"STAR BAGS/auto_backup"); if(!dir.exists()&&!dir.mkdirs())throw new IllegalStateException("فون میں بیک اپ فولڈر نہیں بن سکا۔");
                File dest=new File(dir,name);try(FileInputStream in=new FileInputStream(src);java.io.FileOutputStream os=new java.io.FileOutputStream(dest)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)os.write(b,0,n);os.getFD().sync();}
                File[] files=dir.listFiles((d,f)->f.startsWith("STAR-BAGS-backup-"));if(files!=null&&files.length>30){java.util.Arrays.sort(files,(a,b)->Long.compare(a.lastModified(),b.lastModified()));for(int i=0;i<files.length-30;i++)files[i].delete();}
            }
            long now=System.currentTimeMillis(),interval=Math.max(15,p.getLong("interval_minutes",30));p.edit().putLong("last_backup_at",now).putLong("next_backup_at",now+interval*60000L).putString("last_error","").apply();
            return Result.success();
        } catch(Throwable e) {
            c.getSharedPreferences("star_bags_backup",Context.MODE_PRIVATE).edit().putString("last_error",String.valueOf(e.getMessage())).apply();
            try { if (android.os.Build.VERSION.SDK_INT < 33 || androidx.core.content.ContextCompat.checkSelfPermission(c, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                android.app.NotificationManager nm=(android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
                if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new android.app.NotificationChannel("star_bags_backup_fail","STAR BAGS Backup Alerts",android.app.NotificationManager.IMPORTANCE_HIGH));
                android.app.Notification.Builder nb=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(c,"star_bags_backup_fail"):new android.app.Notification.Builder(c);
                nb.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle("STAR BAGS بیک اپ ناکام").setContentText(String.valueOf(e.getMessage())).setAutoCancel(true);nm.notify(1045,nb.build());
            }} catch(Throwable ignored) {}
            android.util.Log.e("STAR_BAGS_BACKUP","Scheduled backup failed",e);return Result.retry();
        }
    }
}
