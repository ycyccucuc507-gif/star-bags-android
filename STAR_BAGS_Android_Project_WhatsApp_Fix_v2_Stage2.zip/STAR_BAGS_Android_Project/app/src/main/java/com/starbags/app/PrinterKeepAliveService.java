package com.starbags.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** Keeps the shared Bluetooth printer socket alive while the app is backgrounded.
 * The socket is closed after 30 minutes without a printer-related activity.
 */
public class PrinterKeepAliveService extends Service {
    private static final String CHANNEL_ID = "star_bags_printer_connection";
    private static final int NOTIFICATION_ID = 4204;
    private static final long INACTIVITY_TIMEOUT_MS = 30L * 60L * 1000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable timeout = () -> {
        MainActivity.closeSharedPrinterSocket();
        stopForeground(true);
        stopSelf();
    };

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        handler.removeCallbacks(timeout);
        handler.postDelayed(timeout, INACTIVITY_TIMEOUT_MS);
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "STAR BAGS Printer", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Bluetooth thermal printer connection is being kept available");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("STAR BAGS — پرنٹر کنیکٹ ہے")
                .setContentText("غیرفعال ہونے کے 30 منٹ بعد خودکار Disconnect ہوگا")
                .setOngoing(true)
                .build();
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep the foreground service/socket active when the app is swiped from Recents.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(timeout);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
