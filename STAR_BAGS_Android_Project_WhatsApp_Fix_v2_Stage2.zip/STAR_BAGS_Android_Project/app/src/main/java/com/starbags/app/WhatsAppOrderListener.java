package com.starbags.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Reads WhatsApp / WhatsApp Business notifications (only after the owner grants "Notification access")
 * and keeps ONLY messages that contain one of the owner's order keywords. Everything else is ignored.
 */
public class WhatsAppOrderListener extends NotificationListenerService {
    static final String PREFS = "star_bags_wa";
    private static final String CHANNEL = "star_bags_orders";

    /** MainActivity sets this while it is on screen so a new order shows up in the app immediately. */
    static volatile Runnable arrivalHook;

    @Override public void onListenerDisconnected() {
        super.onListenerDisconnected();
        try { if (Build.VERSION.SDK_INT >= 24) requestRebind(new android.content.ComponentName(this, WhatsAppOrderListener.class)); } catch (Throwable ignored) { }
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null) return;
            String pkg = sbn.getPackageName();
            if (!"com.whatsapp".equals(pkg) && !"com.whatsapp.w4b".equals(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle e = n.extras;
            if (e == null) return;
            CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
            String from = title == null ? "WhatsApp" : title.toString();
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String kws = sp.getString("keywords", "");
            String phone = senderPhone(sbn, n, e);
            boolean any = false;
            java.util.List<String[]> msgs = collectMessages(e, sbn.getPostTime());
            for (String[] m : msgs) {
                String body = m[0];
                if (body == null || body.trim().isEmpty() || !matches(body, kws)) continue;
                String id = Integer.toHexString((from + "|" + body).hashCode()) + "-" + m[1];
                if (!enqueue(this, id, from, body, Long.parseLong(m[1]) * 1000L, phone)) continue;
                any = true;
                alert(from, body);
            }
            if (any) { Runnable h = arrivalHook; if (h != null) h.run(); }
        } catch (Throwable ignored) { }
    }

    /**
     * Every message text WhatsApp put in the notification. A multi-line order is cut short in EXTRA_TEXT,
     * so we prefer the full MessagingStyle list, then the big text, then the plain text.
     * Returns {text, timeInSeconds} pairs.
     */
    private static java.util.List<String[]> collectMessages(Bundle e, long postTime) {
        java.util.List<String[]> out = new java.util.ArrayList<>();
        try {
            android.os.Parcelable[] arr = e.getParcelableArray("android.messages");
            if (arr != null) {
                for (android.os.Parcelable p : arr) {
                    if (!(p instanceof Bundle)) continue;
                    Bundle b = (Bundle) p;
                    CharSequence t = b.getCharSequence("text");
                    if (t == null) continue;
                    long tm = b.getLong("time", postTime);
                    out.add(new String[]{t.toString(), String.valueOf(tm / 1000L)});
                }
            }
        } catch (Throwable ignored) { }
        if (!out.isEmpty()) return out;
        String best = "";
        try {
            CharSequence big = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
            CharSequence txt = e.getCharSequence(Notification.EXTRA_TEXT);
            if (big != null && big.length() > best.length()) best = big.toString();
            if (txt != null && txt.length() > best.length()) best = txt.toString();
            CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null && lines.length > 0) {
                StringBuilder sb = new StringBuilder();
                for (CharSequence l : lines) { if (l != null) { if (sb.length() > 0) sb.append('\n'); sb.append(l); } }
                if (sb.length() > best.length()) best = sb.toString();
            }
        } catch (Throwable ignored) { }
        if (!best.isEmpty()) out.add(new String[]{best, String.valueOf(postTime / 60000L * 60L)});
        return out;
    }

    /** Urdu spelling variants / diacritics / zero-width marks removed so "آرڈر", "ارڈر", "اردر" all match. */
    static String norm(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(Locale.ROOT)
                .replaceAll("[\\u064B-\\u065F\\u0670\\u200B-\\u200F\\u202A-\\u202E\\u2066-\\u2069\\uFEFF*_~]", "");
        return t.replace('آ', 'ا').replace('أ', 'ا').replace('ي', 'ی').replace('ى', 'ی').replace('ے', 'ی')
                .replace('ك', 'ک').replace('ة', 'ہ').replace('ۃ', 'ہ').replace('ھ', 'ہ').replace('ڈ', 'د').replace('ٹ', 'ت')
                .replace('ڑ', 'ر').replace('ں', 'ن').replace('ئ', 'ی').replace('ؤ', 'و');
    }

    private static boolean matches(String body, String keywords) {
        String low = norm(body);
        /* the catalog's own order message is always an order, whatever keywords the owner saved */
        if (low.contains("ارد") && low.contains("×")) return true;
        if (low.contains("order") || low.contains("ارڈر") || low.contains("اردر") || low.contains("آرڈر")) return true;
        if (keywords == null) return false;
        for (String k : keywords.split(",")) {
            String t = norm(k.trim()).replaceAll("[:：؛،,.!؟?۔]+$", "").trim();
            if (!t.isEmpty() && low.contains(t)) return true;
        }
        return false;
    }

    /** Best effort: the real WhatsApp number of the sender (digits only) so the app can match it to a saved party. */
    private static String senderPhone(StatusBarNotification sbn, Notification n, Bundle e) {
        try {
            String d = jidDigits(sbn.getTag());
            if (d != null) return d;
            if (Build.VERSION.SDK_INT >= 26) { d = jidDigits(n.getShortcutId()); if (d != null) return d; }
            Object ppl = e.get("android.people.list");
            if (ppl instanceof java.util.List) {
                for (Object o : (java.util.List<?>) ppl) {
                    String s = o == null ? null : o.toString();
                    if (Build.VERSION.SDK_INT >= 28 && o instanceof android.app.Person) {
                        android.app.Person pr = (android.app.Person) o;
                        s = pr.getUri() != null ? pr.getUri() : pr.getKey();
                    }
                    d = jidDigits(s); if (d != null) return d;
                }
            }
        } catch (Throwable ignored) { }
        return "";
    }

    /** "923017265085@s.whatsapp.net" or "tel:+92301..." -> digits; groups (@g.us) are ignored. */
    private static String jidDigits(String s) {
        if (s == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{9,15})@(?:s\\.whatsapp\\.net|c\\.us)").matcher(s);
        if (m.find()) return m.group(1);
        m = java.util.regex.Pattern.compile("tel:\\+?([\\d\\s-]{9,20})").matcher(s);
        if (m.find()) { String d = m.group(1).replaceAll("\\D", ""); if (d.length() >= 9) return d; }
        return null;
    }

    static synchronized boolean enqueue(Context c, String id, String from, String text, long t) { return enqueue(c, id, from, text, t, ""); }

    static synchronized boolean enqueue(Context c, String id, String from, String text, long t, String phone) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
            String seen = sp.getString("seen", "");
            if (seen.contains(id)) return false;
            if (seen.length() > 4000) seen = seen.substring(seen.length() / 2);
            JSONArray q = new JSONArray(sp.getString("queue", "[]"));
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("t", t);
            o.put("from", from);
            o.put("text", text);
            o.put("phone", phone == null ? "" : phone);
            q.put(o);
            while (q.length() > 200) q.remove(0);
            sp.edit().putString("queue", q.toString()).putString("seen", seen + "," + id).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    static synchronized String drain(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        String q = sp.getString("queue", "[]");
        sp.edit().putString("queue", "[]").apply();
        return q;
    }

    private void alert(String from, String body) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "STAR BAGS آرڈر الرٹ", NotificationManager.IMPORTANCE_HIGH);
                ch.enableVibration(true);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("sbOrders", true);
            PendingIntent pi = PendingIntent.getActivity(this, 7001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle("📥 نیا آرڈر — " + from)
                    .setContentText(body.replace('\n', ' '))
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setContentIntent(pi);
            if (Build.VERSION.SDK_INT < 26) { b.setPriority(Notification.PRIORITY_HIGH); b.setDefaults(Notification.DEFAULT_ALL); }
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        } catch (Throwable ignored) { }
    }
}
