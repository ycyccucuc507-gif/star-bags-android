package com.starbags.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Reads WhatsApp / WhatsApp Business notifications (only after the owner grants "Notification access")
 * and keeps ONLY messages that contain one of the owner's order keywords. Everything else is ignored.
 */
public class WhatsAppOrderListener extends NotificationListenerService {
    static final String PREFS = "star_bags_wa";
    private static final String CHANNEL = "star_bags_orders";

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null) return;
            String pkg = sbn.getPackageName();
            if (!"com.whatsapp".equals(pkg) && !"com.whatsapp.w4b".equals(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle e = n.extras;
            if (e == null) return;
            CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = e.getCharSequence(Notification.EXTRA_TEXT);
            if (text == null) return;
            String body = text.toString();
            String from = title == null ? "WhatsApp" : title.toString();
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String kws = sp.getString("keywords", "");
            if (!matches(body, kws)) return;
            String id = Integer.toHexString((from + "|" + body).hashCode()) + "-" + (sbn.getPostTime() / 60000L);
            if (!enqueue(this, id, from, body, sbn.getPostTime(), senderPhone(sbn, n, e))) return;
            alert(from, body);
        } catch (Throwable ignored) { }
    }

    private static boolean matches(String body, String keywords) {
        if (keywords == null || keywords.trim().isEmpty()) return false;
        String low = body.toLowerCase(Locale.ROOT);
        for (String k : keywords.split(",")) {
            // Accept saved keywords with optional punctuation (e.g. "آرڈر:"),
            // because catalog messages contain the plain word "آرڈر".
            String t = k.trim().toLowerCase(Locale.ROOT)
                    .replaceAll("[:：؛،,.!؟?۔]+$", "").trim();
            if (!t.isEmpty() && low.contains(t)) return true;
        }
        return false;
    }

    /** Best effort: the real WhatsApp number of the sender (digits only) so the app can match it to a saved party. */
    private static String senderPhone(StatusBarNotification sbn, Notification n, Bundle e) {
        try {
            String d = jidDigits(sbn.getTag());
            if (d != null) return d;
            if (Build.VERSION.SDK_INT >= 26) { d = jidDigits(n.getShortcutId()); if (d != null) return d; }
            Object ppl = e.get("android.people.list");
            if (ppl instanceof java.util.List) {
                for (Object o : (java.util.List<?>) ppl) {
                    String s = o == null ? null : o.toString();
                    if (Build.VERSION.SDK_INT >= 28 && o instanceof android.app.Person) {
                        android.app.Person pr = (android.app.Person) o;
                        s = pr.getUri() != null ? pr.getUri() : pr.getKey();
                    }
                    d = jidDigits(s); if (d != null) return d;
                }
            }
        } catch (Throwable ignored) { }
        return "";
    }

    /** "923017265085@s.whatsapp.net" or "tel:+92301..." -> digits; groups (@g.us) are ignored. */
    private static String jidDigits(String s) {
        if (s == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{9,15})@(?:s\\.whatsapp\\.net|c\\.us)").matcher(s);
        if (m.find()) return m.group(1);
        m = java.util.regex.Pattern.compile("tel:\\+?([\\d\\s-]{9,20})").matcher(s);
        if (m.find()) { String d = m.group(1).replaceAll("\\D", ""); if (d.length() >= 9) return d; }
        return null;
    }

    static synchronized boolean enqueue(Context c, String id, String from, String text, long t) { return enqueue(c, id, from, text, t, ""); }

    static synchronized boolean enqueue(Context c, String id, String from, String text, long t, String phone) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
            String seen = sp.getString("seen", "");
            if (seen.contains(id)) return false;
            if (seen.length() > 4000) seen = seen.substring(seen.length() / 2);
            JSONArray q = new JSONArray(sp.getString("queue", "[]"));
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("t", t);
            o.put("from", from);
            o.put("text", text);
            o.put("phone", phone == null ? "" : phone);
            q.put(o);
            while (q.length() > 200) q.remove(0);
            sp.edit().putString("queue", q.toString()).putString("seen", seen + "," + id).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    static synchronized String drain(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        String q = sp.getString("queue", "[]");
        sp.edit().putString("queue", "[]").apply();
        return q;
    }

    private void alert(String from, String body) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "STAR BAGS آرڈر الرٹ", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 7001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle("📥 نیا آرڈر پیغام — " + from)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        } catch (Throwable ignored) { }
    }
}
