package com.starbags.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class SeasonReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "star_bags_season_planner";

    @Override public void onReceive(Context context, Intent intent) {
        if (!context.getSharedPreferences("star_bags_reminders", Context.MODE_PRIVATE).getBoolean("enabled", false)) return;
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            java.util.Calendar first = java.util.Calendar.getInstance();
            first.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY);
            first.set(java.util.Calendar.HOUR_OF_DAY, 9); first.set(java.util.Calendar.MINUTE, 0); first.set(java.util.Calendar.SECOND, 0); first.set(java.util.Calendar.MILLISECOND, 0);
            if (first.getTimeInMillis() <= System.currentTimeMillis()) first.add(java.util.Calendar.DAY_OF_YEAR, 7);
            Intent reminder = new Intent(context, SeasonReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, 1202, reminder, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.AlarmManager alarm = (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm != null) alarm.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP, first.getTimeInMillis(), android.app.AlarmManager.INTERVAL_DAY * 7, pi);
            return;
        }
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "STAR BAGS سیزن پلانر", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("ہفتہ وار کاروباری سیزن اور اسٹاک یاددہانی");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 1203, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = context.getSharedPreferences("star_bags_reminders", Context.MODE_PRIVATE).getString("title", "STAR BAGS سیزن پلانر");
        String body = context.getSharedPreferences("star_bags_reminders", Context.MODE_PRIVATE).getString("body", "اگلے 4–8 ہفتوں کی تیاری کا پلان دیکھیں۔");
        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, CHANNEL_ID)
                : new android.app.Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_menu_agenda)
                .setContentTitle(title).setContentText(body).setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent).setAutoCancel(true);
        manager.notify(1204, builder.build());
    }
}
