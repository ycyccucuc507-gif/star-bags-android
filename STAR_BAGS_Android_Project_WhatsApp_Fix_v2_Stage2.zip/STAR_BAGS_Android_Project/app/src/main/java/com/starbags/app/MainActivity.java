package com.starbags.app;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_BACKUP = 1002;
    private static final int PICK_CONTACT = 1003;
    private static final int BT_PERMISSION_REQUEST = 1202;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket thermalSocket;
    private String thermalPrinterAddress = "";
    private static final int BRAND = Color.rgb(24, 59, 99);

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private FrameLayout root;
    private View splashView;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingBackupBytes;
    private String pendingBackupName = "star-bags-backup.json";
    private String pendingBackupMime = "application/json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(BRAND);
        getWindow().setNavigationBarColor(BRAND);
        getWindow().getDecorView().setSystemUiVisibility(0);

        root = new FrameLayout(this);
        root.setBackgroundColor(BRAND);
        root.setClipToPadding(false);

        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setColorSchemeColors(BRAND, Color.rgb(49, 91, 135));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        swipeRefresh.addView(webView, new SwipeRefreshLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(swipeRefresh, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);

        showSplash();
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setBuiltInZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new StarBagsBridge(), "StarBagsAndroid");
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(view, url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(view, request.getUrl().toString());
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideSplash();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent chooserIntent = params.createIntent();
                    // WebView's default chooser does not consistently request multi-select.
                    // Explicitly enable it for <input type="file" multiple>.
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        chooserIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(chooserIntent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    if (fileCallback != null) fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "فائل منتخب کرنے کی سہولت نہیں کھل سکی۔", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.startsWith("blob:")) return; // Blob backups use the native bridge below.
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                if (mimeType != null) request.setMimeType(mimeType);
                if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(filename);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
            } catch (Exception e) {
                Toast.makeText(this, "فائل ڈاؤن لوڈ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
            }
        });

        swipeRefresh.setOnChildScrollUpCallback((parent, child) -> webView != null && webView.canScrollVertically(-1));
        swipeRefresh.setOnRefreshListener(() -> {
            if (webView == null) {
                swipeRefresh.setRefreshing(false);
                return;
            }
            webView.evaluateJavascript(
                    "(function(){if(window.starBagsGoHomeFromRefresh){window.starBagsGoHomeFromRefresh();}else if(window.showModule){window.showModule('home');window.scrollTo(0,0);}})();",
                    value -> { if (swipeRefresh != null) swipeRefresh.setRefreshing(false); });
        });

        if (state == null) webView.loadUrl("file:///android_asset/index.html");
        else {
            webView.restoreState(state);
            if (webView.getUrl() == null) webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BRAND);
        splash.setPadding(28, 32, 28, 32);

        ImageView logo = new ImageView(this);
        try { logo.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("star_bags_logo.jpg"), null)); }
        catch (Exception ignored) {}
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(220), dp(160));
        logoParams.bottomMargin = dp(18);
        splash.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("STAR BAGS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));

        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        progressParams.topMargin = dp(22);
        splash.addView(progress, progressParams);

        splashView = splash;
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideSplash() {
        if (splashView != null && root != null) {
            root.removeView(splashView);
            splashView = null;
        }
    }

    private boolean routeUrl(WebView view, String rawUrl) {
        if (rawUrl == null) return false;
        try {
            if (rawUrl.startsWith("intent://")) {
                Uri intentUri = Uri.parse(rawUrl);
                launchWhatsApp(intentUri.getQueryParameter("phone"), intentUri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("intent:")) {
                try { startActivity(Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME)); }
                catch (Exception ignored) { Toast.makeText(this, "یہ Android آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
                return true;
            }
            Uri uri = Uri.parse(rawUrl);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (host.equals("wa.me") || host.endsWith(".wa.me") || host.equals("api.whatsapp.com")) {
                String phone = uri.getQueryParameter("phone");
                if (phone == null || phone.isEmpty()) {
                    java.util.List<String> segments = uri.getPathSegments();
                    if (!segments.isEmpty()) phone = segments.get(0);
                }
                launchWhatsApp(phone, uri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("https://") || rawUrl.startsWith("http://") || rawUrl.startsWith("tel:") || rawUrl.startsWith("mailto:")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (Exception e) { return rawUrl.startsWith("http"); }
            }
        } catch (Exception ignored) {
            return true;
        }
        return false;
    }

    private void launchWhatsApp(String phone, String message) {
        String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        Uri chat = Uri.parse("https://wa.me/" + number + (message == null || message.isEmpty() ? "" : "?text=" + Uri.encode(message)));
        Intent business = new Intent(Intent.ACTION_VIEW, chat);
        business.setPackage("com.whatsapp.w4b");
        try { startActivity(business); return; } catch (Exception ignored) {}
        Intent normal = new Intent(Intent.ACTION_VIEW, chat);
        normal.setPackage("com.whatsapp");
        try { startActivity(normal); return; } catch (Exception ignored) {}
        try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, chat), "WhatsApp کھولیں")); }
        catch (Exception e) { Toast.makeText(this, "WhatsApp دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
    }

    private void saveBackupBytes(byte[] bytes, String filename, String mimeType) {
        pendingBackupBytes = bytes;
        pendingBackupName = filename == null || filename.trim().isEmpty() ? "star-bags-backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
        pendingBackupMime = mimeType == null || mimeType.isEmpty() ? "application/json" : mimeType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingBackupName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, pendingBackupMime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/STAR BAGS");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Downloads provider unavailable");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Unable to open output");
                    out.write(bytes);
                    out.flush();
                } catch (Exception writeError) {
                    getContentResolver().delete(uri, null, null);
                    throw writeError;
                }
                ContentValues complete = new ContentValues();
                complete.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, complete, null, null);
                pendingBackupBytes = null;
                Toast.makeText(this, "بیک اپ Downloads/STAR BAGS میں محفوظ ہوگیا۔", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception e) {
                // Use the Android document picker if Downloads storage is unavailable.
            }
        }
        try {
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType(pendingBackupMime);
            create.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
            startActivityForResult(create, CREATE_BACKUP);
        } catch (Exception e) {
            Toast.makeText(this, "بیک اپ محفوظ کرنے کا آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show();
            pendingBackupBytes = null;
        }
    }


    private boolean hasBluetoothConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void sendPrinterCallback(String callback, String json) {
        if (webView == null || callback == null || !callback.matches("[A-Za-z_$][A-Za-z0-9_$]*")) return;
        final String script = "window." + callback + " && window." + callback + "(" + json + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void printerError(String callback, String message) {
        try {
            org.json.JSONObject result = new org.json.JSONObject();
            result.put("ok", false); result.put("message", message);
            sendPrinterCallback(callback, result.toString());
        } catch (Exception ignored) {}
    }

    private void ensureBluetoothPermission(String callback) {
        if (Build.VERSION.SDK_INT >= 31 && !hasBluetoothConnectPermission()) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, BT_PERMISSION_REQUEST));
            printerError(callback, "Bluetooth اجازت درکار ہے۔ اجازت دینے کے بعد دوبارہ بٹن دبائیں۔");
        }
    }


    private void renderBillForThermalPrinter(String billHtml, int paperDots, String callback) {
        final WebView receiptView = new WebView(this);
        receiptView.setBackgroundColor(Color.WHITE);
        receiptView.getSettings().setJavaScriptEnabled(false);
        int widthPx = paperDots;
        String safeHtml = billHtml;
        String document = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>" +
                "<style>html,body{margin:0;padding:0;width:" + widthPx + "px;background:#fff;color:#000;font-family:Arial,'Noto Naskh Arabic',sans-serif;font-size:14px;line-height:1.35}" +
                "*{box-sizing:border-box;color:#000!important;background-color:transparent!important;box-shadow:none!important;text-shadow:none!important}" +
                "body{padding:8px}img{max-width:100%;height:auto}table{width:100%!important;border-collapse:collapse!important;table-layout:auto!important;font-size:12px!important}" +
                "th,td{border-bottom:1px dashed #555!important;padding:4px 2px!important;text-align:right!important;overflow-wrap:anywhere!important}" +
                "h1,h2,h3,p{margin:4px 0!important} .bill-banner{display:flex!important;flex-wrap:wrap!important;border-bottom:1px dashed #000!important;padding-bottom:6px!important}" +
                ".bill-logo{max-width:65px!important;max-height:45px!important;object-fit:contain!important} .moneybox{border-top:1px dashed #000!important;padding-top:5px!important}" +
                "button{display:none!important}</style></head><body dir='rtl'>" + safeHtml + "</body></html>";
        receiptView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.documentElement.scrollHeight", value -> {
                    int contentHeight;
                    try { contentHeight = Integer.parseInt(value.replace("\"", "")); }
                    catch (Exception e) { contentHeight = 900; }
                    contentHeight = Math.max(100, Math.min(contentHeight, 12000));
                    view.measure(View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                    view.layout(0, 0, widthPx, contentHeight);
                    android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(widthPx, contentHeight, android.graphics.Bitmap.Config.ARGB_8888);
                    android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
                    canvas.drawColor(Color.WHITE);
                    view.draw(canvas);
                    view.destroy();
                    new Thread(() -> sendReceiptBitmapToPrinter(bitmap, callback, paperDots)).start();
                });
            }
        });
        receiptView.loadDataWithBaseURL("file:///android_asset/", document, "text/html", "UTF-8", null);
    }

    private void sendReceiptBitmapToPrinter(android.graphics.Bitmap bitmap, String callback, int paperDots) {
        try {
            if (!hasBluetoothConnectPermission()) throw new SecurityException("Bluetooth اجازت درکار ہے۔");
            if (thermalSocket == null || !thermalSocket.isConnected()) {
                String saved = getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", "");
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null || !adapter.isEnabled()) throw new IOException("موبائل Bluetooth آن کریں۔");
                if (saved.isEmpty()) {
                    for (BluetoothDevice device : adapter.getBondedDevices()) {
                        String name = device.getName();
                        if (name != null && name.toUpperCase().contains("MPT-II")) { saved = device.getAddress(); break; }
                    }
                }
                if (saved.isEmpty()) throw new IOException("MPT-II Pair نہیں ہے۔ پہلے موبائل Bluetooth Settings میں MPT-II Pair کریں، پھر Print Bill دبائیں۔");
                connectThermalPrinter(saved);
            }
            int w = bitmap.getWidth(), h = bitmap.getHeight();
            int bytesPerRow = (w + 7) / 8;
            byte[] raster = new byte[bytesPerRow * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int pixel = bitmap.getPixel(x, y);
                    int gray = (android.graphics.Color.red(pixel) * 299 + android.graphics.Color.green(pixel) * 587 + android.graphics.Color.blue(pixel) * 114) / 1000;
                    if (gray < 175) raster[y * bytesPerRow + (x / 8)] |= (byte)(0x80 >> (x % 8));
                }
            }
            bitmap.recycle();
            OutputStream out = thermalSocket.getOutputStream();
            synchronized (this) {
                out.write(new byte[]{0x1B, 0x40});
                out.write(new byte[]{0x1B, 0x61, 0x00});
                int offset = 0;
                while (offset < h) {
                    int rows = Math.min(200, h - offset);
                    out.write(new byte[]{0x1D, 0x76, 0x30, 0x00,
                            (byte)(bytesPerRow & 0xFF), (byte)((bytesPerRow >> 8) & 0xFF),
                            (byte)(rows & 0xFF), (byte)((rows >> 8) & 0xFF)});
                    out.write(raster, offset * bytesPerRow, rows * bytesPerRow);
                    offset += rows;
                }
                out.write(new byte[]{0x0A,0x0A,0x0A,0x0A});
                out.flush();
            }
            org.json.JSONObject result = new org.json.JSONObject();
            result.put("ok", true); result.put("message", "بل MPT-II پرنٹر کو بھیج دیا گیا۔");
            sendPrinterCallback(callback, result.toString());
        } catch (Exception e) {
            printerError(callback, "بل پرنٹ نہیں ہو سکا: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        }
    }

    private void disconnectThermalPrinter() {
        try { if (thermalSocket != null) thermalSocket.close(); } catch (Exception ignored) {}
        thermalSocket = null;
    }

    private boolean connectThermalPrinter(String address) throws Exception {
        if (!hasBluetoothConnectPermission()) throw new SecurityException("Bluetooth اجازت نہیں ملی۔");
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new IOException("اس موبائل میں Bluetooth دستیاب نہیں۔");
        if (!adapter.isEnabled()) throw new IOException("موبائل کا Bluetooth بند ہے۔ پہلے اسے آن کریں۔");
        BluetoothDevice device = adapter.getRemoteDevice(address);
        disconnectThermalPrinter();
        BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
        socket.connect();
        thermalSocket = socket;
        thermalPrinterAddress = address;
        getSharedPreferences("star_bags_printer", MODE_PRIVATE).edit().putString("address", address).putString("name", device.getName()).apply();
        return true;
    }

    public class StarBagsBridge {
        @JavascriptInterface public void getPairedThermalPrinters(String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) { printerError(callback, "اس موبائل میں Bluetooth دستیاب نہیں۔"); return; }
                if (!adapter.isEnabled()) { printerError(callback, "Bluetooth بند ہے۔ پہلے موبائل Settings میں آن کریں۔"); return; }
                org.json.JSONArray devices = new org.json.JSONArray();
                Set<BluetoothDevice> paired = adapter.getBondedDevices();
                for (BluetoothDevice device : paired) {
                    org.json.JSONObject item = new org.json.JSONObject();
                    item.put("name", device.getName() == null ? "Bluetooth Printer" : device.getName());
                    item.put("address", device.getAddress());
                    devices.put(item);
                }
                org.json.JSONObject result = new org.json.JSONObject();
                result.put("ok", true); result.put("devices", devices);
                result.put("savedAddress", getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", ""));
                sendPrinterCallback(callback, result.toString());
            } catch (SecurityException e) { printerError(callback, "Bluetooth اجازت درکار ہے۔"); }
            catch (Exception e) { printerError(callback, "Paired پرنٹرز کی فہرست نہیں مل سکی: " + e.getMessage()); }
        }

        @JavascriptInterface public void connectThermalPrinter(String address, String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            new Thread(() -> {
                try {
                    connectThermalPrinter(address);
                    org.json.JSONObject result = new org.json.JSONObject();
                    result.put("ok", true); result.put("message", "پرنٹر کنیکٹ ہوگیا۔");
                    result.put("address", address);
                    sendPrinterCallback(callback, result.toString());
                } catch (Exception e) { printerError(callback, "کنکشن نہیں ہو سکا: " + (e.getMessage() == null ? e.toString() : e.getMessage())); }
            }).start();
        }


        @JavascriptInterface public void printBillHtml(String billHtml, String paperWidth, String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            if (billHtml == null || billHtml.trim().isEmpty()) { printerError(callback, "بل کا Preview خالی ہے۔ پہلے بل تیار کریں۔"); return; }
            runOnUiThread(() -> renderBillForThermalPrinter(billHtml, "80".equals(paperWidth) ? 576 : 384, callback));
        }

        @JavascriptInterface public void printThermalTest(String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            new Thread(() -> {
                try {
                    if (thermalSocket == null || !thermalSocket.isConnected()) {
                        String saved = getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", "");
                        if (saved.isEmpty()) throw new IOException("پہلے MPT-II پرنٹر کنیکٹ کریں۔");
                        connectThermalPrinter(saved);
                    }
                    OutputStream out = thermalSocket.getOutputStream();
                    out.write(new byte[]{0x1B, 0x40}); // ESC @ initialize
                    out.write(new byte[]{0x1B, 0x61, 0x01}); // center
                    out.write("STAR BAGS\n".getBytes("US-ASCII"));
                    out.write("It is work\n".getBytes("US-ASCII"));
                    out.write("MPT-II Bluetooth Test\n".getBytes("US-ASCII"));
                    out.write(new byte[]{0x1B, 0x61, 0x00});
                    out.write("Bluetooth SPP / ESC-POS\n".getBytes("US-ASCII"));
                    out.write(new byte[]{0x0A,0x0A,0x0A,0x0A});
                    out.flush();
                    org.json.JSONObject result = new org.json.JSONObject();
                    result.put("ok", true); result.put("message", "ٹیسٹ رسید پرنٹ بھیج دی گئی۔");
                    sendPrinterCallback(callback, result.toString());
                } catch (Exception e) { printerError(callback, "پرنٹ نہیں ہو سکی: " + (e.getMessage() == null ? e.toString() : e.getMessage())); }
            }).start();
        }

        @JavascriptInterface public void openContactPicker() {
            runOnUiThread(() -> {
                try {
                    Intent pick = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    startActivityForResult(pick, PICK_CONTACT);
                } catch (Exception e) {
                    if (webView != null) webView.evaluateJavascript("window.onStarBagsContactError && window.onStarBagsContactError()", null);
                    Toast.makeText(MainActivity.this, "فون کے Contacts دستیاب نہیں۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void setPullToRefreshEnabled(boolean enabled) {
            runOnUiThread(() -> { if (swipeRefresh != null) swipeRefresh.setEnabled(enabled); });
        }

        @JavascriptInterface public void scheduleSeasonReminder(String title, String body) {
            runOnUiThread(() -> {
                try {
                    getSharedPreferences("star_bags_reminders", MODE_PRIVATE).edit()
                            .putString("title", title == null ? "STAR BAGS سیزن پلانر" : title)
                            .putString("body", body == null ? "اگلے سیزن کی تیاری کا منصوبہ دیکھیں۔" : body)
                            .putBoolean("enabled", true).apply();
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1201);
                    }
                    Calendar first = Calendar.getInstance();
                    first.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                    first.set(Calendar.HOUR_OF_DAY, 9); first.set(Calendar.MINUTE, 0); first.set(Calendar.SECOND, 0); first.set(Calendar.MILLISECOND, 0);
                    if (first.getTimeInMillis() <= System.currentTimeMillis()) first.add(Calendar.DAY_OF_YEAR, 7);
                    Intent intent = new Intent(MainActivity.this, SeasonReminderReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 1202, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
                    if (alarm != null) alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, first.getTimeInMillis(), AlarmManager.INTERVAL_DAY * 7, pi);
                    Toast.makeText(MainActivity.this, "ہر پیر صبح 9 بجے سیزن پلانر ریمائنڈر سیٹ ہوگیا۔", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ریمائنڈر سیٹ نہیں ہو سکا۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void cancelSeasonReminder() {
            try {
                Intent intent = new Intent(MainActivity.this, SeasonReminderReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 1202, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
                if (alarm != null) alarm.cancel(pi);
                pi.cancel();
                getSharedPreferences("star_bags_reminders", MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
                Toast.makeText(MainActivity.this, "سیزن پلانر ریمائنڈر بند ہوگیا۔", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(MainActivity.this, "ریمائنڈر بند نہیں ہو سکا۔", Toast.LENGTH_SHORT).show(); }
        }

        @JavascriptInterface public void saveBackup(String base64, String filename, String mimeType) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> saveBackupBytes(bytes, filename, mimeType));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بیک اپ فائل تیار نہیں ہو سکی۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBillImage(String base64, String phone, String message) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared_bills");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cache directory unavailable");
                File file = new File(dir, "STAR-BAGS-Bill.png");
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message == null ? "STAR BAGS Bill" : message);
                if (!number.isEmpty()) send.putExtra("jid", number + "@s.whatsapp.net");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newUri(getContentResolver(), "STAR BAGS Bill", uri));
                runOnUiThread(() -> {
                    try {
                        Intent business = new Intent(send);
                        business.setPackage("com.whatsapp.w4b");
                        startActivity(business);
                    } catch (Exception noBusiness) {
                        try {
                            Intent normal = new Intent(send);
                            normal.setPackage("com.whatsapp");
                            startActivity(normal);
                        } catch (Exception noWhatsApp) {
                            try { startActivity(Intent.createChooser(send, "STAR BAGS — بل شیئر کریں")); }
                            catch (Exception e) { Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔", Toast.LENGTH_LONG).show(); }
                        }
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔ دوبارہ کوشش کریں۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareCatalog(String payloadJson) {
            runOnUiThread(() -> {
                try {
                    org.json.JSONObject payload = new org.json.JSONObject(payloadJson == null ? "{}" : payloadJson);
                    String message = payload.optString("text", "STAR BAGS Product Catalog");
                    org.json.JSONArray files = payload.optJSONArray("files");
                    java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                    File dir = new File(getCacheDir(), "catalog_share");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cache directory unavailable");
                    if (files != null) {
                        for (int i = 0; i < files.length(); i++) {
                            org.json.JSONObject item = files.optJSONObject(i);
                            if (item == null) continue;
                            String base64 = item.optString("base64", "");
                            if (base64.isEmpty()) continue;
                            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                            String filename = item.optString("name", "STAR-BAGS-Product-" + (i + 1) + ".jpg").replaceAll("[^A-Za-z0-9._-]", "_");
                            File file = new File(dir, filename);
                            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                            uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file));
                        }
                    }
                    Intent send;
                    if (uris.size() > 1) {
                        send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        send.setType("image/*");
                        send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    } else if (uris.size() == 1) {
                        send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/*");
                        send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                    } else {
                        send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                    }
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (!uris.isEmpty()) {
                        ClipData clip = ClipData.newUri(getContentResolver(), "STAR BAGS Catalog", uris.get(0));
                        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                        send.setClipData(clip);
                    }
                    try {
                        Intent business = new Intent(send); business.setPackage("com.whatsapp.w4b"); startActivity(business);
                    } catch (Exception noBusiness) {
                        try { Intent normal = new Intent(send); normal.setPackage("com.whatsapp"); startActivity(normal); }
                        catch (Exception noWhatsApp) { startActivity(Intent.createChooser(send, "STAR BAGS Catalog شیئر کریں")); }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "کیٹلاگ شیئر نہیں ہو سکا۔ کم آئٹمز منتخب کرکے دوبارہ کوشش کریں۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void openSms(String phone, String message) {
            try {
                Uri uri = Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone));
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", message == null ? "" : message);
                startActivity(intent);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "SMS ایپ دستیاب نہیں۔", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    results = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) {
                        results[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
            return;
        }
        if (requestCode == PICK_CONTACT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                String name = "", phone = "";
                Cursor cursor = null;
                try {
                    String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
                    cursor = getContentResolver().query(data.getData(), projection, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        if (nameIndex >= 0) name = cursor.getString(nameIndex);
                        if (phoneIndex >= 0) phone = cursor.getString(phoneIndex);
                    }
                } catch (Exception ignored) {
                } finally { if (cursor != null) cursor.close(); }
                if (webView != null && !phone.trim().isEmpty()) {
                    final String js = "window.onStarBagsContactSelected && window.onStarBagsContactSelected(" + org.json.JSONObject.quote(name == null ? "" : name) + "," + org.json.JSONObject.quote(phone) + ");";
                    webView.evaluateJavascript(js, null);
                } else if (webView != null) {
                    webView.evaluateJavascript("window.onStarBagsContactError && window.onStarBagsContactError()", null);
                    Toast.makeText(this, "منتخب رابطے میں فون نمبر موجود نہیں۔", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == CREATE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Unable to open destination");
                    out.write(pendingBackupBytes);
                    Toast.makeText(this, "بیک اپ فائل محفوظ ہوگئی۔", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "بیک اپ فائل محفوظ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupBytes = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
                "(function(){try{return window.starBagsHandleBack?window.starBagsHandleBack():false;}catch(e){return false;}})();",
                value -> {
                    if (value == null || "false".equals(value) || "null".equals(value)) finish();
                });
    }

    @Override protected void onDestroy() {
        disconnectThermalPrinter();
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
