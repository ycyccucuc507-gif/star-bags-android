package com.starbags.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.AdapterView;
import android.widget.Button;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.Calendar;

public class MainActivity extends Activity {
    private interface PrintScaleCallback { void onSelected(float scale, String fontFamily, boolean bold); }
    private static final String[] PRINT_SCALE_OPTIONS = {
            "0.5X", "0.75X", "1X", "1.1X", "1.2X", "1.3X", "1.5X",
            "1.8X", "2X", "2.5X", "3X", "Custom"
    };
    private static final String[] PRINT_FONT_LABELS = {
            "Noto Naskh Arabic (خوبصورت اردو)", "Noto Sans Arabic (واضح موٹا)",
            "Serif (روایتی)", "Sans-serif (سادہ)", "Monospace (مشینی)"
    };
    private static final String[] PRINT_FONT_CSS = {
            "'Noto Naskh Arabic UI','Noto Naskh Arabic',serif",
            "'Noto Sans Arabic','Arial',sans-serif", "serif", "sans-serif", "monospace"
    };

    private float parsePrintScale(String selected, String customValue) throws Exception {
        float scale;
        if ("Custom".equals(selected)) {
            try { scale = Float.parseFloat(customValue.trim()); }
            catch (Exception e) { throw new Exception("Custom Scale درست درج کریں، مثال: 0.8 یا 3.5"); }
        } else {
            scale = Float.parseFloat(selected.replace("X", ""));
        }
        if (Float.isNaN(scale) || Float.isInfinite(scale) || scale < 0.1f || scale > 5.0f)
            throw new Exception("Custom Scale کی حد 0.1X سے 5X تک ہے۔");
        return scale;
    }

    private void showPrintScaleDialog(String title, PrintScaleCallback callback) {
        android.content.SharedPreferences prefs = getSharedPreferences("star_bags_print_preferences", MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 12, 20, 4);
        TextView label = new TextView(this);
        label.setText("Vertical Scale سے بل کی لمبائی اور عمودی فاصلہ بدلے گا؛ کاغذ کی چوڑائی 58mm ہی رہے گی۔ فونٹ الگ سے منتخب کریں۔ پہلے مکمل اصل پرنٹ Preview دکھایا جائے گا۔");
        box.addView(label);
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, PRINT_SCALE_OPTIONS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        float savedScale = prefs.getFloat("scale", 1.0f);
        int savedPosition = 2;
        for (int i=0;i<PRINT_SCALE_OPTIONS.length-1;i++) if (Math.abs(Float.parseFloat(PRINT_SCALE_OPTIONS[i].replace("X",""))-savedScale)<0.001f) savedPosition=i;
        if (savedScale != 1.0f && savedPosition==2) savedPosition=PRINT_SCALE_OPTIONS.length-1;
        spinner.setSelection(savedPosition);
        box.addView(spinner);
        EditText custom = new EditText(this);
        custom.setSingleLine(true);
        custom.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        custom.setHint("Custom Scale (0.1 سے 5X)");
        custom.setText(String.valueOf(savedScale));
        custom.setVisibility(savedPosition == PRINT_SCALE_OPTIONS.length-1 ? View.VISIBLE : View.GONE);
        box.addView(custom);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                custom.setVisibility(position == PRINT_SCALE_OPTIONS.length - 1 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        TextView fontLabel = new TextView(this);
        fontLabel.setText("اردو / رسید کا فونٹ");
        fontLabel.setPadding(0, 12, 0, 0);
        box.addView(fontLabel);
        Spinner fontSpinner = new Spinner(this);
        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, PRINT_FONT_LABELS);
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fontSpinner.setAdapter(fontAdapter);
        fontSpinner.setSelection(Math.max(0, Math.min(PRINT_FONT_CSS.length-1, prefs.getInt("font", 0))));
        box.addView(fontSpinner);
        android.widget.CheckBox boldText = new android.widget.CheckBox(this);
        boldText.setText("Bold / موٹے اور گہرے الفاظ");
        boldText.setChecked(prefs.getBoolean("bold", true));
        box.addView(boldText);
        android.widget.CheckBox applyAll = new android.widget.CheckBox(this);
        applyAll.setText("Apply to All — یہ سیٹنگ آئندہ بل اور تصاویر کے لیے محفوظ کریں");
        applyAll.setChecked(true);
        box.addView(applyAll);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(box)
                .setNegativeButton("منسوخ", (d, w) -> {}).setPositiveButton("Preview / Apply", null).create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                float scale = parsePrintScale(String.valueOf(spinner.getSelectedItem()), custom.getText().toString());
                int fontIndex = fontSpinner.getSelectedItemPosition();
                boolean bold = boldText.isChecked();
                if (applyAll.isChecked()) prefs.edit().putFloat("scale", scale).putInt("font", fontIndex).putBoolean("bold", bold).apply();
                dialog.dismiss();
                callback.onSelected(scale, PRINT_FONT_CSS[fontIndex], bold);
            } catch (Exception e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }
        });
    }

    // Text receipts need solid strokes, not Floyd-Steinberg grain. Convert the same
    // high-resolution antialiased preview to clean black/white pixels with one threshold.
    private void applyThermalDitherInPlace(android.graphics.Bitmap bitmap) {
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                int pixel = row[x];
                int gray = (android.graphics.Color.red(pixel) * 299 + android.graphics.Color.green(pixel) * 587 + android.graphics.Color.blue(pixel) * 114) / 1000;
                int value = gray < 185 ? 0 : 255;
                row[x] = android.graphics.Color.rgb(value, value, value);
            }
            bitmap.setPixels(row, 0, w, 0, y, w, 1);
        }
    }

    private void showBitmapPrintPreview(android.graphics.Bitmap bitmap, String callback, int paperDots, String title) {
        new Thread(() -> {
            try { applyThermalDitherInPlace(bitmap); }
            catch (Exception e) { if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle(); runOnUiThread(() -> printerError(callback, "پرنٹ Preview تیار نہیں ہو سکا: " + e.getMessage())); return; }
            runOnUiThread(() -> {
            if (bitmap == null || bitmap.isRecycled()) { printerError(callback, "پرنٹ Preview تیار نہیں ہوا۔"); return; }
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            TextView info = new TextView(this);
            info.setPadding(12, 8, 12, 8);
            info.setText("اصل پرنٹ ڈیٹا: " + bitmap.getWidth() + " × " + bitmap.getHeight() + " dots\nیہی تصویر Preview کے بعد پرنٹر کو بھیجی جائے گی۔");
            content.addView(info);
            ImageView image = new ImageView(this);
            image.setBackgroundColor(Color.WHITE);
            image.setScaleType(ImageView.ScaleType.FIT_XY);
            image.setImageBitmap(bitmap);
            int screenWidth = Math.max(220, getResources().getDisplayMetrics().widthPixels - (int)(48 * getResources().getDisplayMetrics().density));
            final int[] previewWidth = new int[]{screenWidth};
            ScrollView scroll = new ScrollView(this);
            android.widget.HorizontalScrollView horizontal = new android.widget.HorizontalScrollView(this);
            horizontal.setFillViewport(true);
            horizontal.addView(scroll, new android.widget.HorizontalScrollView.LayoutParams(previewWidth[0], -2));
            int imageHeight = Math.max(1, Math.round(previewWidth[0] * (bitmap.getHeight() / (float) bitmap.getWidth())));
            scroll.addView(image, new ScrollView.LayoutParams(previewWidth[0], imageHeight));
            LinearLayout zoomRow = new LinearLayout(this);
            zoomRow.setOrientation(LinearLayout.HORIZONTAL);
            Button fitButton = new Button(this); fitButton.setText("Fit to Screen");
            Button zoomOut = new Button(this); zoomOut.setText("−");
            Button zoomIn = new Button(this); zoomIn.setText("+");
            zoomRow.addView(fitButton, new LinearLayout.LayoutParams(0, -2, 2));
            zoomRow.addView(zoomOut, new LinearLayout.LayoutParams(0, -2, 1));
            zoomRow.addView(zoomIn, new LinearLayout.LayoutParams(0, -2, 1));
            Runnable updatePreviewSize = () -> {
                int h = Math.max(1, Math.round(previewWidth[0] * (bitmap.getHeight() / (float) bitmap.getWidth())));
                image.setLayoutParams(new ScrollView.LayoutParams(previewWidth[0], h));
                scroll.setLayoutParams(new android.widget.HorizontalScrollView.LayoutParams(previewWidth[0], -2));
                image.requestLayout();
            };
            fitButton.setOnClickListener(v -> { previewWidth[0] = screenWidth; updatePreviewSize.run(); });
            zoomOut.setOnClickListener(v -> { previewWidth[0] = Math.max(160, Math.round(previewWidth[0] * 0.8f)); updatePreviewSize.run(); });
            zoomIn.setOnClickListener(v -> { previewWidth[0] = Math.min(screenWidth * 3, Math.round(previewWidth[0] * 1.2f)); updatePreviewSize.run(); });
            content.addView(zoomRow);
            content.addView(horizontal, new LinearLayout.LayoutParams(-1, (int)(430 * getResources().getDisplayMetrics().density)));
            AlertDialog preview = new AlertDialog.Builder(this).setTitle(title).setView(content)
                    .setNegativeButton("واپس / منسوخ", (d,w) -> { if (!bitmap.isRecycled()) bitmap.recycle(); })
                    .setPositiveButton("اسی Preview کو پرنٹ کریں", null).create();
            preview.setOnCancelListener(d -> { if (!bitmap.isRecycled()) bitmap.recycle(); });
            preview.show();
            preview.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                preview.dismiss();
                new Thread(() -> sendReceiptBitmapToPrinter(bitmap, callback, paperDots)).start();
            });
            });
        }).start();
    }
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_BACKUP = 1002;
    private static final int PICK_CONTACT = 1003;
    private static final int PICK_PRINT_IMAGE = 1004;
    private String pendingImagePrintCallback = "";
    private int pendingImagePaperDots = 384;
    private static final int BT_PERMISSION_REQUEST = 1202;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static volatile BluetoothSocket thermalSocket;
    private String thermalPrinterAddress = "";
    private volatile long lastPrinterKeepAliveRefreshMs = 0L;
    private static final int BRAND = Color.rgb(24, 59, 99);

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private FrameLayout root;
    private View splashView;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingBackupBytes;
    private String pendingBackupName = "star-bags-backup.json";
    private String pendingBackupMime = "application/json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(BRAND);
        getWindow().setNavigationBarColor(BRAND);
        getWindow().getDecorView().setSystemUiVisibility(0);

        root = new FrameLayout(this);
        root.setBackgroundColor(BRAND);
        root.setClipToPadding(false);

        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setColorSchemeColors(BRAND, Color.rgb(49, 91, 135));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN
                    && thermalSocket != null && thermalSocket.isConnected()) {
                refreshPrinterKeepAlive();
            }
            return false;
        });
        swipeRefresh.addView(webView, new SwipeRefreshLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(swipeRefresh, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);

        showSplash();
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setBuiltInZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new StarBagsBridge(), "StarBagsAndroid");
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(view, url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(view, request.getUrl().toString());
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideSplash();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent chooserIntent = params.createIntent();
                    // WebView's default chooser does not consistently request multi-select.
                    // Explicitly enable it for <input type="file" multiple>.
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        chooserIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(chooserIntent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    if (fileCallback != null) fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "فائل منتخب کرنے کی سہولت نہیں کھل سکی۔", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.startsWith("blob:")) return; // Blob backups use the native bridge below.
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                if (mimeType != null) request.setMimeType(mimeType);
                if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(filename);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
            } catch (Exception e) {
                Toast.makeText(this, "فائل ڈاؤن لوڈ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
            }
        });

        swipeRefresh.setOnChildScrollUpCallback((parent, child) -> webView != null && webView.canScrollVertically(-1));
        swipeRefresh.setOnRefreshListener(() -> {
            if (webView == null) {
                swipeRefresh.setRefreshing(false);
                return;
            }
            webView.evaluateJavascript(
                    "(function(){if(window.starBagsGoHomeFromRefresh){window.starBagsGoHomeFromRefresh();}else if(window.showModule){window.showModule('home');window.scrollTo(0,0);}})();",
                    value -> { if (swipeRefresh != null) swipeRefresh.setRefreshing(false); });
        });

        if (state == null) webView.loadUrl("file:///android_asset/index.html");
        else {
            webView.restoreState(state);
            if (webView.getUrl() == null) webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BRAND);
        splash.setPadding(28, 32, 28, 32);

        ImageView logo = new ImageView(this);
        try { logo.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("star_bags_logo.jpg"), null)); }
        catch (Exception ignored) {}
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(220), dp(160));
        logoParams.bottomMargin = dp(18);
        splash.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("STAR BAGS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));

        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        progressParams.topMargin = dp(22);
        splash.addView(progress, progressParams);

        splashView = splash;
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideSplash() {
        if (splashView != null && root != null) {
            root.removeView(splashView);
            splashView = null;
        }
    }

    private boolean routeUrl(WebView view, String rawUrl) {
        if (rawUrl == null) return false;
        try {
            if (rawUrl.startsWith("intent://")) {
                Uri intentUri = Uri.parse(rawUrl);
                launchWhatsApp(intentUri.getQueryParameter("phone"), intentUri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("intent:")) {
                try { startActivity(Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME)); }
                catch (Exception ignored) { Toast.makeText(this, "یہ Android آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
                return true;
            }
            Uri uri = Uri.parse(rawUrl);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (host.equals("wa.me") || host.endsWith(".wa.me") || host.equals("api.whatsapp.com")) {
                String phone = uri.getQueryParameter("phone");
                if (phone == null || phone.isEmpty()) {
                    java.util.List<String> segments = uri.getPathSegments();
                    if (!segments.isEmpty()) phone = segments.get(0);
                }
                launchWhatsApp(phone, uri.getQueryParameter("text"));
                return true;
            }
            if (rawUrl.startsWith("https://") || rawUrl.startsWith("http://") || rawUrl.startsWith("tel:") || rawUrl.startsWith("mailto:")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (Exception e) { return rawUrl.startsWith("http"); }
            }
        } catch (Exception ignored) {
            return true;
        }
        return false;
    }

    private void launchWhatsApp(String phone, String message) {
        String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        Uri chat = Uri.parse("https://wa.me/" + number + (message == null || message.isEmpty() ? "" : "?text=" + Uri.encode(message)));
        Intent business = new Intent(Intent.ACTION_VIEW, chat);
        business.setPackage("com.whatsapp.w4b");
        try { startActivity(business); return; } catch (Exception ignored) {}
        Intent normal = new Intent(Intent.ACTION_VIEW, chat);
        normal.setPackage("com.whatsapp");
        try { startActivity(normal); return; } catch (Exception ignored) {}
        try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, chat), "WhatsApp کھولیں")); }
        catch (Exception e) { Toast.makeText(this, "WhatsApp دستیاب نہیں۔", Toast.LENGTH_LONG).show(); }
    }

    private void saveBackupBytes(byte[] bytes, String filename, String mimeType) {
        pendingBackupBytes = bytes;
        pendingBackupName = filename == null || filename.trim().isEmpty() ? "star-bags-backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
        pendingBackupMime = mimeType == null || mimeType.isEmpty() ? "application/json" : mimeType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingBackupName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, pendingBackupMime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/STAR BAGS");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Downloads provider unavailable");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Unable to open output");
                    out.write(bytes);
                    out.flush();
                } catch (Exception writeError) {
                    getContentResolver().delete(uri, null, null);
                    throw writeError;
                }
                ContentValues complete = new ContentValues();
                complete.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, complete, null, null);
                pendingBackupBytes = null;
                Toast.makeText(this, "بیک اپ Downloads/STAR BAGS میں محفوظ ہوگیا۔", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception e) {
                // Use the Android document picker if Downloads storage is unavailable.
            }
        }
        try {
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType(pendingBackupMime);
            create.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
            startActivityForResult(create, CREATE_BACKUP);
        } catch (Exception e) {
            Toast.makeText(this, "بیک اپ محفوظ کرنے کا آپشن دستیاب نہیں۔", Toast.LENGTH_LONG).show();
            pendingBackupBytes = null;
        }
    }


    private boolean hasBluetoothConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void sendPrinterCallback(String callback, String json) {
        if (webView == null || callback == null || !callback.matches("[A-Za-z_$][A-Za-z0-9_$]*")) return;
        final String script = "window." + callback + " && window." + callback + "(" + json + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void printerError(String callback, String message) {
        try {
            org.json.JSONObject result = new org.json.JSONObject();
            result.put("ok", false); result.put("message", message);
            sendPrinterCallback(callback, result.toString());
        } catch (Exception ignored) {}
    }

    private void ensureBluetoothPermission(String callback) {
        if (Build.VERSION.SDK_INT >= 31 && !hasBluetoothConnectPermission()) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, BT_PERMISSION_REQUEST));
            printerError(callback, "Bluetooth اجازت درکار ہے۔ اجازت دینے کے بعد دوبارہ بٹن دبائیں۔");
        }
    }



    private void renderBillForThermalPrinter(String billHtml, int paperDots, String callback, float printScale, String fontFamily, boolean boldText) {
        final WebView receiptView = new WebView(this);
        final int targetWidth = paperDots;
        final float density = getResources().getDisplayMetrics().density;
        // WebView layout dimensions are Android physical pixels, while CSS dimensions are dp-like CSS px.
        // Render at density-scaled size, then downsample to the printer's exact dot width.
        final int renderWidth = Math.max(targetWidth, Math.round(targetWidth * density));
        receiptView.setBackgroundColor(Color.WHITE);
        receiptView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        receiptView.getSettings().setJavaScriptEnabled(true);
        receiptView.getSettings().setDomStorageEnabled(false);
        receiptView.getSettings().setLoadWithOverviewMode(false);
        receiptView.getSettings().setUseWideViewPort(false);

        // Apply print-only styling while preserving the on-screen preview, column widths and bill structure.
        // Do not force four columns: the Pertah receipt is a three-column table.
        // The selected scale is applied once to computed text/vertical styles; paper width stays fixed.
        String receiptCss =
                "html,body{margin:0!important;padding:0!important;width:" + targetWidth + "px!important;min-width:" + targetWidth + "px!important;max-width:" + targetWidth + "px!important;height:auto!important;min-height:0!important;max-height:none!important;background:#fff!important;color:#000!important;font-family:" + fontFamily + "!important;font-size:17px!important;line-height:1.55!important;overflow:visible!important}" +
                "body{padding:0!important;direction:rtl!important;box-sizing:border-box!important;font-weight:700!important}" +
                "#printableBill,#pertahPrintable{display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0!important;padding:0!important;box-sizing:border-box!important;background:#fff!important;color:#000!important;overflow:visible!important;font-size:21px!important;line-height:1.5!important;font-weight:800!important}" +
                "#printableBill *:not(img),#pertahPrintable *:not(img){max-height:none!important;overflow:visible!important}" +
                "#printableBill table,#pertahPrintable table,table{width:100%!important;max-width:100%!important;min-width:0!important;table-layout:fixed!important;border-collapse:collapse!important;direction:rtl!important;margin:8px 0!important;box-sizing:border-box!important;font-size:22px!important;line-height:1.45!important}" +
                "thead{display:table-header-group!important}tbody{display:table-row-group!important}tr{display:table-row!important;break-inside:avoid!important;page-break-inside:avoid!important}" +
                "th,td{display:table-cell!important;vertical-align:middle!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;color:#000!important;box-sizing:border-box!important;padding:9px 2px!important;font-size:22px!important;line-height:1.45!important;font-weight:900!important;border-bottom:1px solid #777!important;border-left:0!important;border-right:0!important;border-top:0!important}" +
                "p{white-space:normal!important;overflow-wrap:anywhere!important;color:#000!important;font-size:21px!important;line-height:1.5!important;margin:9px 0!important;font-weight:800!important}" +
                ".bill-banner{max-width:100%!important;box-sizing:border-box!important;flex-wrap:wrap!important;gap:6px!important;padding:6px 6px!important;margin-bottom:7.5px!important}" +
                ".bill-logo{width:68px!important;height:44px!important;max-width:68px!important;max-height:44px!important;object-fit:contain!important;padding:0!important;margin:0!important}" +
                ".bill-brand-name{font-size:26px!important;line-height:1.25!important;font-weight:900!important}" +
                ".bill-banner .bill-contact{font-size:18px!important;line-height:1.35!important;white-space:normal!important}" +
                ".billhead strong{font-size:34px!important;line-height:1.25!important;font-weight:900!important}" +
                ".billmeta{font-size:20px!important;line-height:1.5!important}" +
                ".notice{font-size:20px!important;line-height:1.55!important;padding:12px 6px!important}" +
                ".moneyline,.moneybox{font-size:22px!important;line-height:1.45!important;padding:7px 2px!important}" +
                ".moneyline strong{font-size:22px!important;line-height:1.45!important;font-weight:900!important}" +
                ".pertah-bill{font-size:23px!important;line-height:1.55!important;padding:13.5px 6px!important;border-radius:0!important}" +
                ".pertah-bill h3{font-size:26px!important;line-height:1.4!important;margin:6px 0!important;font-weight:900!important}" +
                ".pertah-bill th,.pertah-bill td{font-size:22px!important;padding:9px 2.25px!important;line-height:1.5!important;font-weight:700!important}" +
                ".pertah-bill .p-grand{font-size:29px!important;padding:13.5px 3px!important;line-height:1.5!important;font-weight:900!important}" +
                ".bill-banner *{color:#000!important}" +
                "img{max-width:100%!important;height:auto!important}" +
                "button,.noprint,.hidden,.buttons{display:none!important}" +
                "*{box-shadow:none!important;text-shadow:none!important;-webkit-font-smoothing:antialiased!important;text-rendering:geometricPrecision!important}" + (boldText ? "body,body *{font-weight:800!important;-webkit-text-stroke:.18px #000!important}" : "");
        String scaleScript = "<script>(function(){var s=" + printScale + ";" +
                // Preserve every original sales-bill column: item, quantity, per-piece rate and total.
                // The Pertah bill alone has the requested three columns: item, quantity and total.
                "var st=document.querySelector('#printableBill table');if(st){st.style.direction='rtl';st.style.tableLayout='fixed';var sr=st.querySelectorAll('tr');sr.forEach(function(r){var c=r.children;if(c.length===4){c[0].style.width='42%';c[0].style.textAlign='right';c[1].style.width='15%';c[1].style.textAlign='center';c[2].style.width='20%';c[2].style.textAlign='center';c[3].style.width='23%';c[3].style.textAlign='center';}});}" +
                "var pt=document.querySelector('#pertahPrintable table');if(pt){pt.style.width='100%';pt.style.tableLayout='fixed';pt.style.direction='rtl';var prs=pt.querySelectorAll('tr');prs.forEach(function(r){var c=r.children;if(c.length>=3){c[0].style.width='48%';c[0].style.textAlign='right';c[1].style.width='22%';c[1].style.textAlign='center';c[2].style.width='30%';c[2].style.textAlign='center';}});}" +
                "var a=Array.prototype.slice.call(document.querySelectorAll('#printableBill *,#pertahPrintable *,body'));a.forEach(function(e){var c=getComputedStyle(e);var fs=parseFloat(c.fontSize)||19,l=c.lineHeight==='normal'?0:(parseFloat(c.lineHeight)||0),mt=parseFloat(c.marginTop)||0,mb=parseFloat(c.marginBottom)||0,pt=parseFloat(c.paddingTop)||0,pb=parseFloat(c.paddingBottom)||0,pl=parseFloat(c.paddingLeft)||0,pr=parseFloat(c.paddingRight)||0;if(fs>0)e.style.setProperty('font-size',(fs*s)+'px','important');if(l>0)e.style.setProperty('line-height',(l*s)+'px','important');if(mt>0)e.style.setProperty('margin-top',(mt*s)+'px','important');if(mb>0)e.style.setProperty('margin-bottom',(mb*s)+'px','important');if(pt>0)e.style.setProperty('padding-top',(pt*s)+'px','important');if(pb>0)e.style.setProperty('padding-bottom',(pb*s)+'px','important');if(pl>0)e.style.setProperty('padding-left',(pl*s)+'px','important');if(pr>0)e.style.setProperty('padding-right',(pr*s)+'px','important');if(e.classList&&e.classList.contains('bill-logo')){e.style.setProperty('width','68px','important');e.style.setProperty('height','44px','important');e.style.setProperty('max-width','68px','important');}});" +
                "document.querySelectorAll('#printableBill,#pertahPrintable,body,html').forEach(function(e){e.style.setProperty('height','auto','important');e.style.setProperty('min-height','0','important');e.style.setProperty('max-height','none','important');e.style.setProperty('overflow','visible','important');});window.__starBagsScaleApplied=true;})();</script>";
        String document = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=" + targetWidth + ", initial-scale=1, maximum-scale=1'><style>" +
                receiptCss + "</style></head><body>" + billHtml + scaleScript + "</body></html>";

        receiptView.setWebViewClient(new WebViewClient() {
            private boolean captured = false;
            @Override public void onPageFinished(WebView view, String url) {
                if (captured) return;
                captured = true;
                // Wait for the inline logo/images and layout to settle. evaluateJavascript
                // must return a plain number here; Android does not await JavaScript Promises.
                view.postDelayed(() -> view.evaluateJavascript(
                        "(function(){var b=document.body,d=document.documentElement;var h=Math.max((b&&b.scrollHeight)||0,(d&&d.scrollHeight)||0,(b&&b.offsetHeight)||0,(d&&d.offsetHeight)||0,(b&&b.getBoundingClientRect().height)||0,(d&&d.getBoundingClientRect().height)||0);var nodes=document.querySelectorAll('body *');for(var i=0;i<nodes.length;i++){var r=nodes[i].getBoundingClientRect();if(r.width>0&&r.height>0)h=Math.max(h,Math.ceil(r.bottom+(window.pageYOffset||0)));}return Math.ceil(h+8);})()",
                        value -> {
                            try {
                                int cssHeight = 0;
                                try { cssHeight = Integer.parseInt(value == null ? "0" : value.replace("\"", "").trim()); } catch (Exception ignored) {}
                                if (cssHeight < 100) throw new IllegalStateException("بل کی تصویر کی اونچائی درست نہیں بنی۔");
                                // Height follows the measured rendered bill; a memory safety ceiling remains.
                                // Raster data is transmitted as independent 24-dot ESC * stripes below.
                                long receiptPixels = (long) targetWidth * (long) cssHeight;
                                // The MPT-II manual warns against one continuous print longer than 1 metre.
                                // Keep a 900 mm safety ceiling (8 dots/mm) for its 384-dot paper mode.
                                if (targetWidth == 384 && cssHeight > 7200) throw new IllegalStateException("MPT-II کی حفاظت کے لیے ایک مسلسل بل کی حد تقریباً 90 سینٹی میٹر رکھی گئی ہے۔ اسے دو بلوں میں تقسیم کریں۔");
                                if (cssHeight <= 0 || receiptPixels > 12_000_000L) throw new IllegalStateException("بل بہت زیادہ لمبا ہے؛ موبائل کی میموری محفوظ رکھنے کے لیے اسے کم حصوں میں پرنٹ کریں۔");
                                float renderScale = renderWidth / (float) targetWidth;
                                int renderHeight = Math.max(1, (int)Math.ceil(cssHeight * renderScale));
                                view.measure(View.MeasureSpec.makeMeasureSpec(renderWidth, View.MeasureSpec.EXACTLY),
                                        View.MeasureSpec.makeMeasureSpec(renderHeight, View.MeasureSpec.EXACTLY));
                                view.layout(0, 0, renderWidth, renderHeight);
                                view.scrollTo(0, 0);
                                // Keep only the final printer-width bitmap in memory. Drawing the
                                // full density-sized intermediate bitmap could require >100 MB
                                // for a long receipt and trigger truncation/OOM on common phones.
                                android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(
                                        targetWidth, cssHeight, android.graphics.Bitmap.Config.ARGB_8888);
                                android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
                                canvas.drawColor(Color.WHITE);
                                canvas.scale(1f / renderScale, 1f / renderScale);
                                view.draw(canvas);
                                if (root != null) root.removeView(view);
                                view.destroy();
                                if (bitmap.getWidth() != targetWidth || bitmap.getHeight() < 100) throw new IllegalStateException("بل کی مکمل تصویر تیار نہیں ہوئی۔");
                                android.util.Log.i("STAR_BAGS_PRINT", "Receipt bitmap ready: widthDots=" + bitmap.getWidth() + ", heightRows=" + bitmap.getHeight() + ", pixels=" + receiptPixels + ", scale=" + printScale + "X, config=ARGB_8888, verticalScaleApplied=true");
                                showBitmapPrintPreview(bitmap, callback, paperDots, "بل / پڑتا — اصل پرنٹ Preview");
                            } catch (OutOfMemoryError e) {
                                try { if (root != null) root.removeView(view); view.destroy(); } catch (Exception ignored) {}
                                printerError(callback, "موبائل کی دستیاب میموری اس بل کو تیار کرنے کے لیے کافی نہیں۔ غیر ضروری ایپس بند کرکے دوبارہ کوشش کریں۔");
                            } catch (Exception e) {
                                try { if (root != null) root.removeView(view); view.destroy(); } catch (Exception ignored) {}
                                printerError(callback, "بل کی مکمل تصویر تیار نہیں ہو سکی: " + e.getMessage());
                            }
                        }), 2200);
            }
        });
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(renderWidth, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        root.addView(receiptView, params);
        receiptView.setTranslationX(-renderWidth - 40);
        receiptView.loadDataWithBaseURL("file:///android_asset/", document, "text/html", "UTF-8", null);
    }

    private void ensureThermalPrinterConnected() throws Exception {
        if (!hasBluetoothConnectPermission()) throw new SecurityException("Bluetooth اجازت درکار ہے۔");
        if (thermalSocket != null && thermalSocket.isConnected()) return;
        String saved = getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", "");
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) throw new IOException("موبائل Bluetooth آن کریں۔");
        if (saved.isEmpty()) {
            for (BluetoothDevice device : adapter.getBondedDevices()) {
                String name = device.getName();
                if (name != null && name.toUpperCase().contains("MPT-II")) { saved = device.getAddress(); break; }
            }
        }
        if (saved.isEmpty()) throw new IOException("MPT-II Pair نہیں ہے۔ پہلے موبائل Bluetooth Settings میں MPT-II Pair کریں، پھر پرنٹ کریں۔");
        connectThermalPrinter(saved);
    }

    private void sendReceiptBitmapToPrinter(android.graphics.Bitmap bitmap, String callback, int paperDots) {
        try {
            ensureThermalPrinterConnected();
            refreshPrinterKeepAlive();
            int w = bitmap.getWidth(), h = bitmap.getHeight();
            if (w < 1 || h < 1 || w > 576 || (w % 8) != 0) {
                throw new IOException("رسید کی چوڑائی ESC/POS کے لیے درست نہیں۔ چوڑائی " + w + " dots ہے۔");
            }
            if (w == 384 && h > 7200) {
                throw new IOException("MPT-II کی حفاظت کے لیے مسلسل پرنٹ 90 سینٹی میٹر تک محدود ہے۔");
            }
            android.util.Log.i("STAR_BAGS_PRINT", "ESC*24 start: widthDots=" + w + ", heightRows=" + h + ", stripeRows=24, bytesPerStripe=" + (w * 3));
            OutputStream out = thermalSocket.getOutputStream();
            int[] rowPixels = new int[w];
            int stripeIndex = 0;
            long totalBytes = 0L;
            final int stripeRows = 24;
            final int feedDots = 24;
            synchronized (this) {
                // ESC @ resets stale modes once per receipt, not between stripes.
                out.write(new byte[]{0x1B, 0x40});
                out.write(new byte[]{0x1B, 0x61, 0x00}); // left aligned, full 384-dot printable area
                for (int y0 = 0; y0 < h; y0 += stripeRows) {
                    int rows = Math.min(stripeRows, h - y0);
                    if (w == 384) {
                        // MPT-II: ESC * mode 33 is a 24-dot column-format bit image.
                        // 1,152 data + 5-byte header + 3-byte ESC J feed = 1,160 bytes,
                        // below the ~3-KB MPT-Series receive buffer and the 40-KB bitmap variant limit.
                        byte[] columns = new byte[w * 3];
                        for (int dy = 0; dy < stripeRows; dy++) {
                            int y = y0 + dy;
                            if (y >= h) break; // last stripe is white-padded; no source rows are lost
                            bitmap.getPixels(rowPixels, 0, w, 0, y, w, 1);
                            int byteInColumn = dy / 8;
                            int bitMask = 0x80 >> (dy % 8);
                            for (int x = 0; x < w; x++) {
                                int pixel = rowPixels[x];
                                int gray = (android.graphics.Color.red(pixel) * 299
                                        + android.graphics.Color.green(pixel) * 587
                                        + android.graphics.Color.blue(pixel) * 114) / 1000;
                                if (gray < 185) columns[x * 3 + byteInColumn] |= (byte) bitMask;
                            }
                        }
                        // ESC * 33 nL nH; n is the number of horizontal dots (not bytes).
                        out.write(new byte[]{0x1B, 0x2A, 33, (byte) (w & 0xFF), (byte) ((w >> 8) & 0xFF)});
                        int sent = 0;
                        while (sent < columns.length) {
                            int packet = Math.min(256, columns.length - sent);
                            out.write(columns, sent, packet);
                            sent += packet;
                        }
                        // ESC J 24 prints/flushes this bit-image stripe and advances exactly 24 dots.
                        out.write(new byte[]{0x1B, 0x4A, (byte) feedDots});
                        totalBytes += 8L + columns.length;
                    } else {
                        // 80mm/576-dot path: keep GS v 0 but limit each image to 24 rows.
                        // A 72-byte row × 24 rows = 1,728 bytes, also below a 3-KB receive buffer.
                        int bytesPerRow = (w + 7) / 8;
                        byte[] band = new byte[bytesPerRow * rows];
                        for (int ry = 0; ry < rows; ry++) {
                            bitmap.getPixels(rowPixels, 0, w, 0, y0 + ry, w, 1);
                            int rowOffset = ry * bytesPerRow;
                            for (int x = 0; x < w; x++) {
                                int pixel = rowPixels[x];
                                int gray = (android.graphics.Color.red(pixel) * 299
                                        + android.graphics.Color.green(pixel) * 587
                                        + android.graphics.Color.blue(pixel) * 114) / 1000;
                                if (gray < 185) band[rowOffset + (x / 8)] |= (byte) (0x80 >> (x % 8));
                            }
                        }
                        out.write(new byte[]{0x1D, 0x76, 0x30, 0x00,
                                (byte) (bytesPerRow & 0xFF), (byte) ((bytesPerRow >> 8) & 0xFF),
                                (byte) (rows & 0xFF), (byte) ((rows >> 8) & 0xFF)});
                        int sent = 0;
                        while (sent < band.length) {
                            int packet = Math.min(256, band.length - sent);
                            out.write(band, sent, packet);
                            sent += packet;
                        }
                        totalBytes += 8L + band.length;
                    }
                    out.flush();
                    stripeIndex++;
                    if (stripeIndex == 1 || stripeIndex % 20 == 0 || y0 + rows >= h) {
                        android.util.Log.i("STAR_BAGS_PRINT", "Thermal stripe " + stripeIndex
                                + ": y=" + y0 + ".." + (y0 + rows - 1)
                                + ", rows=" + rows + ", totalBytes=" + totalBytes);
                    }
                    // 24 dots are 3 mm on the 203-dpi MPT-II; this pacing is deliberately
                    // gentle while allowing the head to finish each small image before next.
                    try { Thread.sleep(65L); }
                    catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw new IOException("Bluetooth پرنٹنگ منقطع ہوگئی۔", interrupted);
                    }
                }
                // A small final tear-off gap; does not add another raster image.
                out.write(new byte[]{0x1B, 0x4A, 12});
                out.flush();
                android.util.Log.i("STAR_BAGS_PRINT", "ESC*24 complete: stripes=" + stripeIndex
                        + ", sourceRows=" + h + ", bytes=" + totalBytes + ", finalFeedDots=12");
            }
            org.json.JSONObject result = new org.json.JSONObject();
            result.put("ok", true);
            result.put("message", "رسید کے تمام چھوٹے 24-dot حصے پرنٹر کو بھیج دیے گئے۔ کاغذ پر آخری حصہ ضرور چیک کریں۔");
            sendPrinterCallback(callback, result.toString());
        } catch (Exception e) {
            printerError(callback, "پرنٹ نہیں ہو سکا: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private void showImagePrintPreview(Uri uri, int targetWidth, String callback) {
        android.graphics.Bitmap previewBitmap = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("منتخب تصویر نہیں کھل سکی۔");
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth < 1 || bounds.outHeight < 1) throw new IOException("JPG یا PNG تصویر منتخب کریں۔");
            int sample = 1;
            while ((bounds.outWidth / sample) > targetWidth * 2 || (bounds.outHeight / sample) > 2400) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("منتخب تصویر دوبارہ نہیں کھل سکی۔");
                previewBitmap = BitmapFactory.decodeStream(in, null, opts);
            }
            if (previewBitmap == null) throw new IOException("تصویر کا Preview نہیں بن سکا۔");
            ImageView image = new ImageView(this);
            image.setImageBitmap(previewBitmap);
            image.setAdjustViewBounds(true);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setBackgroundColor(Color.WHITE);
            image.setPadding(8, 8, 8, 8);
            ScrollView scroll = new ScrollView(this);
            scroll.addView(image, new ScrollView.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            TextView details = new TextView(this);
            details.setText("تصویر Preview — منتخب Scale کے مطابق سائز بدلے گا، اصل تناسب برقرار رہے گا، تصویر درمیان میں پرنٹ ہوگی۔\nاصل تصویر: " + bounds.outWidth + " × " + bounds.outHeight);
            details.setPadding(12, 8, 12, 8);
            content.addView(details);
            TextView scaleLabel = new TextView(this);
            scaleLabel.setText("تصویر کا سائز / Scale (1X = ایک تہائی چوڑائی؛ 3X = پوری 58mm چوڑائی)");
            scaleLabel.setPadding(12, 8, 12, 4);
            content.addView(scaleLabel);
            Spinner scaleSpinner = new Spinner(this);
            ArrayAdapter<String> scaleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, PRINT_SCALE_OPTIONS);
            scaleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            scaleSpinner.setAdapter(scaleAdapter);
            float savedImageScale = getSharedPreferences("star_bags_print_preferences", MODE_PRIVATE).getFloat("scale", 1.0f);
            int savedImagePosition = 2;
            boolean exactImagePreset = false;
            for (int i=0;i<PRINT_SCALE_OPTIONS.length-1;i++) {
                if (Math.abs(Float.parseFloat(PRINT_SCALE_OPTIONS[i].replace("X", ""))-savedImageScale)<0.001f) { savedImagePosition=i; exactImagePreset=true; break; }
            }
            if (!exactImagePreset) savedImagePosition = PRINT_SCALE_OPTIONS.length-1;
            scaleSpinner.setSelection(savedImagePosition);
            content.addView(scaleSpinner);
            EditText customScale = new EditText(this);
            customScale.setSingleLine(true);
            customScale.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            customScale.setHint("Custom Scale (0.1 سے 5X)");
            customScale.setText(String.valueOf(savedImageScale));
            customScale.setVisibility(savedImagePosition == PRINT_SCALE_OPTIONS.length-1 ? View.VISIBLE : View.GONE);
            content.addView(customScale);
            android.widget.CheckBox applyImageToAll = new android.widget.CheckBox(this);
            applyImageToAll.setText("Apply to All — یہ Scale آئندہ پرنٹس کے لیے محفوظ کریں");
            applyImageToAll.setChecked(true);
            content.addView(applyImageToAll);
            scaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    customScale.setVisibility(position == PRINT_SCALE_OPTIONS.length - 1 ? View.VISIBLE : View.GONE);
                    try { float previewScale = parsePrintScale(String.valueOf(scaleSpinner.getSelectedItem()), customScale.getText().toString()); float visualScale = Math.max(0.03f, Math.min(1.0f, previewScale / 3.0f)); image.setScaleX(visualScale); image.setScaleY(visualScale); } catch (Exception ignored) {}
                }
                @Override public void onNothingSelected(AdapterView<?> parent) {}
            });
            customScale.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (scaleSpinner.getSelectedItemPosition() == PRINT_SCALE_OPTIONS.length - 1) { try { float visualScale = Math.max(0.03f, Math.min(1.0f, parsePrintScale("Custom", s.toString()) / 3.0f)); image.setScaleX(visualScale); image.setScaleY(visualScale); } catch (Exception ignored) {} }
                }
                @Override public void afterTextChanged(android.text.Editable e) {}
            });
            content.addView(scroll, new LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    (int) (360 * getResources().getDisplayMetrics().density)));
            final android.graphics.Bitmap dialogBitmap = previewBitmap;
            AlertDialog imageDialog = new AlertDialog.Builder(this)
                    .setTitle("تصویر کا سائز منتخب کریں — اگلا Preview")
                    .setView(content)
                    .setNegativeButton("منسوخ", (d, which) -> { if (!dialogBitmap.isRecycled()) dialogBitmap.recycle(); })
                    .setPositiveButton("اگلا Preview", null)
                    .setOnCancelListener(d -> { if (!dialogBitmap.isRecycled()) dialogBitmap.recycle(); })
                    .create();
            imageDialog.show();
            imageDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    float scale = parsePrintScale(String.valueOf(scaleSpinner.getSelectedItem()), customScale.getText().toString());
                    if (applyImageToAll.isChecked()) getSharedPreferences("star_bags_print_preferences", MODE_PRIVATE).edit().putFloat("scale", scale).apply();
                    imageDialog.dismiss();
                    if (!dialogBitmap.isRecycled()) dialogBitmap.recycle();
                    new Thread(() -> printSelectedImage(uri, targetWidth, callback, scale)).start();
                } catch (Exception ex) { Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        } catch (Exception e) {
            if (previewBitmap != null && !previewBitmap.isRecycled()) previewBitmap.recycle();
            printerError(callback, "تصویر کا Preview نہیں بن سکا: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        }
    }

    private void printSelectedImage(Uri uri, int targetWidth, String callback, float printScale) {
        android.graphics.Bitmap decoded = null;
        android.graphics.Bitmap resized = null;
        try {
            ensureThermalPrinterConnected();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("منتخب تصویر نہیں کھل سکی۔");
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth < 1 || bounds.outHeight < 1) throw new IOException("منتخب فائل درست تصویر نہیں ہے۔ JPG یا PNG منتخب کریں۔");
            int sample = 1;
            while ((bounds.outWidth / sample) > targetWidth * 2) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("منتخب تصویر دوبارہ نہیں کھل سکی۔");
                decoded = BitmapFactory.decodeStream(in, null, opts);
            }
            if (decoded == null) throw new IOException("تصویر decode نہیں ہو سکی۔ دوسری تصویر منتخب کریں۔");
            // Image scale is proportional: 1X uses one-third paper width and 3X reaches full width.
            // The image is centered and aspect ratio is preserved; no cropping or stretching.
            int imageWidth = Math.max(1, Math.min(targetWidth, Math.round(targetWidth * (printScale / 3.0f))));
            int imageHeight = Math.max(1, Math.round(decoded.getHeight() * (imageWidth / (float) decoded.getWidth())));
            long pixels = (long) targetWidth * imageHeight;
            if (imageHeight < 1 || pixels > Integer.MAX_VALUE * 8L) throw new IOException("تصویر کی پیمائش Android کی قابلِ پیمائش حد سے زیادہ ہے۔");
            android.util.Log.i("STAR_BAGS_PRINT", "Scaled image: source=" + decoded.getWidth() + "x" + decoded.getHeight() + ", paperRasterWidth=" + targetWidth + ", imageWidth=" + imageWidth + ", imageHeight=" + imageHeight + ", scale=" + printScale + "X, aspectPreserved=true");
            android.graphics.Bitmap proportional = android.graphics.Bitmap.createScaledBitmap(decoded, imageWidth, imageHeight, true);
            if (proportional != decoded) { decoded.recycle(); decoded = null; }
            resized = android.graphics.Bitmap.createBitmap(targetWidth, imageHeight, android.graphics.Bitmap.Config.RGB_565);
            android.graphics.Canvas imageCanvas = new android.graphics.Canvas(resized);
            imageCanvas.drawColor(Color.WHITE);
            imageCanvas.drawBitmap(proportional, (targetWidth - imageWidth) / 2f, 0f, null);
            if (!proportional.isRecycled()) proportional.recycle();
            android.graphics.Bitmap finalPrintBitmap = resized;
            resized = null;
            showBitmapPrintPreview(finalPrintBitmap, callback, targetWidth, "تصویر — اصل پرنٹ Preview");
        } catch (OutOfMemoryError e) {
            printerError(callback, "تصویر بہت بڑی ہے اور موبائل کی دستیاب میموری کافی نہیں۔ چھوٹی یا کم ریزولوشن والی تصویر منتخب کریں۔");
        } catch (Exception e) {
            printerError(callback, "تصویر پرنٹ نہیں ہو سکی: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
        } finally {
            if (decoded != null && !decoded.isRecycled()) decoded.recycle();
            if (resized != null && !resized.isRecycled()) resized.recycle();
        }
    }

    private void disconnectThermalPrinter() {
        closeSharedPrinterSocket();
    }

    static void closeSharedPrinterSocket() {
        BluetoothSocket socket = thermalSocket;
        thermalSocket = null;
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
    }

    private void refreshPrinterKeepAlive() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (lastPrinterKeepAliveRefreshMs > 0L && now - lastPrinterKeepAliveRefreshMs < 60_000L) return;
        lastPrinterKeepAliveRefreshMs = now;
        try {
            Intent service = new Intent(this, PrinterKeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
        } catch (Exception e) {
            android.util.Log.w("STAR_BAGS_BT", "Background printer service could not be refreshed", e);
        }
    }

    private boolean connectThermalPrinter(String address) throws Exception {
        if (!hasBluetoothConnectPermission()) throw new SecurityException("Bluetooth اجازت نہیں ملی۔");
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new IOException("اس موبائل میں Bluetooth دستیاب نہیں۔");
        if (!adapter.isEnabled()) throw new IOException("موبائل کا Bluetooth بند ہے۔ پہلے اسے آن کریں۔");
        BluetoothDevice device = adapter.getRemoteDevice(address);
        disconnectThermalPrinter();
        BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
        socket.connect();
        thermalSocket = socket;
        thermalPrinterAddress = address;
        refreshPrinterKeepAlive();
        getSharedPreferences("star_bags_printer", MODE_PRIVATE).edit().putString("address", address).putString("name", device.getName()).apply();
        return true;
    }

    public class StarBagsBridge {
        @JavascriptInterface public void getPairedThermalPrinters(String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) { printerError(callback, "اس موبائل میں Bluetooth دستیاب نہیں۔"); return; }
                if (!adapter.isEnabled()) { printerError(callback, "Bluetooth بند ہے۔ پہلے موبائل Settings میں آن کریں۔"); return; }
                org.json.JSONArray devices = new org.json.JSONArray();
                Set<BluetoothDevice> paired = adapter.getBondedDevices();
                for (BluetoothDevice device : paired) {
                    org.json.JSONObject item = new org.json.JSONObject();
                    item.put("name", device.getName() == null ? "Bluetooth Printer" : device.getName());
                    item.put("address", device.getAddress());
                    devices.put(item);
                }
                org.json.JSONObject result = new org.json.JSONObject();
                result.put("ok", true); result.put("devices", devices);
                result.put("savedAddress", getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", ""));
                sendPrinterCallback(callback, result.toString());
            } catch (SecurityException e) { printerError(callback, "Bluetooth اجازت درکار ہے۔"); }
            catch (Exception e) { printerError(callback, "Paired پرنٹرز کی فہرست نہیں مل سکی: " + e.getMessage()); }
        }

        @JavascriptInterface public void connectThermalPrinter(String address, String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            new Thread(() -> {
                try {
                    MainActivity.this.connectThermalPrinter(address);
                    org.json.JSONObject result = new org.json.JSONObject();
                    result.put("ok", true); result.put("message", "پرنٹر کنیکٹ ہوگیا۔");
                    result.put("address", address);
                    sendPrinterCallback(callback, result.toString());
                } catch (Exception e) { printerError(callback, "کنکشن نہیں ہو سکا: " + (e.getMessage() == null ? e.toString() : e.getMessage())); }
            }).start();
        }


        @JavascriptInterface public void printBillHtml(String billHtml, String paperWidth, String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            if (billHtml == null || billHtml.trim().isEmpty()) { printerError(callback, "بل کا Preview خالی ہے۔ پہلے بل تیار کریں۔"); return; }
            runOnUiThread(() -> showPrintScaleDialog("بل / پڑتا پرنٹ سیٹنگز", (scale, font, bold) ->
                    renderBillForThermalPrinter(billHtml, "80".equals(paperWidth) ? 576 : 384, callback, scale, font, bold)));
        }

        @JavascriptInterface public void chooseImageToPrint(String paperWidth, String callback) {
            if ("a4".equalsIgnoreCase(paperWidth)) {
                printerError(callback, "تصویر کی Bluetooth تھرمل پرنٹنگ کے لیے 58mm یا 80mm منتخب کریں۔ A4 عام پرنٹر کا الگ طریقہ ہے۔");
                return;
            }
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            pendingImagePrintCallback = callback == null ? "" : callback;
            pendingImagePaperDots = "80".equals(paperWidth) ? 576 : 384;
            runOnUiThread(() -> {
                try {
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");
                    startActivityForResult(pick, PICK_PRINT_IMAGE);
                } catch (Exception e) {
                    printerError(pendingImagePrintCallback, "تصویر منتخب کرنے کا آپشن نہیں کھل سکا۔");
                    pendingImagePrintCallback = "";
                }
            });
        }

        @JavascriptInterface public void printThermalTest(String callback) {
            if (!hasBluetoothConnectPermission()) { ensureBluetoothPermission(callback); return; }
            new Thread(() -> {
                try {
                    if (thermalSocket == null || !thermalSocket.isConnected()) {
                        String saved = getSharedPreferences("star_bags_printer", MODE_PRIVATE).getString("address", "");
                        if (saved.isEmpty()) throw new IOException("پہلے MPT-II پرنٹر کنیکٹ کریں۔");
                        MainActivity.this.connectThermalPrinter(saved);
                    }
                    refreshPrinterKeepAlive();
                    OutputStream out = thermalSocket.getOutputStream();
                    out.write(new byte[]{0x1B, 0x40}); // ESC @ initialize
                    out.write(new byte[]{0x1B, 0x61, 0x01}); // center
                    out.write("STAR BAGS\n".getBytes("US-ASCII"));
                    out.write("It is work\n".getBytes("US-ASCII"));
                    out.write("MPT-II Bluetooth Test\n".getBytes("US-ASCII"));
                    out.write(new byte[]{0x1B, 0x61, 0x00});
                    out.write("Bluetooth SPP / ESC-POS\n".getBytes("US-ASCII"));
                    out.write(new byte[]{0x0A,0x0A,0x0A,0x0A});
                    out.flush();
                    org.json.JSONObject result = new org.json.JSONObject();
                    result.put("ok", true); result.put("message", "ٹیسٹ رسید پرنٹ بھیج دی گئی۔");
                    sendPrinterCallback(callback, result.toString());
                } catch (Exception e) { printerError(callback, "پرنٹ نہیں ہو سکی: " + (e.getMessage() == null ? e.toString() : e.getMessage())); }
            }).start();
        }

        @JavascriptInterface public void openContactPicker() {
            runOnUiThread(() -> {
                try {
                    Intent pick = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    startActivityForResult(pick, PICK_CONTACT);
                } catch (Exception e) {
                    if (webView != null) webView.evaluateJavascript("window.onStarBagsContactError && window.onStarBagsContactError()", null);
                    Toast.makeText(MainActivity.this, "فون کے Contacts دستیاب نہیں۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void setPullToRefreshEnabled(boolean enabled) {
            runOnUiThread(() -> { if (swipeRefresh != null) swipeRefresh.setEnabled(enabled); });
        }

        @JavascriptInterface public void scheduleSeasonReminder(String title, String body) {
            runOnUiThread(() -> {
                try {
                    getSharedPreferences("star_bags_reminders", MODE_PRIVATE).edit()
                            .putString("title", title == null ? "STAR BAGS سیزن پلانر" : title)
                            .putString("body", body == null ? "اگلے سیزن کی تیاری کا منصوبہ دیکھیں۔" : body)
                            .putBoolean("enabled", true).apply();
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1201);
                    }
                    Calendar first = Calendar.getInstance();
                    first.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                    first.set(Calendar.HOUR_OF_DAY, 9); first.set(Calendar.MINUTE, 0); first.set(Calendar.SECOND, 0); first.set(Calendar.MILLISECOND, 0);
                    if (first.getTimeInMillis() <= System.currentTimeMillis()) first.add(Calendar.DAY_OF_YEAR, 7);
                    Intent intent = new Intent(MainActivity.this, SeasonReminderReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 1202, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
                    if (alarm != null) alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, first.getTimeInMillis(), AlarmManager.INTERVAL_DAY * 7, pi);
                    Toast.makeText(MainActivity.this, "ہر پیر صبح 9 بجے سیزن پلانر ریمائنڈر سیٹ ہوگیا۔", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ریمائنڈر سیٹ نہیں ہو سکا۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void cancelSeasonReminder() {
            try {
                Intent intent = new Intent(MainActivity.this, SeasonReminderReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 1202, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
                if (alarm != null) alarm.cancel(pi);
                pi.cancel();
                getSharedPreferences("star_bags_reminders", MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
                Toast.makeText(MainActivity.this, "سیزن پلانر ریمائنڈر بند ہوگیا۔", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(MainActivity.this, "ریمائنڈر بند نہیں ہو سکا۔", Toast.LENGTH_SHORT).show(); }
        }

        @JavascriptInterface public void saveBackup(String base64, String filename, String mimeType) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> saveBackupBytes(bytes, filename, mimeType));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بیک اپ فائل تیار نہیں ہو سکی۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBillImage(String base64, String phone, String message) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared_bills");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cache directory unavailable");
                File file = new File(dir, "STAR-BAGS-Bill.png");
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                String number = phone == null ? "" : phone.replaceAll("[^0-9]", "");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message == null ? "STAR BAGS Bill" : message);
                if (!number.isEmpty()) send.putExtra("jid", number + "@s.whatsapp.net");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newUri(getContentResolver(), "STAR BAGS Bill", uri));
                runOnUiThread(() -> {
                    try {
                        Intent business = new Intent(send);
                        business.setPackage("com.whatsapp.w4b");
                        startActivity(business);
                    } catch (Exception noBusiness) {
                        try {
                            Intent normal = new Intent(send);
                            normal.setPackage("com.whatsapp");
                            startActivity(normal);
                        } catch (Exception noWhatsApp) {
                            try { startActivity(Intent.createChooser(send, "STAR BAGS — بل شیئر کریں")); }
                            catch (Exception e) { Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔", Toast.LENGTH_LONG).show(); }
                        }
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "بل شیئر نہیں ہو سکا۔ دوبارہ کوشش کریں۔", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareCatalog(String payloadJson) {
            runOnUiThread(() -> {
                try {
                    org.json.JSONObject payload = new org.json.JSONObject(payloadJson == null ? "{}" : payloadJson);
                    String message = payload.optString("text", "STAR BAGS Product Catalog");
                    org.json.JSONArray files = payload.optJSONArray("files");
                    java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                    File dir = new File(getCacheDir(), "catalog_share");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cache directory unavailable");
                    if (files != null) {
                        for (int i = 0; i < files.length(); i++) {
                            org.json.JSONObject item = files.optJSONObject(i);
                            if (item == null) continue;
                            String base64 = item.optString("base64", "");
                            if (base64.isEmpty()) continue;
                            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                            String filename = item.optString("name", "STAR-BAGS-Product-" + (i + 1) + ".jpg").replaceAll("[^A-Za-z0-9._-]", "_");
                            File file = new File(dir, filename);
                            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                            uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file));
                        }
                    }
                    Intent send;
                    if (uris.size() > 1) {
                        send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        send.setType("image/*");
                        send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    } else if (uris.size() == 1) {
                        send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/*");
                        send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                    } else {
                        send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                    }
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (!uris.isEmpty()) {
                        ClipData clip = ClipData.newUri(getContentResolver(), "STAR BAGS Catalog", uris.get(0));
                        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                        send.setClipData(clip);
                    }
                    try {
                        Intent business = new Intent(send); business.setPackage("com.whatsapp.w4b"); startActivity(business);
                    } catch (Exception noBusiness) {
                        try { Intent normal = new Intent(send); normal.setPackage("com.whatsapp"); startActivity(normal); }
                        catch (Exception noWhatsApp) { startActivity(Intent.createChooser(send, "STAR BAGS Catalog شیئر کریں")); }
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "کیٹلاگ شیئر نہیں ہو سکا۔ کم آئٹمز منتخب کرکے دوبارہ کوشش کریں۔", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void openSms(String phone, String message) {
            try {
                Uri uri = Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone));
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", message == null ? "" : message);
                startActivity(intent);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "SMS ایپ دستیاب نہیں۔", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    results = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) {
                        results[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
            return;
        }
        if (requestCode == PICK_PRINT_IMAGE) {
            String callback = pendingImagePrintCallback;
            pendingImagePrintCallback = "";
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri imageUri = data.getData();
                final int dots = pendingImagePaperDots;
                runOnUiThread(() -> showImagePrintPreview(imageUri, dots, callback));
            } else if (!callback.isEmpty()) {
                org.json.JSONObject result = new org.json.JSONObject();
                try { result.put("ok", false); result.put("message", "تصویر منتخب نہیں کی گئی۔"); } catch (Exception ignored) {}
                sendPrinterCallback(callback, result.toString());
            }
            return;
        }
        if (requestCode == PICK_CONTACT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                String name = "", phone = "";
                Cursor cursor = null;
                try {
                    String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
                    cursor = getContentResolver().query(data.getData(), projection, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        if (nameIndex >= 0) name = cursor.getString(nameIndex);
                        if (phoneIndex >= 0) phone = cursor.getString(phoneIndex);
                    }
                } catch (Exception ignored) {
                } finally { if (cursor != null) cursor.close(); }
                if (webView != null && !phone.trim().isEmpty()) {
                    final String js = "window.onStarBagsContactSelected && window.onStarBagsContactSelected(" + org.json.JSONObject.quote(name == null ? "" : name) + "," + org.json.JSONObject.quote(phone) + ");";
                    webView.evaluateJavascript(js, null);
                } else if (webView != null) {
                    webView.evaluateJavascript("window.onStarBagsContactError && window.onStarBagsContactError()", null);
                    Toast.makeText(this, "منتخب رابطے میں فون نمبر موجود نہیں۔", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == CREATE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Unable to open destination");
                    out.write(pendingBackupBytes);
                    Toast.makeText(this, "بیک اپ فائل محفوظ ہوگئی۔", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "بیک اپ فائل محفوظ نہیں ہو سکی۔", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupBytes = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
                "(function(){try{return window.starBagsHandleBack?window.starBagsHandleBack():false;}catch(e){return false;}})();",
                value -> {
                    if (value == null || "false".equals(value) || "null".equals(value)) finish();
                });
    }

    @Override protected void onDestroy() {
        // Do not close the Bluetooth socket here: the foreground keep-alive service
        // owns its 30-minute inactivity window and survives the Activity going away.
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
