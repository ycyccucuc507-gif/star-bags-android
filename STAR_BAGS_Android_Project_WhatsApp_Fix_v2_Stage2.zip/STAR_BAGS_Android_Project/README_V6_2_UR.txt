STAR BAGS Android Project — V6.2 Upgrade
========================================

Build:
1. Android Studio کھولیں۔
2. اس فولڈر کو Open کریں جس میں settings.gradle موجود ہے۔
3. Gradle Sync مکمل ہونے دیں۔
4. Build > Make Project یا Build > Build APK(s) چلائیں۔
5. app/build/outputs/apk/debug/app-debug.apk میں Debug APK ملے گی۔

نئے فیچرز کی مکمل تفصیل UPGRADE_V6_2_REPORT_UR.txt میں ہے۔

WhatsApp Auto Fill:
- Android Settings میں STAR BAGS کے لیے Notification Access صرف اپنی اجازت سے فعال کریں۔
- ایپ Settings > WhatsApp Order Alert میں آرڈر کے الفاظ درج رکھیں۔
- Menu > آرڈرز میں WhatsApp پیغام کھول کر Auto Fill دبائیں۔
- اگر Notification میں فون نمبر نہ ہو تو Auto Fill نمبر پوچھے گا۔ درست نمبر درج کرنے پر پہلے سے موجود Party کی شناخت اور اس کا محفوظ اردو نام استعمال ہوگا۔
- Auto Fill بل خود محفوظ نہیں کرتا۔ آئٹم نہ پہچانا جائے تو سیل شیٹ میں خود منتخب کریں۔

Automatic Backup:
- Settings > Backup میں مقدار اور منٹ/گھنٹے/دن منتخب کرکے Schedule محفوظ کریں۔
- فولڈر منتخب کریں یا Default STAR BAGS app-private backup location استعمال کریں۔
- WorkManager کی periodic scheduling Android کے مطابق کم از کم 15 منٹ اور تاخیر کے امکان کے ساتھ ہے۔
- Restore کے وقت درست JSON backup منتخب کریں؛ موجودہ ڈیٹا کی تبدیلی سے پہلے وارننگ دکھائی جائے گی۔

Public Catalog:
- Firebase URL، Shop ID اور WhatsApp نمبر سیٹ کریں۔
- Online Store میں ہر آئٹم کی تفصیل کھول کر Public Catalog checkbox آن کریں۔
- Publish بٹن استعمال کریں؛ Auto Publish setting فعال ہو تو آئٹمز کی تبدیلی کے بعد آن لائن ہونے پر خود بھی اپ ڈیٹ ہوگا۔
- Public read صرف starbags_catalog/<shopId> پر دیں؛ کاروباری ڈیٹا starbags/<shopId> نجی رکھیں۔

Build اور حقیقی ڈیوائس ٹیسٹ کے بارے میں حدود UPGRADE_V6_2_REPORT_UR.txt میں درج ہیں۔
