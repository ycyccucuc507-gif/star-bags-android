STAR BAGS Android Project V4.10

یہ Android Studio source project ہے، تیار شدہ APK نہیں۔

اہم فائلیں:
- app/src/main/java/com/starbags/app/MainActivity.java
- app/src/main/assets/index.html
- app/build.gradle

V4.10 میں full-height PDF receipt rendering، tile-based raster preview/printing اور Printer Lab شامل ہیں۔
اصل بل کا HTML layout اور حساب کتاب جان بوجھ کر تبدیل نہیں کیا گیا۔

تفصیلی تبدیلیاں اور ٹیسٹ کی حدود TEST_REPORT_UR.txt میں درج ہیں۔
