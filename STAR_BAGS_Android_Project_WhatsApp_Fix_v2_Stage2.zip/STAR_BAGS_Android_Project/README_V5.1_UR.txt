STAR BAGS V5.1 — Mobile billing layout and settings navigation
Date: 19 November 2026
Base: Uploaded V5.0 source ZIP (versionCode 33), preserved in-place.

Changes:
1. Added a separate gear button and a dedicated Settings hub. The existing hamburger menu remains the module/navigation menu.
2. Settings hub provides shortcuts to the existing bill/receipt print settings, printer tools, backup section and online-store tools. It does not duplicate the module menu.
3. Compact sale-entry table: product/source/rate controls are grouped in the first cell; quantity and calculated line total remain visible in separate columns. The horizontal minimum table width was removed for narrow phone screens.
4. Existing row calculation selectors (.sheet-product, .sheet-source, .sheet-qty, .sheet-rate) and the current data model remain unchanged.
5. Android versionCode incremented to 34; versionName 5.1-mobile-ui-settings.

Data/compatibility:
- No localStorage keys, backup JSON version/schema, bill record schema, stock calculations, printer raster sender, or Pertah three-column print HTML were changed.
- Existing V2/V5 JSON backup import path remains in place. Always keep a separate copy before installing an upgraded APK.
- The existing app still stores operational records in WebView localStorage. This update does NOT migrate data to SQLite/Room/IndexedDB or create automatic cloud backup.
- Current WhatsApp integration remains share/local order functionality. Automatic inbound WhatsApp message capture requires WhatsApp Business Platform/API, a verified webhook endpoint and secure server credentials; it is not activated by this source-only update.
- PIN/biometric authentication, cloud multi-device sync, public hosted store, barcode scanning, GST, PDF party statement and scheduled cloud backups are not claimed as implemented.

Validation:
- Static JavaScript syntax and ZIP integrity checks are required before release.
- Android Gradle build and physical 58mm MPT-II printing must be performed on a real Android device/printer. Preview/source changes do not prove hardware output.
