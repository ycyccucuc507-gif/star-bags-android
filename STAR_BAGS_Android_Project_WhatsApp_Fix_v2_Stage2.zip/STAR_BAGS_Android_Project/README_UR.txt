STAR BAGS Android Project — Version 1.3 (15 requirements update)

یہ Android Studio کا مکمل سورس پروجیکٹ ہے۔ موجودہ HTML billing app کو Android WebView میں چلایا جاتا ہے۔

اس ورژن میں شامل/درست کیے گئے اہم کام:
1) WhatsApp intent:// اور wa.me لنکس کو Android native routing کے ذریعے کھولنا؛ پہلے WhatsApp Business، پھر عام WhatsApp۔
2) بل بننے پر خودکار محفوظ کاری؛ موجودہ ریکارڈ میں ترمیم ہو تو اسی بل کو اپ ڈیٹ کرنا۔
3) بل کی PNG تصویر تیار کرنا اور اصل تصویر کو WhatsApp share intent کے ساتھ منسلک کرنا۔
4) Save، Print/PDF اور Send کے بٹن؛ Thermal/A4 پرنٹ کے موجودہ اختیارات برقرار۔
5) پارٹی کے محفوظ فون نمبر کو WhatsApp share میں استعمال کرنے کی کوشش۔
6) موجودہ STAR BAGS لوگو اور کمپنی نام محفوظ؛ Splash پر صرف STAR BAGS نام (STAR BAG HOUSE نہیں)۔
7) تین لائنوں والا مینیو اور نیوی بلیو ہیڈر/status bar۔
8) Native splash screen۔
9) مینیو Refresh: Home پر واپس؛ Backup/Utility میں Refresh Records بٹن بھی شامل۔
10) Pull-to-refresh: نیچے کھینچنے پر Home؛ فارم اور اندرونی اسکرول کے gestures کے لیے touch guard۔
11) Android Back navigation: کھلے ہوئے modules سے ایک ایک قدم پیچھے؛ Home پر Back سے ایپ بند۔
12) Full JSON backup میں bills, products, parties, purchases, payments, expenses, labor, recycle bin, costing ledger اور app settings شامل۔
13) Android 10+ پر Downloads/STAR BAGS میں backup محفوظ؛ ناکامی کی صورت میں Save As picker؛ پرانے Android پر بھی Save As۔
14) Backup restore، موجودہ data structure اور اضافی ledgers سمیت برقرار۔
15) GitHub Actions workflow Gradle 8.9، Java 17، Android SDK 35 کے ساتھ debug APK بناتا ہے۔

Backup کے بارے میں:
- بیک اپ بٹن اب Android bridge کے ذریعے JSON فائل محفوظ کرتا ہے۔ Android 10+ میں فائل Downloads/STAR BAGS فولڈر میں جاتی ہے۔
- اگر فون کا Downloads provider دستیاب نہ ہو تو Android Save As picker کھلے گا۔
- Restore کرنے سے پہلے موجودہ ڈیٹا کی الگ backup فائل ضرور بنا لیں۔

GitHub پر اپلوڈ:
1) ZIP کو Extract کریں۔
2) Repository کے root میں STAR_BAGS_Android_Project فولڈر اور .github/workflows/build-apk.yml اپلوڈ کریں۔
3) پرانا .github/workflows/main.yml اگر موجود ہو تو اسے حذف کریں تاکہ دو workflows ایک ساتھ نہ چلیں۔
4) GitHub → Actions → Build STAR BAGS APK → Run workflow۔
5) کامیاب build کے بعد STAR-BAGS-APK artifact سے app-debug.apk حاصل کریں۔

اہم احتیاط اور ٹیسٹنگ:
- نئی APK انسٹال کرنے سے پہلے موجودہ ایپ سے Full Backup JSON بنائیں۔
- اگر signing key مختلف ہو تو نئی APK پرانی ایپ کے اوپر update نہیں ہوگی؛ پرانی ایپ uninstall کرنے سے پہلے signing key اور backup کی تصدیق کریں۔
- WhatsApp آخری Send صارف کے ہاتھ میں رکھتا ہے؛ ایپ خودکار طور پر پیغام نہیں بھیجتی۔ WhatsApp کے ورژن کے مطابق chat picker آ سکتا ہے۔
- اس ماحول میں Android SDK/Gradle دستیاب نہیں، اس لیے یہاں APK build یا فون پر runtime test ممکن نہیں ہوا۔ HTML کے تمام inline JavaScript بلاکس `node --check` سے syntax-checked ہیں؛ GitHub Actions build اور اصل موبائل پر عملی ٹیسٹ لازمی ہیں۔


اپ ڈیٹ v1.4 (2026-11-05): STAR BAGS لوگو سے Android launcher icon شامل کیا گیا ہے۔ Pull-to-refresh اب Home پر جانے کے ساتھ موجودہ غیر محفوظ بل فارم اور preview بھی صاف کرتا ہے؛ محفوظ بل/ریکارڈ حذف نہیں ہوتے۔
اہم: پارٹی لیجر میں پرانے بقایا اور وصولیوں کا مکمل transaction-based حساب، ادائیگی کی علیحدہ تاریخ، بل attachment اور باقی نئی درخواستوں کی مکمل implementation اس پیکج میں شامل/مصدقہ نہیں؛ اسے مکمل فیچر اپ ڈیٹ نہ سمجھیں۔


اپ ڈیٹ 1.4.1 (2026-11-05):
- سیل بل کے Next کے بعد آنے والے اضافی تفصیلات والے مرحلے میں اختیاری “بل کے ساتھ تصویر اٹیچ کریں” فیلڈ شامل ہے۔
- ہاتھ سے لکھے ہوئے بل کی تصویر منتخب کرنے پر تصویر کو کم سائز JPEG میں تبدیل کرکے بل کے ساتھ محفوظ کیا جاتا ہے۔
- PDF فائل بھی بطور منسلک دستاویز منتخب کی جا سکتی ہے (زیادہ سے زیادہ 3 MB)۔
- منسلک تصویر/دستاویز بل کے پیش منظر میں ظاہر ہوتی ہے؛ بل محفوظ کرنے پر یہ بل ریکارڈ میں شامل رہتی ہے۔
- مکمل Android APK build اور حقیقی فون پر ٹیسٹ GitHub Actions سے APK بننے کے بعد کرنا ضروری ہے۔


اپ ڈیٹ v1.5 (2026-11-06):
- مین مینو کو صارف کی نئی ترتیب کے مطابق دوبارہ منظم کیا گیا: ہوم، آج کا کاروبار، تمام سیلز بل، پارٹیز، رپورٹس، پرافٹ اینڈ لاس، آئٹمز، انوینٹری، پرچیز، مزدوری/خاندانی حساب، بیک اپ/ریکارڈ، یوٹیلٹی۔
- Profit & Loss کو مین مینو میں الگ کلک ایبل بٹن بنایا گیا ہے۔
- موجودہ بل اٹیچمنٹ (تصویر/PDF)، لوگو، Pull-to-refresh، پرنٹ/WhatsApp اور موجودہ بیک اپ/Restore کی خصوصیات برقرار رکھی گئی ہیں۔

اہم حد / دیانت دارانہ نوٹ:
یہ پیکج v1.5 کا محفوظ مینو/ورژن اپ ڈیٹ ہے، صارف کی پوری نئی فیچر فہرست کی تکمیل نہیں۔ پارٹی کے تمام پرانے بقایا جات کے لیے مرکزی transaction ledger اور خودکار cross-screen reconciliation، مکمل dashboard drill-down editing/receipts، اور Google Drive multi-device online sync اس ورژن میں implement یا certify نہیں کیے گئے۔ موجودہ app کی مقامی offline data storage برقرار ہے؛ Google Drive auto-sync موجود ہونے کا دعویٰ نہیں کیا جاتا۔

بل اٹیچمنٹ کے بارے میں:
موجودہ ورژن میں Next کے بعد اضافی تفصیلات والے مرحلے پر تصویر/PDF منتخب کرنے کی سہولت پہلے سے موجود ہے۔ اسے مکمل طور پر ہر فون پر runtime test نہیں کیا گیا؛ APK بننے کے بعد اصل فون پر جانچ ضروری ہے۔


مرحلہ 1 (v1.6-stage1): اخراجات کے اندراج میں ترمیم، محفوظ تبدیلی، حذف کے بعد دوبارہ حساب، اور رپورٹس میں Yesterday / Last 10 Days فلٹر شامل کیے گئے ہیں۔ یہ مکمل مطلوبہ اپڈیٹ نہیں ہے؛ مرکزی کسٹمر لیجر، وصولیوں کی تفصیلی تخصیص، کلک ایبل مالیاتی ڈیش بورڈ اور Google Drive Sync اگلے مرحلے کے کام ہیں۔


STAR BAGS VERSION 1.7 — STAGE 2 ADDITIONS
----------------------------------------
اس پیکج میں Stage 1 کی تبدیلیاں برقرار ہیں اور Stage 2 میں رپورٹس کے صفحے کے اوپر ایک نیا مالیاتی ڈیش بورڈ شامل کیا گیا ہے۔ اس میں تاریخ کی مدت منتخب کرکے چھ کلک ایبل کارڈز دیکھے جا سکتے ہیں: کل سیلز، پارٹی وصولیاں (وصولی رجسٹر)، بقایا، مجموعی منافع، اخراجات، اور خالص منافع۔ ہر کارڈ متعلقہ تفصیل کھولتا ہے۔ سیلز کارڈ سے متعلقہ بل کھولا جا سکتا ہے۔

بل اٹیچمنٹ میں اب محفوظ شدہ بل سے تصویر/PDF شیئر کرنے اور صرف اٹیچمنٹ حذف کرنے کے بٹن بھی شامل ہیں۔ بل حذف کیے بغیر اٹیچمنٹ الگ ہٹائی جا سکتی ہے۔

اہم حدود اور احتیاط:
1) اس ورژن میں Google Drive sign-in، cloud backup یا multi-device sync نافذ نہیں کیا گیا۔ یہ الگ Google OAuth/Drive integration اور حقیقی اکاؤنٹ ٹیسٹنگ مانگتا ہے۔
2) سابقہ بقایا خودکار طور پر نئی بل میں منتقل کرنے کا مرکزی ledger migration اس ورژن میں مکمل نہیں ہے؛ موجودہ بل/پارٹی وصولی کا پرانا نظام برقرار ہے۔ previousDue کو دستی طور پر تبدیل کرنے سے پہلے بقایا کی جانچ کریں۔
3) Dashboard کی وصولی رقم پارٹی وصولی رجسٹر سے لی جاتی ہے؛ نئے بل کے وقت درج ابتدائی paid رقم اس کارڈ میں شامل نہیں۔
4) JavaScript inline scripts کا syntax check کیا گیا ہے اور ZIP integrity check کیا گیا ہے۔ اس ماحول میں Android SDK/Gradle build اور حقیقی موبائل ٹیسٹ نہیں کیے گئے؛ GitHub Actions build کو کامیاب ہونا ضروری ہے۔
5) موجودہ ڈیٹا کا مکمل Backup بنائیں۔ APK کی signing key مختلف ہوئی تو Android پرانی ایپ کے اوپر اپڈیٹ قبول نہیں کرے گا؛ ایسی صورت میں پرانی ایپ uninstall نہ کریں، پہلے signing/data migration کا حل درکار ہوگا۔
