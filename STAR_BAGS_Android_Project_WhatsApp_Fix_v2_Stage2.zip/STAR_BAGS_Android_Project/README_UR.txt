STAR BAGS Android Project — V4.5.4

یہ Source ورژن V4.5.3 کے لمبی رسید والے پرنٹ راستے کی مزید اصلاح کرتا ہے۔

اہم تبدیلیاں:
1) WebView کو پوری رسید کی انتہائی لمبی View بنا کر draw کرنے کے بجائے معمول کے viewport سائز پر رکھا جاتا ہے۔ HTML صفحہ window.scrollTo کے ذریعے 384 CSS-row حصوں میں آگے بڑھتا ہے، اور ہر visible حصے کو الگ 384-dot چوڑی PNG tile میں capture کیا جاتا ہے۔ اس سے WebView کی full-height drawing پر انحصار ختم ہوتا ہے، جو بعض Android WebView ورژنز میں خالی یا ادھورا نتیجہ دے سکتی ہے۔
2) ہر tile Preview اور Bluetooth پرنٹنگ دونوں میں استعمال ہوتا ہے؛ Preview خالی ہو تو پرنٹنگ شروع نہیں کی جاتی۔
3) Bluetooth پرنٹنگ 8-row GS v 0 bands میں ہے۔ 384-dot چوڑائی پر ہر band کا raster payload 384 bytes ہے، اور ہر band کے بعد flush اور 100ms وقفہ ہے۔
4) عام سیل بل کے اصل چار کالم (آئٹم، مقدار، فی عدد ریٹ، آئٹم ٹوٹل) اب print DOM میں حذف نہیں کیے جاتے۔ پڑتا بل کا اپنا تین کالم والا ڈیزائن برقرار ہے۔
5) بل کے اصل ریکارڈ، حساب، پارٹی ڈیٹا اور موبائل billing UI کو نہیں بدلا گیا۔

Build:
Android Studio میں اس فولڈر کو کھولیں، Gradle Sync کریں اور APK بنائیں۔ یہ Source ZIP ہے، APK نہیں۔

اہم: Android SDK/Gradle اور MPT-II hardware اس ماحول میں دستیاب نہیں تھے۔ اس لیے APK build، موبائل runtime، Preview اور حقیقی پرنٹر output کی تصدیق نہیں ہوئی۔ V4.5.4_LONG_RECEIPT_SCROLL_CAPTURE_TEST_REPORT_UR.txt میں چیک اور حدود درج ہیں۔
