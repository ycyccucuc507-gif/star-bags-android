STAR BAGS Android Project — V4.5.3

یہ ورژن V4.5.2 کے بعد لمبی رسید کی Preview rendering اور Bluetooth raster streaming میں تبدیلی کرتا ہے۔

اہم تبدیلیاں:
1) لمبی رسید کے لیے WebView.capturePicture() کی جگہ مکمل content height پر WebView کو layout کرکے clipped چھوٹے Bitmap tiles میں draw کیا جاتا ہے۔
2) ہر tile الگ عارضی PNG فائل میں محفوظ ہوتا ہے؛ Preview اور print دونوں انہی tiles کو استعمال کرتے ہیں۔
3) Receipt Bluetooth printing میں 8-row GS v 0 raster bands اور ہر band کے بعد 100ms وقفہ استعمال ہوتا ہے۔ 384-dot width پر فی band image payload 384 bytes ہے۔
4) اصل billing HTML اور حساب/پارٹی ڈیٹا کی ساخت کو اس تبدیلی میں جان بوجھ کر نہیں بدلا گیا۔

Build:
Android Studio میں اس فولڈر کو کھولیں اور Gradle sync/build کریں۔ اگر Android SDK/Gradle کی خرابی آئے تو پہلے SDK اور compatible Gradle environment درست کریں۔

اہم: یہ Source ZIP ہے، APK نہیں۔ MPT-II پر حقیقی پرنٹنگ ٹیسٹ درکار ہے۔ تفصیل کے لیے V4.5.3_LONG_RECEIPT_NEW_RENDERER_TEST_REPORT_UR.txt دیکھیں۔
