STAR BAGS Android Project — V4.5.5

یہ V4.5.4 کی فوری Compile Fix ریلیز ہے۔

اہم تبدیلی:
- MainActivity.java میں renderScale کی تعریف شامل کی گئی ہے: renderWidth / targetWidth۔
- یہی scale WebView کے physical-pixel viewport، CSS scroll coordinates اور tile bitmap capture کے درمیان conversion کے لیے استعمال ہوتا ہے۔
- اس سے V4.5.4 build log میں رپورٹ ہونے والی دونوں `cannot find symbol: renderScale` غلطیاں درست ہوتی ہیں۔
- versionCode 33 اور versionName 4.5.5-scroll-tile-preview-render-scale-fix کیا گیا ہے۔

باقی پرنٹنگ طریقہ V4.5.4 جیسا ہے: scroll-based WebView tile capture، ایک ہی tiles سے Preview اور Bluetooth raster printing، 8-row print bands اور 100ms pause۔

Build/ٹیسٹنگ کی حیثیت:
- Source میں متغیر کی تعریف اور اس کے استعمال کی جانچ کی گئی ہے۔
- اس runtime میں Android SDK/Gradle دستیاب نہیں، اس لیے مکمل APK build یہاں نہیں چلایا جا سکا۔
- MPT-II پر حقیقی پرنٹ ٹیسٹ نہیں ہوا۔
- اس لیے یہ صرف رپورٹ شدہ compile error کی اصلاح ہے؛ مکمل Preview/long receipt کامیابی کا دعویٰ نہیں۔
