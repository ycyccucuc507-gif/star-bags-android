STAR BAGS Android Project — V4.6.0 PDF Receipt Preview/Raster

اس ورژن میں صرف thermal receipt کے render/preview راستے کو تبدیل کیا گیا ہے۔ بل کے حساب، آئٹمز، مقدار، ریٹ، ادائیگی یا باقی رقم کے JavaScript/HTML حسابات میں تبدیلی نہیں کی گئی۔

اہم تکنیکی تبدیلیاں:
- پرانا hidden WebView scroll + view.draw(Canvas) tile capture راستہ اب استعمال نہیں ہوتا۔
- مکمل receipt WebView کے لیے Android WebView.createPrintDocumentAdapter() استعمال کیا گیا ہے تاکہ WebView کا مواد PDF stream میں تبدیل ہو۔
- receipt کی CSS پیمائش سے custom-width/custom-height PDF page attributes بنائے جاتے ہیں؛ مقصد 58mm پرنٹر کی مقررہ dot-width کے مطابق PDF کا تناسب برقرار رکھنا ہے۔
- PDF کو Android PdfRenderer سے 384-row کے چھوٹے bitmap strips میں rasterize کیا جاتا ہے؛ ایک بہت بڑا receipt bitmap نہیں بنایا جاتا۔
- Preview اور Bluetooth پرنٹنگ دونوں انہی PDF-derived strips کو استعمال کرتے ہیں۔
- PDF raster کے بعد بھی blank/near-white output کے لیے dark-pixel guard موجود ہے، تاکہ سفید رسید خاموشی سے پرنٹر کو نہ بھیجی جائے۔
- موجودہ 8-row ESC/POS raster band streaming اور Bluetooth chunking کا راستہ برقرار رکھا گیا ہے۔
- صرف MainActivity.java اور app/build.gradle تبدیل کیے گئے؛ index.html، bill calculations اور UI assets نہیں چھیڑے گئے۔

ورژن: versionCode 34, versionName 4.6.0-pdf-receipt-raster-preview

اہم تصدیقی حد:
- اس ماحول میں Android SDK/Gradle نصب نہیں تھا، اس لیے APK build یہاں نہیں چلایا جا سکا۔ javac سے صرف syntax-type errors کی تلاش کی گئی؛ Android SDK classes نہ ہونے کی وجہ سے مکمل Java compile ممکن نہیں تھا۔
- AndroidManifest.xml کی XML parsing کامیاب رہی اور ZIP integrity الگ سے چیک کی جائے گی۔
- اس سورس کو ابھی MPT-II پر جسمانی طور پر ٹیسٹ نہیں کیا گیا۔ PDF pipeline کا اصل نتیجہ آپ کے Android CI build اور پھر 5+ آئٹمز والے حقیقی بل پر verify کرنا ضروری ہے۔
- اس لیے اس ورژن کو PDF implementation candidate سمجھیں، guaranteed printer fix نہیں۔ اگر CI میں compile error آئے تو مکمل Build log کے ساتھ واپس بھیجیں؛ اور اگر Preview بنے تو پہلے Preview کے تمام آئٹمز دیکھیں، پھر ایک ٹیسٹ پرنٹ کریں۔


V4.6.1: PDF اب PdfDocument کے ذریعے براہ راست بنتی ہے؛ PrintDocumentAdapter callbacks کو app code میں instantiate نہیں کیا جاتا۔ مکمل-height WebView کو PDF canvas پر draw کر کے PdfRenderer سے preview/print tiles بنائے جاتے ہیں۔
