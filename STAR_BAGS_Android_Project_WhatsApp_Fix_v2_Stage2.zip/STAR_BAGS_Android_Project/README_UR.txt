STAR BAGS — Audited source package V2.1

اس اپ ڈیٹ میں V2.0 کے اصل Android project پر دو تصحیحات کی گئی ہیں:
1) کیٹلاگ کی فی آئٹم display settings اب اصل product storage key میں محفوظ ہوتی ہیں۔
2) بل کے ساتھ منسلک تصویر/PDF پر 3 MB کی مصنوعی app-level پابندی ہٹا دی گئی ہے۔ تصاویر JPEG میں resize/compress ہوتی ہیں؛ PDF اپنی اصل شکل میں محفوظ ہوتی ہے۔ فون کی RAM، دستیاب اسٹوریج اور WebView کی حدود پھر بھی لاگو رہتی ہیں۔

پروجیکٹ میں پہلے سے موجود خصوصیات: پارٹی Contacts picker، بل/WhatsApp sharing، پارٹی sort/delete confirmation، previous due transfer، reports/dashboard، product multi-image compression، backup/restore، local WhatsApp catalog اور local order register۔

اہم: یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور حقیقی فون ٹیسٹ دستیاب نہیں تھے، اس لیے اسے device-tested یا مکمل production-verified نہیں کہا جا سکتا۔ پہلے backup لیں، پرانی APK uninstall نہ کریں، اور GitHub Actions سے build کرکے APK install test کریں۔

بغیر سرور/ہوسٹنگ کے مستقل public web store، WhatsApp Business Catalog کی خودکار cloud sync، اور remote customer orders کی app میں خودکار push notification ممکن نہیں؛ اس ورژن میں local catalog + WhatsApp share + manual order entry ہے۔


نئی کیٹلاگ اپ ڈیٹ:
- مشترکہ دکھانے/چھپانے کی سیٹنگ کے لیے Apply to All۔
- ہر آئٹم کے لیے الگ نام، تفصیل، کیٹلاگ قیمت، کیٹلاگ اسٹاک اور دستیابی۔
- کیٹلاگ کی اپنی تبدیلیاں اصل بلنگ/انوینٹری کے ڈیٹا کو تبدیل نہیں کرتیں۔
- منتخب آئٹمز کی ڈیفالٹ حالت غیر منتخب ہے؛ ایک یا تمام آئٹمز منتخب کیے جا سکتے ہیں۔
- ہر منتخب پروڈکٹ کی تصویر کے اندر اسی پروڈکٹ کا نام/تفصیل/قیمت/اسٹاک کارڈ کی صورت میں شامل کیا جاتا ہے، تاکہ متعدد تصاویر شیئر ہونے پر شناخت واضح رہے۔
- کیٹلاگ کی انفرادی سیٹنگز مکمل بیک اپ اور ریسٹور میں بھی شامل ہیں۔

نوٹ: WhatsApp پر تصاویر کی وصولی/ترتیب WhatsApp اور فون کے شیئر مینو کے مطابق ہو سکتی ہے۔ اس ورژن کا Android APK ابھی حقیقی ڈیوائس پر ٹیسٹ ہونا باقی ہے۔


STAR BAGS V2.2 — Multi-image Online Catalog update
- یوٹیلٹی کے Online Store میں ہر پروڈکٹ کی متعدد تصاویر الگ گیلری کی صورت میں محفوظ رہتی ہیں۔
- ہر تصویر کے لیے الگ کیپشن لکھا، تصویر اوپر/نیچے کی جا سکتی، اور حذف کی جا سکتی ہے۔
- پیش منظر میں پچھلی/اگلی تصویر کے بٹن اور انگلی سے swipe دستیاب ہیں۔
- WhatsApp شیئرنگ میں ہر تصویر الگ کارڈ کے طور پر بنتی ہے؛ پہلی تصویر پر مکمل پروڈکٹ تفصیل/قیمت/اسٹاک اور باقی تصاویر پر متعلقہ کیپشن شامل ہوتا ہے۔
- گیلری، کیپشن اور کیٹلاگ کی الگ سیٹنگز مکمل بیک اپ میں شامل ہیں کیونکہ وہ store item overrides میں محفوظ ہیں۔
- ریکارڈ ریفریش اب کیٹلاگ اور مقامی آرڈر فہرست بھی دوبارہ render کرتا ہے۔

اہم حد: یہ مقامی/offline catalog ہے، عوامی ویب سائٹ یا live hosted store نہیں۔ WhatsApp پر متعدد تصاویر کا اصل ترتیب/کیپشن ہر فون اور WhatsApp ورژن کے share interface پر منحصر ہو سکتا ہے؛ اسی لیے ہر کارڈ پر متعلقہ کیپشن تصویر کے اندر بھی لکھا جاتا ہے۔

V2.4 — 11 نومبر اپ ڈیٹ:
- پارٹی کا سابقہ حساب Step 2 میں واضح۔
- پہلے فروخت شدہ بیگ کی واپسی، اصل پارٹی ریٹ خودکار، مقدار/ریٹ قابلِ ترمیم، بل سے منفی کریڈٹ۔
- فالٹ واپسی خراب اسٹاک میں الگ، قابلِ فروخت انوینٹری میں شامل نہیں۔
- بل تیار ہونے پر خودکار اسکرول۔
- آج کے کاروبار میں اخراجات اور خالص منافع۔
- ماہانہ رپورٹ، پارٹی وائز خریداری، مجموعی منافع، اخراجات اور خالص منافع۔
- رپورٹیں بٹن سے کھلتی/بند ہوتی ہیں۔
- Party Performance اسکور، چارٹ، تفصیلی جدول، تاریخ فلٹر اور بل/رسید drill-down۔
- موجودہ Season Planner اور reminder برقرار۔

یہ سورس ZIP ہے، APK نہیں۔ Gradle/Android SDK build اور حقیقی فون ٹیسٹ GitHub Actions/Android ڈیوائس پر ضروری ہیں۔


STAR BAGS V2.5 — صارف کی نئی درخواستیں
- واپسی کے آئٹم ڈراپ ڈاؤن میں موجودہ محفوظ پروڈکٹس کے ساتھ پرانے بلوں میں موجود نام بھی شامل؛ لسٹ صرف دو مخصوص اسکول بیگ تک محدود نہیں۔
- بل میں سابقہ بقایا کے فوراً بعد واپس آنے والے بیگوں کی تعداد اور منفی رقم دکھانے کی ترتیب۔
- واپسی لائن میں سپلائر کا نام اور اصل خرید قیمت درج کرنے کے خانے؛ بل اور انوینٹری کے الگ سپلائر واپسی خلاصے میں یاددہانی۔ یہ خودکار supplier payment/ledger نہیں ہے؛ سپلائر کو حقیقی ادائیگی الگ درج کرنا ہوگی۔
- Party Performance میں “کھولیں”/میٹرک کلک کے بعد تفصیلی ریکارڈ تک خودکار اسکرول؛ اصل بل کھولنے پر بل تک اسکرول۔
- بل تیار ہونے پر کاغذی بل (printableBill) تک خودکار اسکرول۔
- فری مقامی کاروباری اسسٹنٹ: آف لائن، API Key/انٹرنیٹ/کلاؤڈ کے بغیر، مقامی بل/پارٹی/اخراجات سے بنیادی حسابی جوابات۔ یہ مکمل جنریٹو LLM نہیں؛ سوالات کے محدود موضوعات پر مقامی rule-based جواب دیتا ہے۔ کوئی ڈیٹا بیرونی سروس کو نہیں بھیجا جاتا۔

اہم ٹیسٹنگ حد: JavaScript syntax اور ZIP integrity چیک کیے جا سکتے ہیں، مگر اس ماحول میں Android SDK/Gradle build اور حقیقی فون/WebView interaction ٹیسٹ دستیاب نہیں؛ GitHub Actions build اور فون پر مکمل ٹیسٹ لازمی ہیں۔


STAR BAGS V2.6 — Modern Organized UI (12 نومبر 2026):
- انوینٹری میں اسٹاک الرٹس/موجودہ اسٹاک اور ماخذ کے حساب سے اسٹاک اب بند ہونے والے جدید تفصیلی حصوں میں دکھائے جاتے ہیں۔
- انوینٹری کے اندر سے پرچیز/سپلائر حساب تک فوری بٹن دیا گیا ہے؛ اصل پرچیز ریکارڈ اور حساب کا موجودہ نظام برقرار ہے۔
- باقی ماڈیولز کے براہِ راست history panels کو کھلنے/بند ہونے والے کارڈز میں منظم کیا گیا ہے تاکہ صفحات غیر ضروری طور پر پھیلے ہوئے نہ ہوں۔
- سیزن پلانر میں روزانہ بدلنے والی آف لائن کاروباری ٹپ شامل ہے؛ یہ مقررہ رہنمائی ہے، live market forecast نہیں۔
- جدید کارڈ، بہتر اسپیسنگ، واضح ٹائپوگرافی، نرم شیڈوز اور جدید رنگوں کے ساتھ چارٹ/ٹیبل کی ظاہری شکل بہتر کی گئی ہے۔
- 58mm پرنٹ CSS اور Android Print dialog والا موجودہ طریقہ برقرار ہے؛ عام WebView HTML سے Classic Bluetooth SPP پرنٹر کو براہِ راست کنٹرول کرنے کی ضمانت نہیں۔ اصل پرنٹر ماڈل اور حقیقی ٹیسٹ درکار ہے۔
- یہ source ZIP ہے، APK نہیں۔ JavaScript syntax، HTML IDs، XML اور ZIP integrity کی جانچ کی گئی؛ Android Gradle build اور حقیقی موبائل/پرنٹر ٹیسٹ اس ماحول میں نہیں کیے گئے۔


STAR BAGS V2.7 — Raw Bluetooth Thermal Printer
- یوٹیلٹی میں Native Classic Bluetooth SPP پرنٹر سیٹنگ شامل کی گئی۔
- موبائل میں پہلے سے Pair شدہ Bluetooth ڈیوائسز ایپ کے اندر دکھائی جاتی ہیں؛ MPT-II نام والے پرنٹر کو خودکار ترجیح دی جاتی ہے۔
- Android 12+ پر Bluetooth Connect کی runtime permission درکار ہے۔
- Connect بٹن RFCOMM SPP UUID کے ذریعے پرنٹر سے کنکشن قائم کرتا ہے۔
- ٹیسٹ پرنٹ ESC/POS initialize اور text commands بھیجتا ہے؛ رسید پر STAR BAGS، “It is work” اور MPT-II Bluetooth Test پرنٹ ہوتا ہے۔
- پرنٹر کا Pair ہونا ضروری ہے؛ اگر MPT-II فہرست میں نہ آئے تو پہلے Android Settings → Bluetooth سے Pair کریں۔
- اس مرحلے میں Bluetooth کنکشن اور ٹیسٹ رسید شامل ہے؛ موجودہ بل پرنٹ بٹن ابھی Android Print dialog استعمال کرتا ہے۔ اگلے مرحلے میں بل کو بھی Raw Bluetooth ESC/POS پر منتقل کرنا ہوگا۔
- یہ سورس ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور حقیقی MPT-II پرنٹر ٹیسٹ دستیاب نہیں؛ GitHub Actions build اور حقیقی ڈیوائس پر Connect/Test لازمی ہے۔


STAR BAGS V2.8 — اصل بل کی Raw Bluetooth پرنٹنگ:
- پہلے صفحے کے اصل "بل پرنٹ کریں" بٹن کو Native Bluetooth SPP / ESC-POS پرنٹنگ سے جوڑا گیا ہے۔
- موجودہ بل Preview کے HTML کو Android WebView میں رسید کی تصویر (raster) میں تبدیل کرکے MPT-II پرنٹر پر بھیجا جاتا ہے، تاکہ اردو/تصاویر سمیت پرنٹنگ کی کوشش ہو۔
- 58mm (384 dots) اور 80mm (576 dots) راسٹر چوڑائی استعمال ہوتی ہے۔
- محفوظ شدہ پرنٹر کنکشن دوبارہ استعمال ہوتا ہے؛ اگر محفوظ کنکشن نہ ہو تو Paired MPT-II تلاش کیا جاتا ہے۔
- Android 12+ پر BLUETOOTH_CONNECT کی runtime اجازت درکار ہے۔ اجازت دینے کے بعد دوبارہ Print Bill دبائیں۔ اگر MPT-II Pair نہیں تو پہلے Android Bluetooth Settings میں Pair کریں۔
- یہ سورس ZIP ہے، APK نہیں۔ Android Gradle build اور حقیقی MPT-II پرنٹر پر اردو، لوگو، پیپر کٹنگ اور رسید کی لمبائی کی لازمی جانچ باقی ہے۔


V2.8.1 — Java compile fix:
- StarBagsBridge کے اندر outer Activity کے one-argument connectThermalPrinter method کو واضح طور پر MainActivity.this کے ذریعے کال کیا گیا ہے، تاکہ Java overload/name-shadowing compilation error ختم ہو۔


STAR BAGS V2.9 — Bill Preview + MPT-II raster rendering fix:
- پہلے صفحے کے Print Bill بٹن پر الگ بل Preview modal دکھایا جاتا ہے؛ صارف Preview دیکھ کر Print Bill کی تصدیق کرتا ہے۔
- Thermal raster کے لیے WebView کو عارضی طور پر Android view tree میں attach کرکے software rendering کے ساتھ draw کیا جاتا ہے؛ detached WebView کے blank bitmap مسئلے سے بچاؤ۔
- اصل printableBill element کا outerHTML پرنٹ pipeline کو بھیجا جاتا ہے۔
- خالی bitmap کی شناخت ہونے پر پرنٹر کو خالی پیج نہیں بھیجا جاتا اور واضح error دکھائی جاتی ہے۔
- 58mm/80mm کے موجودہ اختیارات برقرار ہیں۔ حقیقی MPT-II پر اردو/لوگو/رسید کی لمبائی کا ٹیسٹ ابھی صارف کے فون پر ضروری ہے۔


STAR BAGS V3.0 — Full bill raster rendering correction:
- MPT-II receipt rendering now uses a density-aware WebView viewport: CSS layout is created at the intended 384/576 CSS-pixel paper width, rendered at device density, then downsampled to exactly 384/576 printer dots.
- Added explicit receipt styles for the complete bill: logo/header, party, all four item columns, totals, payment/balance summary and thank-you footer.
- Waits for embedded logo/images before capture and measures the full document height before rasterizing.
- Keeps the existing Preview modal and Print Bill confirmation flow.
- This source ZIP has not been built by Android Gradle or physically tested on an MPT-II device in this environment. Verify with a GitHub Actions build and one real receipt before replacing production.

V3.1 — WebView receipt-height fix:
- Removed Promise return from evaluateJavascript height measurement. Android's evaluateJavascript callback does not await Promises; this caused the height value to be non-numeric and triggered the false "height not valid" error.
- Height is now returned synchronously as a numeric DOM measurement after a longer image/layout settling delay.
- The original full receipt HTML, inline logo, item table, party name and payment summary remain the print source.

V3.2 — Larger, clearer thermal receipt:
- Kept the exact thermal print dot width (targetWidth) unchanged for the selected paper size.
- Increased receipt typography, table cell padding, line spacing, banner/logo size, and payment-summary spacing to improve readability.
- The receipt grows vertically as text wraps within the same fixed paper width.
- Printing remains a monochrome bitmap/raster receipt.


V3.3 — Pertah print preview and share:
- Added a dedicated boxed, monochrome receipt preview for the Pertah costing feature.
- Preview has no STAR BAGS logo or branding, as requested.
- Print sends the exact preview HTML through the existing MPT-II thermal bitmap printer bridge and selected paper width.
- Share generates a boxed PNG receipt and uses the existing Android image-sharing bridge, with browser fallback.
- Existing sales bill print implementation is untouched.

V3.4 — MPT-II مکمل رسید Bluetooth transmission fix:
- لمبی رسید کے raster data کو چھوٹے 128-row bands میں بھیجا جاتا ہے۔
- ہر band کا payload 512-byte Bluetooth writes میں تقسیم، flush اور مختصر pacing کے ساتھ بھیجا جاتا ہے تاکہ بعض MPT-II firmware میں بڑے RFCOMM writes کے آخری حصے کے ضائع ہونے کا امکان کم ہو۔
- یہ تبدیلی عام سیلز بل اور پڑتا بل دونوں کے مشترکہ native thermal print pipeline پر لاگو ہے؛ preview/layout اور محفوظ کاروباری ڈیٹا تبدیل نہیں کیے گئے۔
- ZIP source package ہے، APK نہیں۔ Android Gradle build اور اصل MPT-II پرنٹر پر پوری رسید (بالخصوص آخری Grand Total) کی physical verification لازمی ہے؛ اس ماحول میں حقیقی پرنٹر ٹیسٹ ممکن نہیں تھا۔


V3.5 پرنٹنگ اصلاح: بل کے اصل Preview کی 2X تحریر، کالموں کی چوڑائی، باکس/بارڈر اور تین یا چار کالم والی ٹیبل کی ترتیب برقرار رکھی گئی ہے۔ پڑتا بل کے تین کالموں پر چار کالم والی زبردستی CSS لاگو نہیں ہوگی۔ طویل بل کی تصویر کو خاموشی سے کاٹنے کے بجائے حد سے زیادہ لمبا ہونے پر واضح پیغام دیا جائے گا۔ اصل MPT-II پرنٹر پر ٹیسٹ لازمی کریں۔
