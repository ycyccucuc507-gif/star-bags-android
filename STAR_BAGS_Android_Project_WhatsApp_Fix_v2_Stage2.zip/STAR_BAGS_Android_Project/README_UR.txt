STAR BAGS — Audited source package V2.1

اس اپ ڈیٹ میں V2.0 کے اصل Android project پر دو تصحیحات کی گئی ہیں:
1) کیٹلاگ کی فی آئٹم display settings اب اصل product storage key میں محفوظ ہوتی ہیں۔
2) بل کے ساتھ منسلک تصویر/PDF پر 3 MB کی مصنوعی app-level پابندی ہٹا دی گئی ہے۔ تصاویر JPEG میں resize/compress ہوتی ہیں؛ PDF اپنی اصل شکل میں محفوظ ہوتی ہے۔ فون کی RAM، دستیاب اسٹوریج اور WebView کی حدود پھر بھی لاگو رہتی ہیں۔

پروجیکٹ میں پہلے سے موجود خصوصیات: پارٹی Contacts picker، بل/WhatsApp sharing، پارٹی sort/delete confirmation، previous due transfer، reports/dashboard، product multi-image compression، backup/restore، local WhatsApp catalog اور local order register۔

اہم: یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور حقیقی فون ٹیسٹ دستیاب نہیں تھے، اس لیے اسے device-tested یا مکمل production-verified نہیں کہا جا سکتا۔ پہلے backup لیں، پرانی APK uninstall نہ کریں، اور GitHub Actions سے build کرکے APK install test کریں۔

بغیر سرور/ہوسٹنگ کے مستقل public web store، WhatsApp Business Catalog کی خودکار cloud sync، اور remote customer orders کی app میں خودکار push notification ممکن نہیں؛ اس ورژن میں local catalog + WhatsApp share + manual order entry ہے۔


نئی کیٹلاگ اپ ڈیٹ:
- مشترکہ دکھانے/چھپانے کی سیٹنگ کے لیے Apply to All۔
- ہر آئٹم کے لیے الگ نام، تفصیل، کیٹلاگ قیمت، کیٹلاگ اسٹاک اور دستیابی۔
- کیٹلاگ کی اپنی تبدیلیاں اصل بلنگ/انوینٹری کے ڈیٹا کو تبدیل نہیں کرتیں۔
- منتخب آئٹمز کی ڈیفالٹ حالت غیر منتخب ہے؛ ایک یا تمام آئٹمز منتخب کیے جا سکتے ہیں۔
- ہر منتخب پروڈکٹ کی تصویر کے اندر اسی پروڈکٹ کا نام/تفصیل/قیمت/اسٹاک کارڈ کی صورت میں شامل کیا جاتا ہے، تاکہ متعدد تصاویر شیئر ہونے پر شناخت واضح رہے۔
- کیٹلاگ کی انفرادی سیٹنگز مکمل بیک اپ اور ریسٹور میں بھی شامل ہیں۔

نوٹ: WhatsApp پر تصاویر کی وصولی/ترتیب WhatsApp اور فون کے شیئر مینو کے مطابق ہو سکتی ہے۔ اس ورژن کا Android APK ابھی حقیقی ڈیوائس پر ٹیسٹ ہونا باقی ہے۔


STAR BAGS V2.2 — Multi-image Online Catalog update
- یوٹیلٹی کے Online Store میں ہر پروڈکٹ کی متعدد تصاویر الگ گیلری کی صورت میں محفوظ رہتی ہیں۔
- ہر تصویر کے لیے الگ کیپشن لکھا، تصویر اوپر/نیچے کی جا سکتی، اور حذف کی جا سکتی ہے۔
- پیش منظر میں پچھلی/اگلی تصویر کے بٹن اور انگلی سے swipe دستیاب ہیں۔
- WhatsApp شیئرنگ میں ہر تصویر الگ کارڈ کے طور پر بنتی ہے؛ پہلی تصویر پر مکمل پروڈکٹ تفصیل/قیمت/اسٹاک اور باقی تصاویر پر متعلقہ کیپشن شامل ہوتا ہے۔
- گیلری، کیپشن اور کیٹلاگ کی الگ سیٹنگز مکمل بیک اپ میں شامل ہیں کیونکہ وہ store item overrides میں محفوظ ہیں۔
- ریکارڈ ریفریش اب کیٹلاگ اور مقامی آرڈر فہرست بھی دوبارہ render کرتا ہے۔

اہم حد: یہ مقامی/offline catalog ہے، عوامی ویب سائٹ یا live hosted store نہیں۔ WhatsApp پر متعدد تصاویر کا اصل ترتیب/کیپشن ہر فون اور WhatsApp ورژن کے share interface پر منحصر ہو سکتا ہے؛ اسی لیے ہر کارڈ پر متعلقہ کیپشن تصویر کے اندر بھی لکھا جاتا ہے۔

V2.4 — 11 نومبر اپ ڈیٹ:
- پارٹی کا سابقہ حساب Step 2 میں واضح۔
- پہلے فروخت شدہ بیگ کی واپسی، اصل پارٹی ریٹ خودکار، مقدار/ریٹ قابلِ ترمیم، بل سے منفی کریڈٹ۔
- فالٹ واپسی خراب اسٹاک میں الگ، قابلِ فروخت انوینٹری میں شامل نہیں۔
- بل تیار ہونے پر خودکار اسکرول۔
- آج کے کاروبار میں اخراجات اور خالص منافع۔
- ماہانہ رپورٹ، پارٹی وائز خریداری، مجموعی منافع، اخراجات اور خالص منافع۔
- رپورٹیں بٹن سے کھلتی/بند ہوتی ہیں۔
- Party Performance اسکور، چارٹ، تفصیلی جدول، تاریخ فلٹر اور بل/رسید drill-down۔
- موجودہ Season Planner اور reminder برقرار۔

یہ سورس ZIP ہے، APK نہیں۔ Gradle/Android SDK build اور حقیقی فون ٹیسٹ GitHub Actions/Android ڈیوائس پر ضروری ہیں۔


STAR BAGS V2.5 — صارف کی نئی درخواستیں
- واپسی کے آئٹم ڈراپ ڈاؤن میں موجودہ محفوظ پروڈکٹس کے ساتھ پرانے بلوں میں موجود نام بھی شامل؛ لسٹ صرف دو مخصوص اسکول بیگ تک محدود نہیں۔
- بل میں سابقہ بقایا کے فوراً بعد واپس آنے والے بیگوں کی تعداد اور منفی رقم دکھانے کی ترتیب۔
- واپسی لائن میں سپلائر کا نام اور اصل خرید قیمت درج کرنے کے خانے؛ بل اور انوینٹری کے الگ سپلائر واپسی خلاصے میں یاددہانی۔ یہ خودکار supplier payment/ledger نہیں ہے؛ سپلائر کو حقیقی ادائیگی الگ درج کرنا ہوگی۔
- Party Performance میں “کھولیں”/میٹرک کلک کے بعد تفصیلی ریکارڈ تک خودکار اسکرول؛ اصل بل کھولنے پر بل تک اسکرول۔
- بل تیار ہونے پر کاغذی بل (printableBill) تک خودکار اسکرول۔
- فری مقامی کاروباری اسسٹنٹ: آف لائن، API Key/انٹرنیٹ/کلاؤڈ کے بغیر، مقامی بل/پارٹی/اخراجات سے بنیادی حسابی جوابات۔ یہ مکمل جنریٹو LLM نہیں؛ سوالات کے محدود موضوعات پر مقامی rule-based جواب دیتا ہے۔ کوئی ڈیٹا بیرونی سروس کو نہیں بھیجا جاتا۔

اہم ٹیسٹنگ حد: JavaScript syntax اور ZIP integrity چیک کیے جا سکتے ہیں، مگر اس ماحول میں Android SDK/Gradle build اور حقیقی فون/WebView interaction ٹیسٹ دستیاب نہیں؛ GitHub Actions build اور فون پر مکمل ٹیسٹ لازمی ہیں۔


STAR BAGS V2.6 — Modern Organized UI (12 نومبر 2026):
- انوینٹری میں اسٹاک الرٹس/موجودہ اسٹاک اور ماخذ کے حساب سے اسٹاک اب بند ہونے والے جدید تفصیلی حصوں میں دکھائے جاتے ہیں۔
- انوینٹری کے اندر سے پرچیز/سپلائر حساب تک فوری بٹن دیا گیا ہے؛ اصل پرچیز ریکارڈ اور حساب کا موجودہ نظام برقرار ہے۔
- باقی ماڈیولز کے براہِ راست history panels کو کھلنے/بند ہونے والے کارڈز میں منظم کیا گیا ہے تاکہ صفحات غیر ضروری طور پر پھیلے ہوئے نہ ہوں۔
- سیزن پلانر میں روزانہ بدلنے والی آف لائن کاروباری ٹپ شامل ہے؛ یہ مقررہ رہنمائی ہے، live market forecast نہیں۔
- جدید کارڈ، بہتر اسپیسنگ، واضح ٹائپوگرافی، نرم شیڈوز اور جدید رنگوں کے ساتھ چارٹ/ٹیبل کی ظاہری شکل بہتر کی گئی ہے۔
- 58mm پرنٹ CSS اور Android Print dialog والا موجودہ طریقہ برقرار ہے؛ عام WebView HTML سے Classic Bluetooth SPP پرنٹر کو براہِ راست کنٹرول کرنے کی ضمانت نہیں۔ اصل پرنٹر ماڈل اور حقیقی ٹیسٹ درکار ہے۔
- یہ source ZIP ہے، APK نہیں۔ JavaScript syntax، HTML IDs، XML اور ZIP integrity کی جانچ کی گئی؛ Android Gradle build اور حقیقی موبائل/پرنٹر ٹیسٹ اس ماحول میں نہیں کیے گئے۔


STAR BAGS V2.7 — Raw Bluetooth Thermal Printer
- یوٹیلٹی میں Native Classic Bluetooth SPP پرنٹر سیٹنگ شامل کی گئی۔
- موبائل میں پہلے سے Pair شدہ Bluetooth ڈیوائسز ایپ کے اندر دکھائی جاتی ہیں؛ MPT-II نام والے پرنٹر کو خودکار ترجیح دی جاتی ہے۔
- Android 12+ پر Bluetooth Connect کی runtime permission درکار ہے۔
- Connect بٹن RFCOMM SPP UUID کے ذریعے پرنٹر سے کنکشن قائم کرتا ہے۔
- ٹیسٹ پرنٹ ESC/POS initialize اور text commands بھیجتا ہے؛ رسید پر STAR BAGS، “It is work” اور MPT-II Bluetooth Test پرنٹ ہوتا ہے۔
- پرنٹر کا Pair ہونا ضروری ہے؛ اگر MPT-II فہرست میں نہ آئے تو پہلے Android Settings → Bluetooth سے Pair کریں۔
- اس مرحلے میں Bluetooth کنکشن اور ٹیسٹ رسید شامل ہے؛ موجودہ بل پرنٹ بٹن ابھی Android Print dialog استعمال کرتا ہے۔ اگلے مرحلے میں بل کو بھی Raw Bluetooth ESC/POS پر منتقل کرنا ہوگا۔
- یہ سورس ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور حقیقی MPT-II پرنٹر ٹیسٹ دستیاب نہیں؛ GitHub Actions build اور حقیقی ڈیوائس پر Connect/Test لازمی ہے۔


STAR BAGS V2.8 — اصل بل کی Raw Bluetooth پرنٹنگ:
- پہلے صفحے کے اصل "بل پرنٹ کریں" بٹن کو Native Bluetooth SPP / ESC-POS پرنٹنگ سے جوڑا گیا ہے۔
- موجودہ بل Preview کے HTML کو Android WebView میں رسید کی تصویر (raster) میں تبدیل کرکے MPT-II پرنٹر پر بھیجا جاتا ہے، تاکہ اردو/تصاویر سمیت پرنٹنگ کی کوشش ہو۔
- 58mm (384 dots) اور 80mm (576 dots) راسٹر چوڑائی استعمال ہوتی ہے۔
- محفوظ شدہ پرنٹر کنکشن دوبارہ استعمال ہوتا ہے؛ اگر محفوظ کنکشن نہ ہو تو Paired MPT-II تلاش کیا جاتا ہے۔
- Android 12+ پر BLUETOOTH_CONNECT کی runtime اجازت درکار ہے۔ اجازت دینے کے بعد دوبارہ Print Bill دبائیں۔ اگر MPT-II Pair نہیں تو پہلے Android Bluetooth Settings میں Pair کریں۔
- یہ سورس ZIP ہے، APK نہیں۔ Android Gradle build اور حقیقی MPT-II پرنٹر پر اردو، لوگو، پیپر کٹنگ اور رسید کی لمبائی کی لازمی جانچ باقی ہے۔


V2.8.1 — Java compile fix:
- StarBagsBridge کے اندر outer Activity کے one-argument connectThermalPrinter method کو واضح طور پر MainActivity.this کے ذریعے کال کیا گیا ہے، تاکہ Java overload/name-shadowing compilation error ختم ہو۔


STAR BAGS V2.9 — Bill Preview + MPT-II raster rendering fix:
- پہلے صفحے کے Print Bill بٹن پر الگ بل Preview modal دکھایا جاتا ہے؛ صارف Preview دیکھ کر Print Bill کی تصدیق کرتا ہے۔
- Thermal raster کے لیے WebView کو عارضی طور پر Android view tree میں attach کرکے software rendering کے ساتھ draw کیا جاتا ہے؛ detached WebView کے blank bitmap مسئلے سے بچاؤ۔
- اصل printableBill element کا outerHTML پرنٹ pipeline کو بھیجا جاتا ہے۔
- خالی bitmap کی شناخت ہونے پر پرنٹر کو خالی پیج نہیں بھیجا جاتا اور واضح error دکھائی جاتی ہے۔
- 58mm/80mm کے موجودہ اختیارات برقرار ہیں۔ حقیقی MPT-II پر اردو/لوگو/رسید کی لمبائی کا ٹیسٹ ابھی صارف کے فون پر ضروری ہے۔


STAR BAGS V3.0 — Full bill raster rendering correction:
- MPT-II receipt rendering now uses a density-aware WebView viewport: CSS layout is created at the intended 384/576 CSS-pixel paper width, rendered at device density, then downsampled to exactly 384/576 printer dots.
- Added explicit receipt styles for the complete bill: logo/header, party, all four item columns, totals, payment/balance summary and thank-you footer.
- Waits for embedded logo/images before capture and measures the full document height before rasterizing.
- Keeps the existing Preview modal and Print Bill confirmation flow.
- This source ZIP has not been built by Android Gradle or physically tested on an MPT-II device in this environment. Verify with a GitHub Actions build and one real receipt before replacing production.

V3.1 — WebView receipt-height fix:
- Removed Promise return from evaluateJavascript height measurement. Android's evaluateJavascript callback does not await Promises; this caused the height value to be non-numeric and triggered the false "height not valid" error.
- Height is now returned synchronously as a numeric DOM measurement after a longer image/layout settling delay.
- The original full receipt HTML, inline logo, item table, party name and payment summary remain the print source.

V3.2 — Larger, clearer thermal receipt:
- Kept the exact thermal print dot width (targetWidth) unchanged for the selected paper size.
- Increased receipt typography, table cell padding, line spacing, banner/logo size, and payment-summary spacing to improve readability.
- The receipt grows vertically as text wraps within the same fixed paper width.
- Printing remains a monochrome bitmap/raster receipt.


V3.3 — Pertah print preview and share:
- Added a dedicated boxed, monochrome receipt preview for the Pertah costing feature.
- Preview has no STAR BAGS logo or branding, as requested.
- Print sends the exact preview HTML through the existing MPT-II thermal bitmap printer bridge and selected paper width.
- Share generates a boxed PNG receipt and uses the existing Android image-sharing bridge, with browser fallback.
- Existing sales bill print implementation is untouched.

V3.4 — MPT-II مکمل رسید Bluetooth transmission fix:
- لمبی رسید کے raster data کو چھوٹے 128-row bands میں بھیجا جاتا ہے۔
- ہر band کا payload 512-byte Bluetooth writes میں تقسیم، flush اور مختصر pacing کے ساتھ بھیجا جاتا ہے تاکہ بعض MPT-II firmware میں بڑے RFCOMM writes کے آخری حصے کے ضائع ہونے کا امکان کم ہو۔
- یہ تبدیلی عام سیلز بل اور پڑتا بل دونوں کے مشترکہ native thermal print pipeline پر لاگو ہے؛ preview/layout اور محفوظ کاروباری ڈیٹا تبدیل نہیں کیے گئے۔
- ZIP source package ہے، APK نہیں۔ Android Gradle build اور اصل MPT-II پرنٹر پر پوری رسید (بالخصوص آخری Grand Total) کی physical verification لازمی ہے؛ اس ماحول میں حقیقی پرنٹر ٹیسٹ ممکن نہیں تھا۔


V3.5 پرنٹنگ اصلاح: بل کے اصل Preview کی 2X تحریر، کالموں کی چوڑائی، باکس/بارڈر اور تین یا چار کالم والی ٹیبل کی ترتیب برقرار رکھی گئی ہے۔ پڑتا بل کے تین کالموں پر چار کالم والی زبردستی CSS لاگو نہیں ہوگی۔ طویل بل کی تصویر کو خاموشی سے کاٹنے کے بجائے حد سے زیادہ لمبا ہونے پر واضح پیغام دیا جائے گا۔ اصل MPT-II پرنٹر پر ٹیسٹ لازمی کریں۔


STAR BAGS V3.6 — پڑتا بل مکمل پرنٹ استحکام (16 نومبر 2026):
- V3.5 کے اصل Android/HTML سورس، ڈیٹا اسٹوریج، سیلز بل اور دیگر ماڈیولز برقرار رکھے گئے ہیں۔
- پڑتا بل کا موجودہ تین کالم والا باکس ڈیزائن، Preview HTML، 2X فونٹ اور باکس بارڈرز تبدیل نہیں کیے گئے۔
- پڑتا اور سیلز بل کے مشترکہ Bluetooth raster sender میں MPT-II مطابقت کے لیے raster bands 128 سے 64 rows اور Bluetooth data chunks 512 سے 256 bytes کیے گئے؛ packet اور band کے درمیان وقفہ بڑھایا گیا تاکہ طویل رسید کے آخری حصے کے ضائع ہونے کا امکان کم ہو۔
- WebView receipt height measurement میں document اور printable element کی اضافی bounds شامل کی گئیں۔
- Android versionCode 19 اور versionName 3.6-pertah-full-print مقرر کیا گیا۔
- اہم: 40,000 CSS px حفاظتی حد ابھی برقرار ہے تاکہ انتہائی طویل رسید پر فون کی میموری ختم نہ ہو۔ 50/100 آئٹمز کی کامیابی اصل مواد، فون اور WebView میموری پر منحصر ہے۔
- یہ Android Studio source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build یا حقیقی MPT-II پرنٹر دستیاب نہیں؛ اس لیے physical print کامیابی کی تصدیق نہیں کی گئی۔ پہلے 10، پھر 50 اور پھر 100 آئٹمز کے ساتھ پرنٹر پر ٹیسٹ کریں۔


V3.7 ترمیمات (V3.6 کی بنیاد پر):
- تھرمل بل کے لوگو اور ہیڈر کا سائز نارمل کیا گیا؛ بل کی تفصیلات/آئٹم ٹیکسٹ کم نہیں کیا گیا۔
- MPT-II کے لیے Raster ڈیٹا چھوٹے 32-row بینڈز اور 128-byte Bluetooth writes میں بھیجا جاتا ہے، درمیان میں زیادہ وقفہ رکھا گیا ہے تاکہ طویل رسید کے ڈیٹا کے ضائع ہونے کا امکان کم ہو۔
- Android پر حقیقی MPT-II پرنٹ ٹیسٹ ضروری ہے؛ صرف ZIP سے پرنٹنگ کی کامیابی ثابت نہیں ہوتی۔


STAR BAGS V3.8 — Long Pertah Thermal Print (source update):
- اپلوڈ شدہ ZIP میں README پر V3.7 کا ذکر تھا، مگر Java/Gradle سورس میں پرانے 32-row bands، 128-byte writes، 76×48 logo، 40,000 CSS px guard اور version 3.6/versionCode 19 موجود تھے۔ V3.8 میں انہی اصل فائلوں کو درست کیا گیا؛ صرف README کی بنیاد پر V3.7 code ہونے کا دعویٰ نہیں کیا گیا۔
- MPT-II raster transfer اب 128-row bands، زیادہ سے زیادہ 4096-byte writes، ہر band کے بعد flush اور تقریباً 90ms وقفہ استعمال کرتا ہے۔ یہ configuration ممکنہ compatibility بہتری ہے؛ اصل پرنٹر پر کامیابی ثابت نہیں۔
- Thermal rendering میں 12,000 CSS px سے زیادہ height کو خاموشی سے truncate کرنے کے بجائے واضح error دیا جاتا ہے۔ final printer-width bitmap براہِ راست بنایا جاتا ہے تاکہ طویل بل کے لیے density-sized full-height intermediate bitmap کی غیر ضروری memory cost کم ہو۔
- Sales thermal header کا logo 54×34 px رکھا گیا ہے۔ Pertah کا موجودہ تین کالم، باکسز، ترتیب، فونٹ سائز اور HTML bill design تبدیل نہیں کیا گیا؛ sales bill اور Pertah bill کے ڈیزائن الگ ہیں۔
- Raster conversion میں row-wise pixel processing استعمال ہوتی ہے۔ Preview کا اصل Pertah printable HTML ہی print bridge کو بھیجا جاتا ہے۔
- versionCode 20 اور versionName 3.8-pertah-long-print مقرر ہیں۔
- یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور MPT-II physical printing دستیاب نہیں؛ اس لیے کوئی physical print test کامیاب قرار نہیں دیا گیا۔ 5/20/50+ آئٹمز اور 9/10/12 انچ کے الگ الگ ٹیسٹ، آخری آئٹم/Grand Total، اردو readability، Preview-vs-print اور حقیقی MPT-II verification ابھی باقی ہیں۔


STAR BAGS V3.9 — پڑتا بل اور تصویر کی Raw Bluetooth پرنٹنگ (16 نومبر 2026):
- پرنٹر سیٹنگ میں “تصویر منتخب کریں اور پرنٹ کریں” کا نیا آپشن شامل کیا گیا ہے۔ Android Documents picker سے Gallery، Files یا دستیاب WhatsApp images میں سے JPG/PNG منتخب کی جا سکتی ہے۔
- منتخب تصویر کو 58mm (384 dots) یا 80mm (576 dots) کی پرنٹر چوڑائی پر برقرار aspect ratio کے ساتھ fit کیا جاتا ہے؛ 20,000 dots سے زیادہ لمبی تصویر پر واضح پیغام کے ساتھ پرنٹ روکا جاتا ہے، خاموشی سے crop نہیں کیا جاتا۔
- Raster ڈیٹا اب پورے بل کے لیے ایک بڑے byte array میں جمع نہیں ہوتا؛ 128-row bands الگ تیار ہوتے ہیں، ہر band میں زیادہ سے زیادہ 4096-byte writes، flush اور تقریباً 90ms وقفہ رکھا گیا ہے۔
- پڑتا بل کا موجودہ تین کالم والا ڈیزائن، باکسز، ترتیب اور سیلز بل سے علیحدہ layout برقرار رکھا گیا ہے۔
- یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build اور MPT-II پر حقیقی پرنٹ ٹیسٹ نہیں ہوئے۔ JPG/PNG image picker، 5/20/50+ پڑتا آئٹمز، 9/10/12 انچ، آخری آئٹم/Grand Total، اردو وضاحت اور اصل پرنٹر پر مکمل رسید کی جانچ ابھی لازمی ہے۔ “ڈیٹا بھیج دیا گیا” کا مطلب پرنٹر نے مکمل پرنٹ کر دیا، اس کی ضمانت نہیں۔


STAR BAGS V4.0 — 16 نومبر 2026 (Source update / unbuilt)
- versionCode: 22
- versionName: 4.0-58mm-full-length-image-print
- V3.9 audit: MainActivity.java میں Pertah HTML → WebView raster pipeline، 128-row ESC/POS raster bands، 4096-byte output chunks، per-band flush اور 90ms pause پہلے سے موجود تھے۔
- V3.9 audit: 12,000 CSS-pixel Pertah receipt guard اور 20,000-dot raster/image guard حقیقی software limits تھے؛ V4.0 میں یہ مقررہ height guards ہٹا دیے گئے ہیں۔ Android Bitmap allocation، فون RAM، WebView/View limits اور پرنٹر firmware/buffer کی حقیقی حدود اب بھی لاگو ہیں؛ بہت بڑی رسید پر memory/platform failure ممکن ہے۔
- Raster logging: ہر band کے y-range، rows، payload bytes اور cumulative bytes کے لیے STAR_BAGS_PRINT Logcat entries شامل ہیں۔
- Print Image: ACTION_OPEN_DOCUMENT image/* chooser برقرار ہے؛ Gallery/Files/WhatsApp میں محفوظ اور DocumentsUI کے ذریعے نظر آنے والی تصاویر منتخب ہو سکتی ہیں۔ پرنٹ سے پہلے native scrollable image preview اور confirmation شامل ہے؛ پرنٹنگ مشترکہ ESC/POS raster sender سے ہوتی ہے۔
- موجودہ تین کالم والا Pertah HTML ڈیزائن، sales bill markup، billing/storage logic اور باقی app features کو دانستہ تبدیل نہیں کیا گیا۔
- اہم غیر تصدیق شدہ مفروضہ: 58mm کوڈ mapping اب بھی 384 dots اور 80mm کو 576 dots استعمال کرتی ہے۔ MPT-II کے اس مخصوص یونٹ کی اصل DPI/printable dot width source ZIP سے معلوم نہیں ہو سکتی؛ پرنٹر کے manual/diagnostic یا حقیقی test print سے تصدیق ضروری ہے۔ 58mm رول کی nominal چوڑائی printable head width کے برابر نہیں ہوتی۔
- اس source-only environment میں Android SDK، Gradle executable/wrapper اور حقیقی MPT-II hardware دستیاب نہیں تھے۔ لہٰذا Gradle build، APK، Bluetooth transmission، paper output، Urdu clarity اور مکمل لمبائی کے hardware tests انجام نہیں دیے گئے۔ ان کو کامیاب نہ سمجھا جائے۔
- V4.0 ZIP میں اصل V3.9 project کا مکمل source ہے؛ تبدیلی سے پہلے V3.9 backup الگ محفوظ کیا گیا ہے۔

V4.0 2X PRINT UPDATE:
- Thermal Sales/Pertah bill typography, table spacing, logo and totals enlarged for clearer reading while keeping selected paper width fixed.
- Choose Image thermal output keeps selected paper width and doubles the printed image height (vertical enlargement). Very large images remain subject to Android Bitmap memory/device limits.


============================================================
STAR BAGS V4.0 — 17 نومبر 2026 — Thermal Print + Bluetooth Keep-Alive
============================================================
یہ تازہ ترین V4.0 ترمیمی نوٹ ہے؛ اس کے بعد والے نکات اس README میں موجود پرانے V4.0 print notes کی جگہ لیتے ہیں۔

- Android versionCode 22 اور versionName: 4.0-58mm-1.5x-print-bt30
- سیلز بل اور پڑتا بل کے لیے Native Bluetooth ESC/POS raster printing برقرار ہے۔ موبائل کی اصل بلنگ اسکرین، بل بنانے کا حساب، پارٹی/آئٹم ڈیٹا، سیلز بل markup اور پڑتا بل کا تین کالم والا markup تبدیل نہیں کیا گیا۔
- پرنٹ کے لیے الگ CSS رکھا گیا ہے؛ اصل thermal baseline کے مقابلے میں تحریر اور متعلقہ عناصر کو تقریباً 1.5X درمیانی/واضح سائز پر رکھا گیا ہے۔ بل کی ترتیب، الفاظ، ٹیبل اور باکسز کی ساخت محفوظ رکھنے کی کوشش کی گئی ہے۔ فونٹ/پرنٹر کے اصل نتیجے کی تصدیق فزیکل پرنٹ سے ہوگی۔
- 58mm کی موجودہ software mapping 384 dots اور 80mm کی 576 dots ہے۔ یہ MPT-II یونٹ کی تصدیق شدہ printable-head width یا DPI کا دعویٰ نہیں؛ اصل printable width ٹیسٹ/مینول سے verify کرنا ضروری ہے۔
- رسید کی اونچائی کے لیے 12,000 CSS px/12-million-pixel والی پرانی مصنوعی حد ہٹا دی گئی ہے۔ اونچائی rendered bill کے مطابق بنتی ہے اور ESC/POS ڈیٹا 128-row bands، 4096-byte chunks، per-band flush اور تقریباً 90ms pacing کے ساتھ بھیجا جاتا ہے۔ Android Bitmap/RAM، WebView/Skia dimensions، فون کے وسائل، Bluetooth link اور پرنٹر firmware/buffer کی قدرتی حدود پھر بھی موجود ہیں؛ اس لیے غیر محدود جسمانی لمبائی کی ضمانت نہیں دی جا سکتی۔
- Print Image اب کاغذ کی پوری configured width میں اصل aspect ratio برقرار رکھتے ہوئے fit ہوتی ہے؛ زبردستی دو تہائی چوڑائی یا crop نہیں کیا جاتا۔ Gallery/Files اور وہاں دستیاب WhatsApp میں محفوظ JPG/PNG کے لیے ACTION_OPEN_DOCUMENT اور print سے پہلے preview برقرار ہیں۔
- Bluetooth connection کو Activity سے الگ رکھنے کے لیے PrinterKeepAliveService شامل ہے۔ کامیاب connect کے بعد connected-device foreground service اور ongoing notification شروع ہوتی ہے؛ Activity بند/Recent Apps سے swipe ہونے پر Activity خود socket بند نہیں کرتی۔ آخری printer activity کے 30 منٹ بعد service socket بند کرکے خود رک جاتی ہے۔ ایپ میں صارف کی activity (touch)، connect، print اور test print کے دوران inactivity timer refresh ہوتا ہے۔
- Android Force Stop، Bluetooth بند ہونا، فون reboot، OS کی سخت battery/background پابندیاں، process kill یا printer کا خود disconnect ہونا سافٹ ویئر کے قابو سے باہر ہو سکتا ہے۔ اگر process ختم ہو جائے تو پرانا RFCOMM socket زندہ نہیں رہتا؛ ایپ دوبارہ کھلنے پر محفوظ paired address سے reconnect ممکن ہے۔
- Foreground service کے لیے notification مستقل نظر آ سکتی ہے؛ یہ background Bluetooth connection برقرار رکھنے کے لیے Android کا مطلوبہ طریقہ ہے۔
- یہ Android Studio SOURCE ZIP ہے، APK نہیں۔ اس runtime میں Gradle executable/wrapper اور Android SDK/android.jar دستیاب نہیں؛ لہٰذا Java/Android compile، APK generation، حقیقی Android background lifecycle اور MPT-II paper output test نہیں ہوئے۔
- کسی physical test کو کامیاب قرار نہیں دیا گیا۔ Test report الگ فائل میں ہے؛ 5/20/50+ items، 9/10/12/15/20 inch، آخری آئٹم، Grand Total، Urdu clarity، Print Image، 30-minute timeout، incoming call/background/Recent Apps اور Force Stop کے الگ device tests باقی ہیں۔


STAR BAGS V4.1 — Custom Thermal Print Scale (17 نومبر 2026)
- بل اور پڑتا بل کے ہر Native Bluetooth print request سے پہلے Scale انتخاب کا ڈائیلاگ کھلتا ہے۔
- دستیاب preset: 0.5X، 0.75X، 1X، 1.1X، 1.2X، 1.3X، 1.5X، 1.8X، 2X، 2.5X اور 3X۔
- Custom Scale بھی دستیاب ہے؛ محفوظ حد 0.1X سے 5X رکھی گئی ہے تاکہ غیرمعمولی قدر سے WebView/bitmap memory خطرے میں نہ پڑے۔
- بل کی موجودہ 1.5X print-only typography کو 1X baseline سمجھا گیا ہے۔ منتخب scale CSS zoom سے مکمل bill design (الفاظ، لوگو، بارڈرز، padding اور spacing) پر لگتا ہے؛ body کی logical width الٹی نسبت سے adjust ہوتی ہے تاکہ final raster کاغذ کی پوری configured printable width استعمال کرے۔
- Image picker کے Preview میں بھی یہی preset/custom scale انتخاب شامل ہے۔ 1X پر تصویر پوری configured paper width استعمال کرتی ہے؛ 1X سے کم پر تصویر centered چھوٹی ہوتی ہے اور اصل تناسب برقرار رہتا ہے۔ 1X سے زیادہ پر image width printable paper width پر cap ہوتی ہے، تصویر crop یا stretch نہیں ہوتی۔
- Image scaling کی فطری حد: اگر 1X پہلے ہی پوری paper width ہے تو 1X سے بڑی تصویر کو اصل تناسب کے ساتھ مزید چوڑا نہیں کیا جا سکتا، جب تک اسے crop، stretch یا کاغذ سے باہر نہ نکالا جائے۔ اس لیے >1X image selection full-width پر cap ہے؛ یہ limitation Preview میں بتائی گئی ہے۔
- Version code 23؛ version name 4.1-58mm-custom-scale-bt30۔
- index.html میں کوئی تبدیلی نہیں کی گئی؛ بلنگ UI، amounts، calculations اور bill/pertah markup untouched ہیں۔
- یہ source ZIP ہے، APK نہیں۔ Android SDK/Gradle دستیاب نہ ہونے کے باعث Java/Gradle build اور MPT-II پر عملی ٹیسٹ اس ماحول میں نہیں ہوئے۔

============================================================
V4.2 - SCALE APPLY + PRINT QUALITY FIX
============================================================

اس ورژن میں صارف کے V4.1 فیڈبیک کے مطابق یہ اصلاحات کی گئی ہیں:

1) بل اور پڑتا بل کے منتخب Print Scale کو اب صرف WebView zoom پر منحصر نہیں رکھا گیا۔
   منتخب اسکیل براہِ راست ہر پرنٹ عنصر کے computed font-size، line-height اور عمودی spacing پر
   ایک مرتبہ لاگو ہوتا ہے۔ اس لیے 1X، 1.2X، 1.8X، 2X وغیرہ کے درمیان تحریر کے سائز میں
   واضح فرق آنا چاہیے۔
2) کاغذ کی logical width 58mm کے لیے 384 dots اور 80mm کے لیے 576 dots ہی رکھی گئی ہے؛
   اسکیل بدلنے سے کاغذ کی چوڑائی کم نہیں کی جاتی۔ بڑے فونٹ پر متن خود نئی لائنوں میں جا سکتا ہے،
   اس لیے رسید کی لمبائی بڑھ سکتی ہے۔
3) رسید کا intermediate bitmap RGB_565 کے بجائے ARGB_8888 ہے تاکہ WebView کے antialiased
   کنارے محفوظ رہیں۔ Thermal monochrome conversion threshold کو 175 سے 188 کیا گیا ہے تاکہ
   باریک حروف کے مدھم کنارے زیادہ واضح بن سکیں۔
4) اردو کے لیے Noto Naskh Arabic UI / Noto Naskh Arabic / Noto Sans Arabic fallback ترتیب دی گئی ہے۔
5) میموری حفاظت کے لیے receipt bitmap کا 12,000,000 pixel guard رکھا گیا ہے؛ 58mm/384-dot
   چوڑائی پر یہ تقریباً 31,250 raster rows بنتی ہیں۔
6) اصل موبائل billing HTML، حساب، آئٹمز، rates، quantities اور bill data میں تبدیلی نہیں کی گئی۔

اہم: 1X پر موجودہ درمیانی baseline typography استعمال ہوتی ہے۔ مثال کے طور پر table کا 18px
base font 1X پر 18px، 1.2X پر 21.6px، 1.8X پر 32.4px اور 2X پر 36px بنتا ہے۔

عملی حد: 1X پر تصویر پہلے ہی پوری printable width استعمال کرتی ہے؛ اس لیے 1X سے بڑے image
scale پر پوری تصویر کو بغیر crop یا stretch کیے مزید چوڑا نہیں کیا جا سکتا۔ بل کی تحریر کے
اسکیل میں یہ پابندی نہیں، کیونکہ فونٹ بڑا ہونے پر متن نئی لائنوں میں منتقل ہو جاتا ہے۔

Build/Hardware status: Android SDK/Gradle اس ورک سیشن میں دستیاب نہیں تھے، اس لیے APK یا
Android compilation کا دعویٰ نہیں کیا جا رہا۔ MPT-II پر حقیقی پرنٹ، darkness، speed، 1X/1.2X/
1.8X/2X/3X visual comparison اور لمبے بل کا فزیکل ٹیسٹ ابھی درکار ہے۔

STAR BAGS V4.3 — Exact Print Preview, Scale, Font and Raster Quality (17 نومبر 2026)
- بل اور پڑتا پرنٹ میں Scale presets اور Custom Scale (0.1X تا 5X) برقرار؛ Scale فونٹ سائز، لائن ہائٹ، عمودی مارجن اور padding پر لاگو ہوتا ہے جبکہ پرنٹ پیپر کی مقررہ چوڑائی برقرار رہتی ہے۔
- Noto Naskh Arabic، Noto Sans Arabic، Serif، Sans-serif اور Monospace کے CSS/system font options؛ Bold کا الگ toggle۔ فونٹس Android WebView میں دستیاب system fonts/fallback پر منحصر ہیں؛ الگ TTF/OTF font files اس ZIP میں bundle نہیں کی گئیں۔
- Apply to All منتخب کرنے پر scale، font اور bold settings SharedPreferences میں محفوظ ہوتی ہیں اور آئندہ bill/pertah print dialog میں دوبارہ آتی ہیں۔
- بل/پڑتا پہلے final printer-width raster bitmap میں render ہوتا ہے؛ موبائل Preview میں وہی bitmap دکھائی جاتی ہے اور Print دبانے پر عین اسی bitmap کو ESC/POS raster bands میں بھیجا جاتا ہے۔ Preview میں Fit to Screen، zoom-in اور zoom-out controls صرف موبائل preview کی دیکھنے والی جسامت بدلتے ہیں، اصل پرنٹ نہیں۔
- Image print میں 1X = printable width کا ایک تہائی، 3X = مکمل printable width؛ درمیان کے scales متناسب ہیں۔ تصویر center ہوتی ہے، اصل aspect ratio برقرار رہتا ہے، crop/stretch نہیں ہوتا۔ 3X سے زیادہ custom scale پر کاغذ کی چوڑائی حد بن جاتی ہے؛ اس سے زیادہ چوڑا پرنٹ 58mm پر ممکن نہیں۔
- Raster conversion میں Floyd–Steinberg grayscale dithering اور 160 threshold استعمال؛ band pacing 120ms۔ اصل کاغذی نتیجہ پرنٹر، تھرمل ہیڈ، کاغذ اور فونٹ fallback کے مطابق بدل سکتا ہے۔
- موبائل UI، bill calculation اور اصل index.html میں کوئی تبدیلی نہیں کی گئی۔
- یہ source ZIP ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle موجود نہ ہونے کی وجہ سے مکمل Android compile/build ممکن نہیں؛ اصل MPT-II پر print/preview/font/scale کا physical test لازمی ہے۔


V4.4 — مکمل بل Preview اور Vertical Scale اصلاح
- Scale اب صرف عمودی spacing/line-height/margins/padding اور لوگو کی اونچائی پر اثر انداز ہوتا ہے؛ 58mm/80mm پرنٹ چوڑائی نہیں بڑھاتا۔
- لوگو کی چوڑائی کو Scale سے ضرب نہیں دی جاتی، اس لیے وہ پیپر کی چوڑائی کے اندر رہتا ہے۔
- بل کے root containers کی auto height، max-height اور overflow کو پرنٹ کے لیے override کیا گیا ہے۔
- مکمل DOM کے تمام عناصر کے آخری bottom position سے Preview کی اونچائی ناپی جاتی ہے، تاکہ نیچے کا حصہ رہ نہ جائے۔
- نوٹ: تھرمل پرنٹر کی اصل resolution/چوڑائی hardware dots سے محدود ہے؛ صرف Scale بڑھانے سے نئی physical pixels پیدا نہیں ہوتیں۔
